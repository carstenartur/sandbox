package org.sandbox.math.qa.jmh_generated;
public class SwuRegionBenchmark_Inputs_jmhType extends SwuRegionBenchmark_Inputs_jmhType_B3 {
}

