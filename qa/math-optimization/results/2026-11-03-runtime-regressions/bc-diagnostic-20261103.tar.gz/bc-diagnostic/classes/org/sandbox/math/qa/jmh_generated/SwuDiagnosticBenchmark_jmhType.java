package org.sandbox.math.qa.jmh_generated;
public class SwuDiagnosticBenchmark_jmhType extends SwuDiagnosticBenchmark_jmhType_B3 {
}

