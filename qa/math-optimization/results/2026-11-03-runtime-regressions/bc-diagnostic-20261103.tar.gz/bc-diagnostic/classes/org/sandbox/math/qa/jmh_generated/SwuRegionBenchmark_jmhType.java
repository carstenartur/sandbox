package org.sandbox.math.qa.jmh_generated;
public class SwuRegionBenchmark_jmhType extends SwuRegionBenchmark_jmhType_B3 {
}

