package org.sandbox.math.qa.jmh_generated;
public class SwuDiagnosticBenchmark_Inputs_jmhType extends SwuDiagnosticBenchmark_Inputs_jmhType_B3 {
}

