import java.math.BigInteger;
import java.lang.reflect.Field;
import java.util.*;
import org.bouncycastle.crypto.hash2curve.*;
import org.bouncycastle.math.ec.ECCurve;
public class OperandProbe {
 public static void main(String[] args)throws Exception {
  for(String profile:List.of("P256_XMD_SHA_256","P384_XMD_SHA_384","P521_XMD_SHA_512","BLS12_381_G1_XMD_SHA_256_SSWU_RO")) {
   var hp=HashToCurveProfile.valueOf(profile);var h=HashToEllipticCurve.getInstance(hp,"sandbox-qualified-source-test");
   Field f=HashToEllipticCurve.class.getDeclaredField("hashToField");f.setAccessible(true);var ht=(HashToField)f.get(h);
   f=HashToField.class.getDeclaredField("curve");f.setAccessible(true);var curve=(ECCurve)f.get(ht);
   BigInteger p=curve.getField().getCharacteristic(), B=curve.getB().toBigInteger(),z=hp.getZ();
   int[] max=new int[6];var random=new Random(93802455L);
   for(int i=0;i<64;i++){byte[] m=new byte[32];random.nextBytes(m);for(var row:ht.process(m,2)){BigInteger u=row[0];
    BigInteger a=z.multiply(u.multiply(u)),b=a.multiply(a).add(a),c=B.multiply(b.add(BigInteger.ONE));
    BigInteger old=u.modPow(BigInteger.TWO,p);old=z.multiply(old).mod(p);BigInteger old2=old.modPow(BigInteger.TWO,p).add(old).mod(p);BigInteger old3=B.multiply(old2.add(BigInteger.ONE).mod(p)).mod(p);
    if(!old.equals(a.mod(p))||!old2.equals(b.mod(p))||!old3.equals(c.mod(p)))throw new AssertionError();
    BigInteger[] v={u,old,a,b,c,B};for(int j=0;j<v.length;j++)max[j]=Math.max(max[j],v[j].abs().bitLength());
   }}
   System.out.println(profile+" p="+p.bitLength()+" z="+z+" max[u,reducedtv1,unreducedtv1,unreducedtv2,dividendtv3,B]="+Arrays.toString(max));
  }
 }
}
