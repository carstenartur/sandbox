package org.sandbox.jdt.math.tests;
import java.util.*;
import org.sandbox.jdt.internal.corext.fix.math.*;
import de.regelsuche.sdk.optimization.*;
public class AdmissionProbe {
 public static void main(String[] ignored) {
  var options=new MathCleanUpOptions(true,EnumSet.allOf(NumericKind.class),SafetyProfile.PRESERVE_JAVA,OptimizationGoal.LOWER_ESTIMATED_RUNTIME,1_000_000L,20_000,false,17,List.of(),true);
  for(String body:List.of("BigInteger result=x.modPow(BigInteger.TWO,m); result=result.add(result); consume(result); return observed;", "BigInteger result=x.modPow(BigInteger.TWO,m); result=result.multiply(BigInteger.TWO); consume(result); return observed;")){
   String s="import java.math.BigInteger; public class Calculation { static BigInteger observed; static void consume(BigInteger v){observed=v;} public static BigInteger compute(BigInteger x,BigInteger m){"+body+"}}";
   var a=MathematicalAnalysis.analyze(MathTestSupport.parse(s),s,options,null,s.indexOf("public static BigInteger compute"),s.length()-s.indexOf("public static BigInteger compute"));
   System.out.println("ACCEPTED "+a.evidence().stream().map(e->e.original()+" -> "+e.replacement()).toList());
  }
 }
}
