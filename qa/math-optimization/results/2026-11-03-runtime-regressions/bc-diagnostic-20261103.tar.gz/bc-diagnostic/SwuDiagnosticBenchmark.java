package org.sandbox.math.qa;

import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import javax.tools.ToolProvider;
import org.openjdk.jmh.annotations.*;

/** Diagnostic only: retained full source variants, no claim of ordinary Apply for restored. */
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.MICROSECONDS)
@Warmup(iterations=3,time=500,timeUnit=TimeUnit.MILLISECONDS)
@Measurement(iterations=5,time=500,timeUnit=TimeUnit.MILLISECONDS) @Fork(2)
public class SwuDiagnosticBenchmark {
 @State(Scope.Thread) public static class Inputs {
  @Param({"originalA","generated","restored","originalB"}) public String variant;
  @Param({"P384_XMD_SHA_384","P521_XMD_SHA_512"}) public String curve;
  @Param({"32"}) public int messageBytes;
  Function<byte[],byte[]> call; byte[][] messages=new byte[64][]; int cursor;
  Path temporary; List<BouncyCastleHashToCurveBenchmark.VariantLoader> loaders=new ArrayList<>();
  @Setup(Level.Trial) public void setup() throws Exception {
   Path root=Path.of("/workspace/scratch/a255c6a494f5/bc-diagnostic");
   Path jar=Path.of("/workspace/scratch/330c17e56514/m2-integration/org/bouncycastle/bcprov-jdk18on/1.85.2/bcprov-jdk18on-1.85.2.jar");
   temporary=Files.createTempDirectory("swu-diagnostic-");
   Map<String,Function<byte[],byte[]>> calls=new LinkedHashMap<>();
   for(String name:List.of("originalA","generated","restored","originalB")) {
    String sourceVariant=name.startsWith("original")?"original":name;
    Path out=Files.createDirectory(temporary.resolve(name));
    Path source=root.resolve(sourceVariant).resolve("org/bouncycastle/crypto/hash2curve/impl/SimplifiedShallueVanDeWoestijneMapToCurve.java");
    Path bridge=out.resolve("HashCall.java");
    Files.writeString(bridge,"""
      import java.util.function.Function;
      import org.bouncycastle.crypto.hash2curve.HashToCurveProfile;
      import org.bouncycastle.crypto.hash2curve.HashToEllipticCurve;
      public final class HashCall implements Function<byte[],byte[]> {
       private final HashToEllipticCurve hashing;
       public HashCall(String profile) throws Exception {
        hashing=HashToEllipticCurve.getInstance((HashToCurveProfile)HashToCurveProfile.class.getField(profile).get(null),"sandbox-qualified-source-test");
       }
       public byte[] apply(byte[] message) { return hashing.hashToCurve(message).getEncoded(false); }
      }
      """);
    if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"--release","17","-proc:none","-cp",jar.toString(),"-d",out.toString(),source.toString(),bridge.toString())!=0) throw new IllegalStateException("Compilation failed");
    var loader=new BouncyCastleHashToCurveBenchmark.VariantLoader(out,jar);loaders.add(loader);
    @SuppressWarnings("unchecked") var function=(Function<byte[],byte[]>)loader.loadClass("HashCall").getConstructor(String.class).newInstance(curve);
    calls.put(name,function);
   }
   var random=new Random(93802455L);
   for(int i=0;i<64;i++) {
    messages[i]=new byte[messageBytes];random.nextBytes(messages[i]);byte[] expected=calls.get("originalA").apply(messages[i]);
    for(var item:calls.entrySet()) if(!Arrays.equals(expected,item.getValue().apply(messages[i])))throw new IllegalStateException("Different output "+item.getKey()+" sample "+i);
   }
   call=calls.get(variant);
  }
  @TearDown(Level.Trial) public void cleanup() throws Exception {
   for(var loader:loaders)loader.close();
   try(var files=Files.walk(temporary)){for(Path p:files.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}
  }
 }
 @Benchmark public byte[] fullCall(Inputs in){return in.call.apply(in.messages[in.cursor++&63]);}
}
