package org.sandbox.math.qa;
import java.math.BigInteger;
import java.lang.reflect.Field;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.bouncycastle.crypto.hash2curve.*;
import org.bouncycastle.math.ec.ECCurve;
import org.openjdk.jmh.annotations.*;
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations=3,time=500,timeUnit=TimeUnit.MILLISECONDS)
@Measurement(iterations=5,time=500,timeUnit=TimeUnit.MILLISECONDS) @Fork(2)
public class SwuRegionBenchmark {
 @State(Scope.Thread) public static class Inputs {
  @Param({"originalA","generated","restored","originalB"}) public String variant;
  @Param({"P384_XMD_SHA_384","P521_XMD_SHA_512"}) public String profile;
  BigInteger p,z,B;BigInteger[] inputs=new BigInteger[128];int cursor;
  @Setup(Level.Trial) public void setup()throws Exception {
   var hp=HashToCurveProfile.valueOf(profile);var h=HashToEllipticCurve.getInstance(hp,"sandbox-qualified-source-test");
   Field f=HashToEllipticCurve.class.getDeclaredField("hashToField");f.setAccessible(true);var ht=(HashToField)f.get(h);
   f=HashToField.class.getDeclaredField("curve");f.setAccessible(true);var curve=(ECCurve)f.get(ht);
   p=curve.getField().getCharacteristic();B=curve.getB().toBigInteger();z=hp.getZ();var random=new Random(93802455L);
   for(int i=0;i<64;i++){byte[] m=new byte[32];random.nextBytes(m);var rows=ht.process(m,2);inputs[2*i]=rows[0][0];inputs[2*i+1]=rows[1][0];}
   for(var u:inputs)if(!Arrays.equals(original(u,this),generated(u,this))||!Arrays.equals(original(u,this),restored(u,this)))throw new AssertionError();
  }
 }
 static BigInteger[] original(BigInteger u,Inputs s){
  var tv1=u.modPow(BigInteger.TWO,s.p);tv1=s.z.multiply(tv1).mod(s.p);
  var tv2=tv1.modPow(BigInteger.TWO,s.p);tv2=tv2.add(tv1).mod(s.p);
  var tv3=tv2.add(BigInteger.ONE).mod(s.p);tv3=s.B.multiply(tv3).mod(s.p);
  return new BigInteger[]{tv1,tv2,tv3};
 }
 static boolean guards(BigInteger u,Inputs s){return s.B!=null&&s.B.getClass()==BigInteger.class&&s.B.bitLength()<4096
  &&s.p!=null&&s.p.getClass()==BigInteger.class&&s.p.bitLength()<4096&&s.p.signum()>0
  &&u!=null&&u.getClass()==BigInteger.class&&u.bitLength()<4096
  &&s.z!=null&&s.z.getClass()==BigInteger.class&&s.z.bitLength()<4096;}
 static BigInteger[] generated(BigInteger u,Inputs s){
  if(!guards(u,s))return original(u,s);
  var a=s.z.multiply(u.multiply(u));var b=a.multiply(a).add(a);
  return new BigInteger[]{a.mod(s.p),b.mod(s.p),s.B.multiply(b.add(BigInteger.ONE)).mod(s.p)};
 }
 static BigInteger[] restored(BigInteger u,Inputs s){
  if(!guards(u,s))return original(u,s);
  var a=s.z.multiply(u.multiply(u).mod(s.p)).mod(s.p);var b=a.multiply(a).mod(s.p).add(a).mod(s.p);
  return new BigInteger[]{a.mod(s.p),b.mod(s.p),s.B.multiply(b.add(BigInteger.ONE).mod(s.p)).mod(s.p)};
 }
 @Benchmark public BigInteger[] region(Inputs in){var u=in.inputs[in.cursor++&127];return switch(in.variant){case "generated"->generated(u,in);case "restored"->restored(u,in);default->original(u,in);};}
}
