package org.bouncycastle.crypto.hash2curve.impl;

import java.math.BigInteger;

import org.bouncycastle.crypto.hash2curve.H2cUtils;
import org.bouncycastle.crypto.hash2curve.MapToCurve;
import org.bouncycastle.crypto.hash2curve.SqrtRatioCalculator;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.math.ec.ECPoint;

/**
 * Implements the Simplified Shallue van de Woestijne Map to curve according to section 6.6.2 of RFC
 * 9380 This is the straight-line implementation optimized for Weierstrass curves as defined in
 * section F.2.
 */
public class SimplifiedShallueVanDeWoestijneMapToCurve implements MapToCurve
{
    private final ECCurve curve;
    private final BigInteger z;

    private final SqrtRatioCalculator sqrtRatioCalculator;

    /**
     * Constructs an instance of the SimplifiedShallueVanDeWoestijneMapToCurve mapping mechanism for
     * mapping values onto a Weierstrass elliptic curve. This implementation is based on section 6.6.2
     * of RFC 9380 and optimizations defined in section F.2.
     *
     * @param curve the elliptic curve to which the mapping will be applied; must conform to the
     * Weierstrass form
     * @param z a non-zero constant value used as a parameter in the mapping algorithm
     */
    public SimplifiedShallueVanDeWoestijneMapToCurve(final ECCurve curve, final BigInteger z)
    {
        this.curve = curve;
        this.z = z;
        this.sqrtRatioCalculator = new GenericSqrtRatioCalculator(curve, z);
    }

    /**
     * <p><strong>Mathematics cleanup:</strong> BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.</p>
     * 
     * Processes the given input value to map it to an elliptic curve point using the Shallue-van de
     * Woestijne algorithm, optimized for Weierstrass curves. This implementation adheres to the
     * specifications outlined in RFC 9380, section 6.6.2, and section F.2 for efficient computation.
     * <p>
     * The method computes the x and y coordinates for the point on the elliptic curve, using modular
     * arithmetic and auxiliary functions for square root computation and conditional assignments.
     *
     * @param u the input value to be mapped to a point on the elliptic curve
     * @return the computed point on the elliptic curve represented as an ECPoint
     */
    public ECPoint process(final BigInteger u)
    {
        final BigInteger A = this.curve.getA().toBigInteger();
        final BigInteger B = this.curve.getB().toBigInteger();
        final BigInteger p = this.curve.getField().getCharacteristic();

        // Verified mathematics (MATHEMATICAL).
        // BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(u, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(p, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(z, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(B, 4096).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(u).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(p).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(z).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(B).
        // Premise: POSITIVE(p).
        // Retain exact-receiver, non-null and magnitude guards for: B, p, u, z.
        // Original values:
        // final java.math.BigInteger _math0 = java.math.BigInteger.valueOf(2L);
        // final java.math.BigInteger _math1 = (z.multiply((u.modPow(_math0, p)))).mod(p);
        // final java.math.BigInteger _math2 = ((_math1.modPow(_math0, p)).add(_math1)).mod(p);
        // tv1 = _math1;
        // tv2 = _math2;
        // tv3 = ((B.multiply(((_math2.add(java.math.BigInteger.ONE)).mod(p)))).mod(p));
        // Replacement values:
        // final java.math.BigInteger _math0 = z.multiply((u.multiply(u)));
        // final java.math.BigInteger _math1 = (_math0.multiply(_math0)).add(_math0);
        // tv1 = _math0.mod(p);
        // tv2 = _math1.mod(p);
        // tv3 = B.multiply(_math1.add(java.math.BigInteger.ONE)).mod(p);
        // Recorded search path:
        // Search step 1/6 [modpow-small-binary-chain]:
        // final java.math.BigInteger _math0 = z.multiply((u.multiply(u).mod(p))).mod(p);
        // final java.math.BigInteger _math1 = ((_math0.modPow(java.math.BigInteger.valueOf(2L), p)).add(_math0)).mod(p);
        // tv1 = _math0;
        // tv2 = _math1;
        // tv3 = (B.multiply(((_math1.add(java.math.BigInteger.ONE)).mod(p))).mod(p));
        // Search step 2/6 [modpow-small-binary-chain]:
        // final java.math.BigInteger _math0 = z.multiply((u.multiply(u).mod(p))).mod(p);
        // final java.math.BigInteger _math1 = ((_math0.multiply(_math0).mod(p)).add(_math0)).mod(p);
        // tv1 = _math0;
        // tv2 = _math1;
        // tv3 = (B.multiply(((_math1.add(java.math.BigInteger.ONE)).mod(p))).mod(p));
        // Search step 3/6 [mod-arithmetic-inner-reductions]:
        // final java.math.BigInteger _math0 = (z.multiply((u.multiply(u)))).mod(p);
        // final java.math.BigInteger _math1 = ((_math0.multiply(_math0).mod(p)).add(_math0)).mod(p);
        // tv1 = _math0;
        // tv2 = _math1;
        // tv3 = (B.multiply(((_math1.add(java.math.BigInteger.ONE)).mod(p))).mod(p));
        // Search step 4/6 [mod-arithmetic-inner-reductions]:
        // final java.math.BigInteger _math0 = z.multiply((u.multiply(u)));
        // final java.math.BigInteger _math1 = ((_math0.multiply(_math0)).add(_math0)).mod(p);
        // tv1 = (_math0.mod(p));
        // tv2 = _math1;
        // tv3 = (B.multiply(((_math1.add(java.math.BigInteger.ONE)).mod(p))).mod(p));
        // Search step 5/6 [mod-arithmetic-inner-reductions]:
        // final java.math.BigInteger _math0 = z.multiply((u.multiply(u)));
        // final java.math.BigInteger _math1 = (_math0.multiply(_math0)).add(_math0);
        // tv1 = (_math0.mod(p));
        // tv2 = (_math1.mod(p));
        // tv3 = (B.multiply(((_math1.add(java.math.BigInteger.ONE)).mod(p))).mod(p));
        // Search step 6/6 [mod-arithmetic-inner-reductions]:
        // final java.math.BigInteger _math0 = z.multiply((u.multiply(u)));
        // final java.math.BigInteger _math1 = (_math0.multiply(_math0)).add(_math0);
        // tv1 = (_math0.mod(p));
        // tv2 = (_math1.mod(p));
        // tv3 = ((B.multiply((_math1.add(java.math.BigInteger.ONE)))).mod(p));
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: AFFINE_MODULAR_NORMAL_FORM.
        // Estimated operation work: 104 -> 36; not a timing measurement.
        BigInteger tv1;
        BigInteger tv2;
        BigInteger tv3;
        if ((B != null && B.getClass() == java.math.BigInteger.class && B.bitLength() < 4096) && (p != null && p.getClass() == java.math.BigInteger.class && p.bitLength() < 4096 && p.signum() > 0) && (u != null && u.getClass() == java.math.BigInteger.class && u.bitLength() < 4096) && (z != null && z.getClass() == java.math.BigInteger.class && z.bitLength() < 4096)) {
        final java.math.BigInteger _math0 = z.multiply((u.multiply(u)));
        final java.math.BigInteger _math1 = (_math0.multiply(_math0)).add(_math0);
        tv1 = _math0.mod(p);
        tv2 = _math1.mod(p);
        tv3 = B.multiply(_math1.add(java.math.BigInteger.ONE)).mod(p);
        } else {
        // Mathematics fallback: unchanged original Java behavior.
        tv1 = u.modPow(BigInteger.valueOf(2), p);
        tv1 = this.z.multiply(tv1).mod(p);
        tv2 = tv1.modPow(BigInteger.valueOf(2), p);
        tv2 = tv2.add(tv1).mod(p);
        tv3 = tv2.add(BigInteger.ONE).mod(p);
        tv3 = B.multiply(tv3).mod(p);
        }
        BigInteger tv4 = H2cUtils.cmov(this.z, tv2.negate(), !tv2.equals(BigInteger.ZERO));
        tv4 = A.multiply(tv4).mod(p);
        // Verified mathematics (MATHEMATICAL).
        // BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(tv3, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(p, 4096).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(tv3).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(p).
        // Premise: POSITIVE(p).
        // Retain exact-receiver, non-null and magnitude guards for: p, tv3.
        // Original values:
        // tv2 = (tv3.modPow(java.math.BigInteger.valueOf(2L), p));
        // Replacement values:
        // tv2 = tv3.multiply(tv3).mod(p);
        // Recorded search path:
        // Search step 1/1 [modpow-small-binary-chain]:
        // tv2 = (tv3.multiply(tv3).mod(p));
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: AFFINE_MODULAR_NORMAL_FORM.
        // Estimated operation work: 36 -> 10; not a timing measurement.
        if ((p != null && p.getClass() == java.math.BigInteger.class && p.bitLength() < 4096 && p.signum() > 0) && (tv3 != null && tv3.getClass() == java.math.BigInteger.class && tv3.bitLength() < 4096)) {
        tv2 = tv3.multiply(tv3).mod(p);
        } else {
        // Mathematics fallback: unchanged original Java behavior.
        tv2 = tv3.modPow(BigInteger.valueOf(2), p);
        }
        // Verified mathematics (MATHEMATICAL).
        // BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(tv4, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(p, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(A, 4096).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(tv4).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(p).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(A).
        // Premise: POSITIVE(p).
        // Retain exact-receiver, non-null and magnitude guards for: A, p, tv4.
        // Original values:
        // final java.math.BigInteger _math0 = tv4.modPow(java.math.BigInteger.valueOf(2L), p);
        // tv6 = _math0;
        // tv5 = ((A.multiply(_math0)).mod(p));
        // Replacement values:
        // final java.math.BigInteger _math2 = tv4.multiply(tv4).mod(p);
        // tv6 = _math2;
        // tv5 = A.multiply(_math2).mod(p);
        // Recorded search path:
        // Search step 1/1 [modpow-small-binary-chain]:
        // final java.math.BigInteger _math0 = tv4.multiply(tv4).mod(p);
        // tv6 = _math0;
        // tv5 = (A.multiply(_math0).mod(p));
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: AFFINE_MODULAR_NORMAL_FORM.
        // Estimated operation work: 44 -> 20; not a timing measurement.
        BigInteger tv6;
        BigInteger tv5;
        if ((A != null && A.getClass() == java.math.BigInteger.class && A.bitLength() < 4096) && (p != null && p.getClass() == java.math.BigInteger.class && p.bitLength() < 4096 && p.signum() > 0) && (tv4 != null && tv4.getClass() == java.math.BigInteger.class && tv4.bitLength() < 4096)) {
        final java.math.BigInteger _math2 = tv4.multiply(tv4).mod(p);
        tv6 = _math2;
        tv5 = A.multiply(_math2).mod(p);
        } else {
        // Mathematics fallback: unchanged original Java behavior.
        tv6 = tv4.modPow(BigInteger.valueOf(2), p);
        tv5 = A.multiply(tv6).mod(p);
        }
        tv2 = tv2.add(tv5).mod(p);
        tv2 = tv2.multiply(tv3).mod(p);
        tv6 = tv6.multiply(tv4).mod(p);
        tv5 = B.multiply(tv6).mod(p);
        tv2 = tv2.add(tv5).mod(p);
        BigInteger x = tv1.multiply(tv3).mod(p);
        final SqrtRatio sqrtRatio = this.sqrtRatioCalculator.sqrtRatio(tv2, tv6);
        final boolean isGx1Square = sqrtRatio.isQR();
        final BigInteger y1 = sqrtRatio.getRatio();
        BigInteger y = tv1.multiply(u).mod(p);
        y = y.multiply(y1).mod(p);
        x = H2cUtils.cmov(x, tv3, isGx1Square);
        y = H2cUtils.cmov(y, y1, isGx1Square);
        final boolean e1 = H2cUtils.sgn0(u, this.curve) == H2cUtils.sgn0(y, this.curve);
        y = H2cUtils.cmov(y.negate(), y, e1).mod(p);
        x = x.multiply(tv4.modPow(BigInteger.ONE.negate(), p)).mod(p);
        return this.curve.createPoint(x, y);
    }
}
