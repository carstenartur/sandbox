#!/usr/bin/env bash
set -eu
root=/workspace/scratch/a255c6a494f5/methodinfo-investigation
jdk=/workspace/scratch/330c17e56514/toolchains/jdk-25.0.5+8
method_task_cp="$(cat "$root/production-classpath.txt"):$root/diagnostic-classes"
"$jdk/bin/java" -cp "$method_task_cp" org.openjdk.jmh.Main 'measure.DiagnosticJmh.freshReadAndFirstArgumentNames' -p variant=original,originalControl,current,new,native -f 2 -wi 3 -i 5 -w 500ms -r 500ms -t 1 -bm avgt -tu ns -prof gc -foe true -rf json -rff "$root/diagnostic-evidence/jmh-results.json" -o "$root/diagnostic-evidence/jmh.log" > "$root/diagnostic-evidence/jmh-console.log" 2>&1
