package measure.jmh_generated;
public class DiagnosticJmh_jmhType extends DiagnosticJmh_jmhType_B3 {
}

