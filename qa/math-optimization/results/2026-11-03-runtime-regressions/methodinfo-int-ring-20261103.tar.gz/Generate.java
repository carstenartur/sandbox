import java.nio.file.*;
import java.util.*;
import org.eclipse.jdt.core.*;
import org.eclipse.jdt.core.dom.*;
import org.eclipse.jface.text.Document;
import org.sandbox.jdt.internal.corext.fix.math.*;
import de.regelsuche.sdk.optimization.*;
public class Generate {
 public static void main(String[] args) throws Exception {
  Path root=Path.of(args[0]);String source=Files.readString(root.resolve("original-src/org/eclipse/jdt/internal/compiler/classfmt/MethodInfo.java"));
  String jar=root.resolve("original-compiler.jar").toString();
  var settings=new HashMap<String,String>();JavaCore.setComplianceOptions("17",settings);
  var parser=ASTParser.newParser(AST.getJLSLatest());parser.setSource(source.toCharArray());parser.setUnitName("MethodInfo.java");parser.setResolveBindings(true);parser.setEnvironment(new String[]{jar},new String[0],null,true);parser.setCompilerOptions(settings);
  var ast=(CompilationUnit)parser.createAST(null);for(var p:ast.getProblems())if(p.isError())throw new AssertionError(p);
  String loop="for (int i = 0; i < exceptionTableLength; i++) {\n\t\t\treadOffset += 8;\n\t\t}";int offset=source.indexOf(loop);if(offset<0)throw new AssertionError("loop");
  var options=new MathCleanUpOptions(true,EnumSet.allOf(NumericKind.class),SafetyProfile.PRESERVE_JAVA,OptimizationGoal.LOWER_ESTIMATED_RUNTIME,1_000_000,20_000,false,17,List.of());
  var environment=new MathematicalAnalysis.SourceEnvironment("MethodInfo.java",List.of(jar),List.of(),List.of(),settings);
  var analysis=MathematicalAnalysis.analyze(ast,source,options,null,offset,loop.length(),environment);
  if(analysis.replacements().size()!=1)throw new AssertionError(analysis.diagnostics());
  var document=new Document(source);analysis.newEdit().apply(document);String generated=document.get();
  Path out=root.resolve(args[1]+"-src/org/eclipse/jdt/internal/compiler/classfmt/MethodInfo.java");Files.createDirectories(out.getParent());Files.writeString(out,generated);
  Files.writeString(root.resolve(args[1]+"-replacement.txt"),analysis.replacements().getFirst().replacement());
  System.out.println(analysis.replacements().getFirst().replacement());
 }
}
