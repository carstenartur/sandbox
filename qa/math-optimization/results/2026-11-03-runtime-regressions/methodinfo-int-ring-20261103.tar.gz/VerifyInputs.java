import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
public class VerifyInputs {
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]);
  class Verifier extends ClassLoader {Verifier(){super(ClassLoader.getPlatformClassLoader());}Class<?> define(byte[] b){return defineClass(null,b,0,b.length);}}
  for(int n:new int[]{0,24,79,4095,4096,4097,8192,65535}){
   byte[] input=Files.readAllBytes(root.resolve("fixtures/handlers-"+n+".class"));
   Object actual=new Verifier().define(input).getMethod("target",int.class).invoke(null,7);
   if(!Integer.valueOf(7).equals(actual))throw new AssertionError(n);
  }
  try(var jar=new JarFile(root.resolve("original-compiler.jar").toFile());var in=jar.getInputStream(jar.getJarEntry("org/eclipse/jdt/internal/compiler/classfmt/ClassFileReader.class"))){
   if(!Arrays.equals(in.readAllBytes(),Files.readAllBytes(root.resolve("fixtures/real-ClassFileReader.class"))))throw new AssertionError("real control source");
  }
  System.out.println("8 legal synthetic fixtures loaded/invoked; real fixture exactly equals qualified JAR class entry");
 }
}
