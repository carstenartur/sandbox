#!/usr/bin/env bash
set -eu
root=/workspace/scratch/a255c6a494f5/methodinfo-investigation
jdk=/workspace/scratch/330c17e56514/toolchains/jdk-25.0.5+8
for variant in original current new; do
 mkdir -p "$root/$variant-classes"
 "$jdk/bin/javac" --release 17 -proc:none -g -cp "$root/original-compiler.jar" -d "$root/$variant-classes" "$root/$variant-src/org/eclipse/jdt/internal/compiler/classfmt/MethodInfo.java"
done
cp -R "$root/original-classes" "$root/originalControl-classes"
mkdir -p "$root/native-classes/org/eclipse/jdt/internal/compiler/classfmt"
unzip -p "$root/original-compiler.jar" org/eclipse/jdt/internal/compiler/classfmt/MethodInfo.class > "$root/native-classes/org/eclipse/jdt/internal/compiler/classfmt/MethodInfo.class"
