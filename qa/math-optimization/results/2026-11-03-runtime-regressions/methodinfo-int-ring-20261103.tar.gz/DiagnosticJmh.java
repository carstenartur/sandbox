package measure;
import java.nio.file.*;
import java.net.*;
import java.lang.invoke.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.jar.*;
import java.security.*;
import org.openjdk.jmh.annotations.*;
@BenchmarkMode(Mode.AverageTime) @OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations=3,time=500,timeUnit=TimeUnit.MILLISECONDS)
@Measurement(iterations=5,time=500,timeUnit=TimeUnit.MILLISECONDS)
@Fork(value=2,jvmArgsAppend={"-Xms1g","-Xmx1g","-XX:+UseG1GC","-Xverify:all"}) @Threads(1) @State(Scope.Thread)
public class DiagnosticJmh {
 @Param({"original","originalControl","current","new"}) public String variant;
 @Param({"0","65535","real-ClassFileReader"}) public String workload;
 static final Path ROOT=Path.of("/workspace/scratch/a255c6a494f5/methodinfo-investigation");
 static final String CLASS="org.eclipse.jdt.internal.compiler.classfmt.MethodInfo";
 private Loader actual;private byte[] input;private char[] name;
 static String sha(byte[] bytes) throws Exception {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}
 static class Loader implements AutoCloseable {
  URLClassLoader loader;MethodHandle read,inspect;
  Loader(String variant) throws Exception {
   Path classes=ROOT.resolve(variant+"-classes");Path jar=ROOT.resolve("original-compiler.jar");
   loader=new URLClassLoader(new URL[]{classes.toUri().toURL(),ROOT.resolve("bridge-classes").toUri().toURL(),jar.toUri().toURL()},ClassLoader.getPlatformClassLoader());
   Class<?> bridge=Class.forName("benchbridge.ReaderBridge",true,loader),method=Class.forName(CLASS,true,loader);
   Class<?> reader=Class.forName("org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader",true,loader);
   if(method.getClassLoader()!=loader||reader.getClassLoader()!=loader||bridge.getClassLoader()!=loader)throw new AssertionError("loader");
   if(!Path.of(method.getProtectionDomain().getCodeSource().getLocation().toURI()).equals(classes))throw new AssertionError("override");
   if(!Path.of(reader.getProtectionDomain().getCodeSource().getLocation().toURI()).equals(jar))throw new AssertionError("base jar");
   read=MethodHandles.publicLookup().findStatic(bridge,"read",MethodType.methodType(char[][][].class,byte[].class,char[].class));
   inspect=MethodHandles.publicLookup().findStatic(bridge,"inspect",MethodType.methodType(Object[].class,byte[].class,char[].class,boolean.class));
  }
  char[][][] read(byte[] input,char[] name)throws Throwable{return (char[][][])read.invokeExact(input,name);}
  public void close() throws IOException{loader.close();}
 }
 @Setup(Level.Trial) public void setup() throws Throwable {
  input=Files.readAllBytes(ROOT.resolve("fixtures/"+(workload.startsWith("real-")?workload:"handlers-"+workload)+".class"));name=(workload+".class").toCharArray();
  actual=new Loader(variant);
  Object[] check=(Object[])actual.inspect.invokeExact(input,name,false);
  if(!Boolean.TRUE.equals(check[3])||((Integer)check[1])!=((char[][][])check[0]).length)throw new AssertionError("lazy cache");
  try(var reference=new Loader("original")){
   for(int i=0;i<64;i++)if(!Arrays.deepEquals(reference.read(input,name),actual.read(input,name)))throw new AssertionError("names");
  }
  Properties proof=new Properties();proof.setProperty("variant",variant);proof.setProperty("workload",workload);
  proof.setProperty("classSha256",sha(Files.readAllBytes(ROOT.resolve(variant+"-classes/"+CLASS.replace('.','/')+".class"))));
  proof.setProperty("inputSha256",sha(input));proof.setProperty("jarSha256",sha(Files.readAllBytes(ROOT.resolve("original-compiler.jar"))));
  proof.setProperty("runtime",System.getProperty("java.runtime.version"));proof.setProperty("flags",java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString());
  try(var out=Files.newBufferedWriter(ROOT.resolve("diagnostic-evidence/"+variant+"-"+workload+"-"+ProcessHandle.current().pid()+".properties"))){proof.store(out,"Full fresh read and first argument-name decoding; checks outside timing");}
 }
 @Benchmark public char[][][] freshReadAndFirstArgumentNames()throws Throwable{return actual.read(input,name);}
 @TearDown(Level.Trial)public void close()throws Exception{actual.close();}
 public static void main(String[] args)throws Throwable{
  for(String variant:List.of("original","originalControl","current","new","native"))for(String workload:List.of("0","24","79","4095","4096","4097","8192","65535","real-ClassFileReader")){
   var instance=new DiagnosticJmh();instance.variant=variant;instance.workload=workload;instance.setup();instance.freshReadAndFirstArgumentNames();instance.close();
  }
  System.out.println("45 complete-reader equivalence and lazy-cache checks passed");
 }
}
