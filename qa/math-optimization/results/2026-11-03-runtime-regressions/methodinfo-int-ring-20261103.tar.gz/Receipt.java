import java.nio.file.*;
import java.util.*;
import java.security.*;
import com.fasterxml.jackson.databind.*;
public class Receipt {
 static String hash(Path p)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(p)));}
 public static void main(String[] args)throws Exception{
  Path root=Path.of(args[0]),repo=Path.of(args[1]);var hashes=new TreeMap<String,String>();
  for(String name:List.of("original-compiler.jar","original-src","current-src","new-src","original-classes","originalControl-classes","current-classes","new-classes","native-classes","fixtures","bridge-src","bridge-classes","cohort1-known-initial-shared-load","cohort2-quiet","Generate.java","DiagnosticJmh.java","run-diagnostic-jmh.sh","prepare-classes.sh","VerifyInputs.java")){
   try(var paths=Files.walk(root.resolve(name))){for(Path p:paths.filter(Files::isRegularFile).toList())hashes.put(root.relativize(p).toString(),hash(p));}
  }
  var data=new LinkedHashMap<String,Object>();data.put("schema","sandbox.methodinfo-int-ring-diagnostic/v1");data.put("productionCommit","1bb66e41b");data.put("jdtSourceCommit","6725c16c24d94c83302346dc384bb915a0f2fe1a");data.put("jvm",System.getProperty("java.runtime.version"));data.put("javaHome",System.getProperty("java.home"));
  data.put("quietCohort","All original comparisons overlap at 99.9%; no resolved speedup/regression; historical 21.1% regression unconfirmed in this local diagnostic");
  data.put("cohort1Confound","Another preexisting Maven compile overlapped approximately the first 15 seconds; retained entire cohort; clean identical repeat predeclared before comparative analysis");
  data.put("checks",Map.of("baselineFocused",41,"finalFocused",42,"finalFailures",0,"finalErrors",0,"finalSkips",0,"completeReaderChecks",45,"jvmVerifiedSyntheticFixtures",8,"timedCases",30,"timedForks",60));
  data.put("hashes",hashes);new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(root.resolve("receipt.json").toFile(),data);
 }
}
