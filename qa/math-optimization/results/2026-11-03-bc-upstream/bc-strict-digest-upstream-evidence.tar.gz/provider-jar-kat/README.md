# Additional official digest tests against the actual provider JAR

Both phases passed all eight unchanged official `SimpleTest` classes: SHA-1,
SHA-256, MD4, MD5, SHA-384, SHA-512, SHA-512/224 and SHA-512/256. The adapter checks
each `TestResult.isSuccessful()` and fails the process for any unsuccessful test
or class-provenance mismatch. It does not infer success from console text.

Each loader contains only the corresponding built provider JAR as production
code, followed by the official test classes and resources. The parent is the
platform class loader. This actually executes the effective Java-9 overlay
implementations used by Java 25, including SHA256Digest, LongDigest, SHA384Digest,
SHA512Digest and SHA512tDigest. All 13 loaded classes in the digest package are
bound to that provider JAR and its effective resource bytes; all 68 loaded BC
classes per phase have source and byte hashes recorded.

The official test classes retain their existing fixed expected vectors, million-A
tests where defined, clone/memo and encoded-state checks. Nine test/dependency
class files and their corresponding source files are byte-identical before and
after. The sources and class snapshots used are retained under each phase.

These are eight additional top-level official test invocations per phase, kept
separate from the full Gradle/JUnit inventory. They do not represent a new full
provider suite or a benchmark. Operational durations in the raw receipts must
not be interpreted as relative performance.

Read `summary.json` first. The two phase receipts retain loaded-class identities,
the exact result objects, provider JAR hashes and effective MR resource paths.
`executed-commands.txt` records the isolated invocation and tool identities.
