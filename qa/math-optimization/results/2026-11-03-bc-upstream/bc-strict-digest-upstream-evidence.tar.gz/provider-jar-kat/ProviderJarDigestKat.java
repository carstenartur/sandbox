import com.google.gson.GsonBuilder;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarFile;
import java.util.zip.ZipFile;

/** Execute unchanged official SimpleTests against the already-built provider JAR only. */
public class ProviderJarDigestKat {
    private static final List<String> TESTS = List.of("SHA1DigestTest", "SHA256DigestTest", "MD4DigestTest", "MD5DigestTest",
            "SHA384DigestTest", "SHA512DigestTest", "SHA512t224DigestTest", "SHA512t256DigestTest");
    private static final List<String> REQUIRED_DIGESTS = List.of("SHA1Digest", "SHA256Digest", "MD4Digest", "MD5Digest",
            "SHA384Digest", "SHA512Digest", "SHA512tDigest", "LongDigest");
    private static String hash(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static final class ObservingLoader extends URLClassLoader {
        final Map<String, Class<?>> loaded = new LinkedHashMap<>();
        ObservingLoader(URL[] urls) { super(urls, ClassLoader.getPlatformClassLoader()); }
        @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
            Class<?> cls = super.findClass(name);
            if (name.startsWith("org.bouncycastle.")) loaded.put(name, cls);
            return cls;
        }
    }
    public static void main(String[] args) throws Exception {
        Path base = Path.of(args[0]).toAbsolutePath();
        String phase = args[1];
        if (!phase.equals("baseline") && !phase.equals("after")) throw new IllegalArgumentException("phase");
        Path tree = base.resolve(phase.equals("baseline") ? "original" : "after");
        Path provider = tree.resolve("prov/build/libs/bcprov-jdk18on-1.85.2.jar").toRealPath();
        Path tests = tree.resolve("core/build/classes/java/test").toRealPath();
        Path resources = tree.resolve("core/build/resources/test").toRealPath();
        Path output = base.resolve("provider-jar-kat/" + phase);
        Files.createDirectories(output);
        URL[] urls = {provider.toUri().toURL(), tests.toUri().toURL(), resources.toUri().toURL()};
        var receipt = new LinkedHashMap<String, Object>();
        receipt.put("phase", phase);
        receipt.put("runtime", Runtime.version().toString());
        receipt.put("providerJar", provider.toString());
        receipt.put("providerJarSha256", hash(Files.readAllBytes(provider)));
        receipt.put("isolatedClasspath", List.of(provider.toString(), tests.toString(), resources.toString()));
        receipt.put("parentLoader", "ClassLoader.getPlatformClassLoader()");
        receipt.put("productionMainDirectoriesOrCoreJarOnClasspath", false);
        var results = new ArrayList<Map<String, Object>>();
        var identities = new ArrayList<Map<String, Object>>();
        boolean success = true;
        long start = System.nanoTime();
        try (var loader = new ObservingLoader(urls);
                var jar = new JarFile(provider.toFile(), false, ZipFile.OPEN_READ, Runtime.version())) {
            Class<?> simpleTest = loader.loadClass("org.bouncycastle.util.test.SimpleTest");
            Class<?> testResult = loader.loadClass("org.bouncycastle.util.test.TestResult");
            var perform = simpleTest.getMethod("perform");
            var isSuccessful = testResult.getMethod("isSuccessful");
            for (String name : TESTS) {
                var item = new LinkedHashMap<String, Object>();
                item.put("test", "org.bouncycastle.crypto.test." + name);
                long testStart = System.nanoTime();
                try {
                    Class<?> cls = loader.loadClass("org.bouncycastle.crypto.test." + name);
                    if (!Path.of(cls.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath().equals(tests))
                        throw new IllegalStateException("Official test class came from unexpected location: " + cls);
                    var constructor = cls.getDeclaredConstructor();
                    constructor.setAccessible(true);
                    Object instance = constructor.newInstance();
                    Object result = perform.invoke(instance);
                    boolean passed = (Boolean) isSuccessful.invoke(result);
                    item.put("passed", passed);
                    item.put("result", result.toString());
                    if (!passed) success = false;
                    System.out.println(phase + " " + name + " successful=" + passed + " " + result);
                } catch (Throwable failure) {
                    Throwable actual = failure instanceof InvocationTargetException invocation ? invocation.getCause() : failure;
                    item.put("passed", false);
                    item.put("error", actual.toString());
                    actual.printStackTrace(System.err);
                    success = false;
                }
                item.put("elapsedSecondsOperationalOnly", (System.nanoTime() - testStart) / 1_000_000_000.0);
                results.add(item);
            }
            for (String name : REQUIRED_DIGESTS) {
                if (!loader.loaded.containsKey("org.bouncycastle.crypto.digests." + name))
                    throw new IllegalStateException("Expected tested digest was not loaded: " + name);
            }
            for (var entry : new ArrayList<>(loader.loaded.entrySet())) {
                String name = entry.getKey();
                String resourceName = name.replace('.', '/') + ".class";
                Class<?> cls = entry.getValue();
                Path origin = Path.of(cls.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
                byte[] bytes;
                try (var in = loader.getResourceAsStream(resourceName)) { bytes = in.readAllBytes(); }
                var item = new LinkedHashMap<String, Object>();
                item.put("class", name);
                item.put("codeSource", origin.toString());
                item.put("resource", loader.getResource(resourceName).toString());
                item.put("sha256", hash(bytes));
                item.put("classfileMajor", ((bytes[6] & 255) << 8) | (bytes[7] & 255));
                if (origin.equals(provider)) {
                    var jarEntry = jar.getJarEntry(resourceName);
                    byte[] expected;
                    try (var in = jar.getInputStream(jarEntry)) { expected = in.readAllBytes(); }
                    if (!java.util.Arrays.equals(bytes, expected)) throw new IllegalStateException("Provider resource differs: " + name);
                    item.put("effectiveJarEntry", jarEntry.getRealName());
                    item.put("matchesEffectiveJava25JarBytes", true);
                } else if (origin.equals(tests)) {
                    Path saved = output.resolve("official-test-classes/" + resourceName);
                    Files.createDirectories(saved.getParent());
                    Files.write(saved, bytes);
                    Path source = tree.resolve("core/src/test/java/" + name.replace('.', '/') + ".java");
                    if (Files.isRegularFile(source)) {
                        item.put("sourcePath", source.toString());
                        item.put("sourceSha256", hash(Files.readAllBytes(source)));
                        Path savedSource = output.resolve("official-test-sources/" + name.replace('.', '/') + ".java");
                        Files.createDirectories(savedSource.getParent());
                        Files.copy(source, savedSource);
                    }
                } else throw new IllegalStateException("Unexpected Bouncy Castle class origin: " + origin);
                if (name.startsWith("org.bouncycastle.crypto.digests.") && !origin.equals(provider))
                    throw new IllegalStateException("Digest class is shadowed by non-provider artifact: " + name);
                identities.add(item);
            }
            receipt.put("allLoadedDigestClassesFromProviderJar", true);
            receipt.put("allProviderLoadedClassesMatchEffectiveJava25JarResources", true);
        } finally {
            receipt.put("results", results);
            receipt.put("loadedBouncyCastleClassIdentities", identities);
            receipt.put("elapsedSecondsOperationalOnly", (System.nanoTime() - start) / 1_000_000_000.0);
            receipt.put("allEightOfficialSimpleTestsSuccessful", success && results.size() == 8
                    && Boolean.TRUE.equals(receipt.get("allLoadedDigestClassesFromProviderJar")));
            Files.writeString(output.resolve("receipt.json"), new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create().toJson(receipt) + "\n");
        }
        if (!Boolean.TRUE.equals(receipt.get("allEightOfficialSimpleTestsSuccessful"))) throw new AssertionError("Provider-only digest qualification failed");
    }
}
