#!/usr/bin/env bash
# Thin process adapter: continue only the interrupted upstream provider task.
set -uo pipefail
base=/workspace/scratch/330c17e56514/bc-upstream-qualification
jdk=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
proxy_authority=${HTTPS_PROXY#*://}
proxy_authority=${proxy_authority%%/*}
proxy_host=${proxy_authority%:*}
proxy_port=${proxy_authority##*:}
proxy_options="-Dhttp.proxyHost=$proxy_host -Dhttp.proxyPort=$proxy_port -Dhttps.proxyHost=$proxy_host -Dhttps.proxyPort=$proxy_port -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -XX:ActiveProcessorCount=2"
unset BC_JDK8 BC_JDK11 BC_JDK17 BC_JDK21
export JAVA_HOME="$jdk" BC_JDK25="$jdk" BC_TEST_DATA_HOME="$base/bc-test-data"
export GRADLE_USER_HOME="$base/gradle-cache-after" GRADLE_OPTS="$proxy_options" JAVA_TOOL_OPTIONS="$proxy_options"
export PATH="$jdk/bin:$PATH"
cd "$base/after" || exit 2
command=(./gradlew --no-daemon --max-workers=1 --console=plain :prov:test --stacktrace --offline)
printf '%q ' "${command[@]}" > "$base/after-provider-resume-command.txt"
printf '\n' >> "$base/after-provider-resume-command.txt"
date -u +%FT%TZ > "$base/after-provider-resume-started.txt"
date +%s > "$base/after-provider-resume-started-epoch.txt"
status=0
"${command[@]}" > "$base/after-provider-resume.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$base/after-provider-resume-exit-code.txt"
date -u +%FT%TZ > "$base/after-provider-resume-ended.txt"
date +%s > "$base/after-provider-resume-ended-epoch.txt"
exit "$status"
