package org.sandbox.jdt.triggerpattern.test.policy;

import java.nio.file.*;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/** Read-only entry point to the existing comparator; executes no JUnit tests. */
public final class RetainedJUnitInventory {
  private static final Gson JSON = new GsonBuilder().setPrettyPrinting().create();
  private record Counts(int reportFiles, int testExecutions, int passed, int skipped,
      int failures, int errors, long uniqueTestIdentities, int uniqueIdentityStatePairs,
      long repeatedExecutionsBeyondUniqueIdentity, List<String> parseErrors) {}
  private record Shape(long suiteElements, long suitesWrapperElements, long testcaseElements) {}
  private record Entry(String module, String identity, String state, int executions) {}

  public static void main(String[] args) throws Exception {
    if (args.length == 4 && args[0].equals("compare")) {
      var result = JUnitXmlInventoryComparator.compare(Path.of(args[1]), Path.of(args[2]),
          JUnitXmlInventoryComparator.Mapping.empty());
      result.write(Path.of(args[3]));
      System.out.println(JSON.toJson(result));
      if (!result.passed()) throw new IllegalStateException("Inventory comparison failed: " + result.problems());
      return;
    }
    if (args.length != 3 || !args[0].equals("inventory"))
      throw new IllegalArgumentException("inventory REPORT_ROOT OUTPUT_DIR or compare BEFORE AFTER OUTPUT_JSON");
    Path root = Path.of(args[1]), output = Path.of(args[2]);
    Files.createDirectories(output);
    var whole = JUnitXmlInventoryComparator.collect(root, DocumentBuilderFactory::newInstance);
    Path mathRoot = root.resolve("sandbox_math_cleanup_test");
    var math = JUnitXmlInventoryComparator.collect(mathRoot, DocumentBuilderFactory::newInstance);
    var modules = new TreeMap<String, Counts>();
    var entries = new ArrayList<Entry>();
    try (var directories = Files.list(root)) {
      for (Path module : directories.filter(Files::isDirectory).sorted().toList()) {
        var inventory = JUnitXmlInventoryComparator.collect(module, DocumentBuilderFactory::newInstance);
        if (inventory.reportFiles() == 0) continue;
        modules.put(module.getFileName().toString(), counts(inventory));
        inventory.states().entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e ->
            entries.add(new Entry(module.getFileName().toString(), e.getKey().identity(),
                e.getKey().state().value(), e.getValue())));
      }
    }
    Shape wholeShape = shape(root), mathShape = shape(mathRoot);
    var summary = new LinkedHashMap<String, Object>();
    summary.put("scope", "Actual retained JUnit XML from one Sandbox Maven job; no test execution and no before/after comparison.");
    summary.put("wholeBuild", counts(whole));
    summary.put("mathematicsModule", counts(math));
    summary.put("modulesWithReports", modules.size());
    summary.put("moduleQualifiedUniqueTestIdentities", modules.values().stream().mapToLong(Counts::uniqueTestIdentities).sum());
    summary.put("xmlStructureWholeBuild", wholeShape);
    summary.put("xmlStructureMathematics", mathShape);
    summary.put("countingDefinitions", List.of(
        "Test executions are testcase elements with multiplicity, classified by the unchanged JUnitXmlInventoryComparator.",
        "A unique identity is the reported classname (or suite-name fallback) plus # plus reported test name; this is not a count of unique Java methods. Same identity in different modules is counted separately only by moduleQualifiedUniqueTestIdentities.",
        "Suite elements and XML report files are container/report counts, not additional test executions; they do not enumerate JUnit-engine runtime containers.",
        "Skipped testcase records are included in testExecutions but excluded from passed.",
        "Suite-level aggregate tests attributes are not added to testcase counts."));
    summary.put("parseErrors", whole.parseErrors());
    write(output.resolve("inventory-summary.json"), summary);
    write(output.resolve("module-inventories.json"), modules);
    write(output.resolve("test-inventory.json"), entries);
    write(output.resolve("skipped-tests.json"), entries.stream().filter(e -> e.state().equals("skipped")).toList());
    write(output.resolve("repeated-identities.json"), entries.stream().filter(e -> e.executions() > 1).toList());
    System.out.println(JSON.toJson(summary));
    if (!whole.parseErrors().isEmpty() || whole.testCount() != wholeShape.testcaseElements()
        || math.testCount() != mathShape.testcaseElements()
        || modules.values().stream().mapToInt(Counts::testExecutions).sum() != whole.testCount())
      throw new IllegalStateException("Incomplete or inconsistent XML inventory; inspect retained summary.");
  }

  private static Counts counts(JUnitXmlInventoryComparator.Inventory inventory) {
    long unique = inventory.states().keySet().stream().map(JUnitXmlInventoryComparator.TestStateKey::identity).distinct().count();
    return new Counts(inventory.reportFiles(), inventory.testCount(),
        inventory.count(JUnitXmlInventoryComparator.State.PASSED), inventory.count(JUnitXmlInventoryComparator.State.SKIPPED),
        inventory.count(JUnitXmlInventoryComparator.State.FAILURE), inventory.count(JUnitXmlInventoryComparator.State.ERROR),
        unique, inventory.states().size(), inventory.testCount() - unique, inventory.parseErrors());
  }

  /** Counts XML structure only; result states and identities come from the existing comparator. */
  private static Shape shape(Path directory) throws Exception {
    XMLInputFactory factory = XMLInputFactory.newFactory();
    factory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
    factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
    factory.setXMLResolver((publicId, systemId, baseUri, namespace) -> { throw new XMLStreamException("External XML resolution disabled"); });
    long suites = 0, wrappers = 0, testcases = 0;
    try (var paths = Files.walk(directory)) {
      for (Path file : paths.filter(Files::isRegularFile).filter(p -> p.toString().endsWith(".xml")).sorted().toList()) {
        try (var input = Files.newInputStream(file)) {
          var reader = factory.createXMLStreamReader(input);
          try {
            while (reader.hasNext()) if (reader.next() == XMLStreamConstants.START_ELEMENT) {
              switch (reader.getLocalName()) {
                case "testsuite" -> suites++;
                case "testsuites" -> wrappers++;
                case "testcase" -> testcases++;
              }
            }
          } finally { reader.close(); }
        }
      }
    }
    return new Shape(suites, wrappers, testcases);
  }

  private static void write(Path file, Object value) throws Exception {
    Files.writeString(file, JSON.toJson(value) + System.lineSeparator());
  }
}
