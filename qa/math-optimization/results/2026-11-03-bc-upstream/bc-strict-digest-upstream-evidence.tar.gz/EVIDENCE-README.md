# Bouncy Castle mathematics qualification

This evidence concerns the nine ordinary digest rewrites in five source files at
BC tag `r1rv85v2`, commit `854bd5c4286e1530132418906bf6175da7d9d83c`.
The mathematics patch is preserved verbatim; its SHA-256 is
`337a8c1c53b947e83f564f310b86b3289698f1a8eb137cd764936c573ca39411`.

`before-after-qualification.json` is the authoritative final summary when present.
`inventory-comparison/` contains the results of the unchanged shared Java
`JUnitXmlInventoryComparator`, with no allowed missing, added or renamed tests.
Core, Provider and Java-25 KDF inventories are compared separately so identical
names in different tasks cannot hide changes in multiplicity.

The original Gradle invocation completed with exit zero. The first refactored
invocation completed Core and Java-25 KDF tests, then was interrupted during the
Provider task. Its original running receipt and partial log are retained without
inventing an exit status. `after-attempt-interruption.json` records the observed
loss of the process. `after-provider-resume-receipt.json` records the separate
continuation of only the unfinished full Provider task, offline against the same
cache and without source, build configuration, test selection or JDK changes.
The completed Core tests are not rerun by that continuation.

`helper-coverage-before-after.json` is derived from actual Core JaCoCo reports.
All nine changed helper bodies have 100% instruction coverage in both variants.
Coverage is evidence of execution, not exhaustive proof over all input values.

`mr-runtime-evidence/` distinguishes ordinary test classpaths from the effective
Java-25 multi-release view of the packaged Provider JAR. The Provider JAR has
Java-9 overlays for SHA256Digest and LongDigest. They must not be described as
absent or byte-identical to the Java-8 root classes. Classpath replay is explicitly
identified as replay rather than instrumentation of the original test JVM.
Any additional packaged-JAR digest-vector checks are recorded separately from
the standard full Gradle/JUnit inventory.

The standard upstream PQC sampler includes vector zero and uses a time-based
offset to sample later vectors. Equal JUnit identity/state multisets therefore do
not establish identical sampled PQC vectors. The exhaustive `testFull` mode was
not selected. No qualification is claimed for unrelated PKIX, TLS, PGP, MLS or
mail products, other JDK versions, or the entire historical mathematics corpus.

Static bytecode metrics, test durations, and operation-model estimates are not a
runtime speedup or constant-time proof. Full source checkouts, dependency caches
and JDK binaries are omitted; their pinned identities and relevant file hashes
are retained. `SHA256SUMS` in the final archive checks every other retained file.
