# Bouncy Castle effective JAR and captured-classpath evidence

`receipt.json` describes the complete result and scope. It is an artifact and
resolution inspection; it does not assert that any in-progress/interrupted test
task has finished.

The two provider JARs contain Java-9 overlays for `SHA256Digest` and `LongDigest`.
Java 25 selects those entries when the provider JAR itself supplies the class.
All nine modified helper bodies retain the intended changes in that effective
view. Each helper has two fewer JVM instructions. The Java-8 and Java-9 views
have the same arithmetic helper bodies within a phase; the only differing
executable body is `SHA256Digest.newInstance(Digest)`, whose error-message string
concatenation uses the respective compilation target's strategy.

The captured ordinary Gradle classpaths select the compiled main outputs in
`core/test` and `prov/test`. `prov/test25` selects the Core JAR before the provider
JAR. The isolated class-loader reconstruction verifies the same source phase's
class bytes in each case, without initializing or exercising the digest classes.
This is a reconstruction from actual captured classpath order, not a recording of
the original test JVM's live `Class` objects.

Some files prefixed `after-worker-classpath-` contain a concurrently observed
baseline worker. The receipt classifies captures by their actual canonical paths,
not that prefix. Every original capture is retained under
`captured-worker-classpaths/`.

`baseline/` and `after/` preserve the effective class bytes extracted from each
existing JAR. The TSV inventories, raw `javap` listings, symbolic comparison,
analysis sources and exact commands are retained for inspection. Numeric
constant-pool indices and spacing are normalized while symbolic operands and
encoded instruction offsets remain visible.

No standalone provider-JAR-only full test run, runtime benchmark or cryptographic
constant-time qualification was performed by this inspection.

The separate `../provider-jar-kat/` evidence subsequently executes eight unchanged
official digest tests per phase against only the actual provider JAR and verifies
the live loaded-class identities. That targeted execution is additional to this
read-only artifact and classpath reconstruction.
