import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.jar.JarFile;
import java.util.zip.ZipFile;

/** Read-only inspection of existing artifacts and captured classpath order. */
public class RuntimeIdentityProbe {
    private static final String[] CLASSES = {"SHA1Digest", "SHA256Digest", "LongDigest", "MD4Digest", "MD5Digest"};
    private static String hash(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static int major(byte[] bytes) { return ((bytes[6] & 255) << 8) | (bytes[7] & 255); }
    public static void main(String[] args) throws Exception {
        Path base = Path.of(args[0]).toAbsolutePath();
        Path output = base.resolve("mr-runtime-evidence");
        Files.createDirectories(output);
        System.out.println("RUNTIME\t" + Runtime.version());
        for (String phase : List.of("baseline", "after")) {
            Path tree = base.resolve(phase.equals("baseline") ? "original" : "after");
            for (String module : List.of("core", "prov")) {
                Path file = tree.resolve(module + "/build/libs/" + (module.equals("core") ? "bccore" : "bcprov") + "-jdk18on-1.85.2.jar");
                System.out.println("JAR\t" + phase + "\t" + module + "\t" + file + "\t" + hash(Files.readAllBytes(file)));
                try (var jar = new JarFile(file.toFile(), false, ZipFile.OPEN_READ, Runtime.version())) {
                    for (String name : CLASSES) {
                        String entryName = "org/bouncycastle/crypto/digests/" + name + ".class";
                        var entry = jar.getJarEntry(entryName);
                        byte[] bytes;
                        try (var in = jar.getInputStream(entry)) { bytes = in.readAllBytes(); }
                        Path saved = output.resolve(phase + "/" + module + "/" + entryName);
                        Files.createDirectories(saved.getParent());
                        Files.write(saved, bytes);
                        System.out.println("EFFECTIVE\t" + phase + "\t" + module + "\t" + name + "\t" + entry.getRealName() + "\t" + hash(bytes) + "\t" + major(bytes) + "\t" + bytes.length);
                        var entries = jar.entries();
                        while (entries.hasMoreElements()) {
                            var candidate = entries.nextElement();
                            if (!candidate.getName().equals(entryName) && !(candidate.getName().startsWith("META-INF/versions/") && candidate.getName().endsWith("/" + entryName))) continue;
                            byte[] candidateBytes;
                            try (var in = jar.getInputStream(candidate)) { candidateBytes = in.readAllBytes(); }
                            System.out.println("ENTRY\t" + phase + "\t" + module + "\t" + name + "\t" + candidate.getName() + "\t" + hash(candidateBytes) + "\t" + major(candidateBytes) + "\t" + candidateBytes.length);
                        }
                    }
                }
            }
        }
        var captures = new ArrayList<Path>();
        try (var files = Files.list(base)) {
            files.filter(p -> p.getFileName().toString().matches("(?:baseline|after)-worker-classpath-[0-9]+\\.txt")).sorted().forEach(captures::add);
        }
        var seen = new HashSet<String>();
        for (Path capture : captures) {
            String text = Files.readString(capture).trim();
            String[] lines = text.split("\\R");
            if (lines.length != 2 || !lines[0].equals("-cp")) throw new IllegalArgumentException("Unexpected capture: " + capture);
            String cp = lines[1];
            String phase = cp.contains(base + "/after/") ? "after" : "baseline";
            String scope = cp.contains("/prov/build/classes/java/test25:") ? "prov/test25" : cp.contains("/prov/build/classes/java/test:") ? "prov/test" : "core/test";
            String digest = hash(Files.readAllBytes(capture));
            System.out.println("CAPTURE\t" + capture.getFileName() + "\t" + digest + "\t" + phase + "\t" + scope);
            if (!seen.add(cp)) continue;
            URL[] urls = java.util.Arrays.stream(cp.split(":"))
                    .map(Path::of).map(p -> { try { return p.toUri().toURL(); } catch (Exception e) { throw new RuntimeException(e); } }).toArray(URL[]::new);
            try (var loader = new URLClassLoader(urls, ClassLoader.getPlatformClassLoader())) {
                for (String name : CLASSES) {
                    String className = "org.bouncycastle.crypto.digests." + name;
                    String resource = className.replace('.', '/') + ".class";
                    Class<?> cls = Class.forName(className, false, loader);
                    byte[] bytes;
                    try (var in = loader.getResourceAsStream(resource)) { bytes = in.readAllBytes(); }
                    System.out.println("RESOLUTION\t" + phase + "\t" + scope + "\t" + capture.getFileName() + "\t" + name + "\t" + cls.getProtectionDomain().getCodeSource().getLocation() + "\t" + loader.getResource(resource) + "\t" + hash(bytes) + "\t" + major(bytes));
                }
            }
        }
    }
}
