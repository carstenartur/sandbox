import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** Compare existing javap code listings; no Bouncy Castle compilation or execution. */
public class CompareJavap {
    static final Pattern CLASS = Pattern.compile("^.*\\bclass ([^ ]+).*$");
    static String hash(byte[] b) throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b)); }
    static Map<String, String> methods(Path file) throws Exception {
        var result = new LinkedHashMap<String, String>();
        String currentClass = null, header = null;
        boolean code = false;
        var body = new ArrayList<String>();
        for (String line : Files.readAllLines(file)) {
            var cls = CLASS.matcher(line);
            boolean classHeader = !line.startsWith(" ") && cls.matches();
            boolean memberHeader = line.matches("^  \\S.*$");
            if (classHeader || memberHeader || line.equals("}")) {
                if (code) {
                    String previous = result.put(currentClass + " :: " + header, String.join("\n", body));
                    if (previous != null) throw new IllegalStateException("Duplicate method header");
                }
                body.clear(); code = false;
                if (classHeader) { currentClass = cls.group(1); header = null; }
                else if (memberHeader) header = line.trim();
            } else if (line.trim().equals("Code:")) code = true;
            else if (code && !line.isBlank()) body.add(line.trim().replaceAll("#[0-9]+", "#CP").replaceAll("\\s+", " "));
        }
        if (code) result.put(currentClass + " :: " + header, String.join("\n", body));
        if (result.isEmpty()) throw new IllegalStateException("No executable methods: " + file);
        return result;
    }
    static Map<String, Object> compare(Map<String, String> a, Map<String, String> b) throws Exception {
        if (!a.keySet().equals(b.keySet())) throw new IllegalStateException("Executable method inventories differ");
        var changes = new ArrayList<Map<String, Object>>();
        for (String key : a.keySet()) if (!a.get(key).equals(b.get(key))) {
            var item = new LinkedHashMap<String, Object>();
            item.put("method", key); item.put("before", a.get(key)); item.put("after", b.get(key));
            item.put("beforeSymbolicSha256", hash(a.get(key).getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            item.put("afterSymbolicSha256", hash(b.get(key).getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            changes.add(item);
        }
        return Map.of("executableMethodsCompared", a.size(), "changedCount", changes.size(), "changedMethods", changes);
    }
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);
        var methods = new LinkedHashMap<String, Map<String, String>>();
        var hashes = new LinkedHashMap<String, String>();
        for (String phase : List.of("baseline", "after")) for (String module : List.of("core", "prov")) {
            String key = phase + "-" + module;
            Path input = root.resolve(key + "-effective.javap.txt");
            methods.put(key, methods(input)); hashes.put(input.getFileName().toString(), hash(Files.readAllBytes(input)));
        }
        var result = new LinkedHashMap<String, Object>();
        result.put("scope", "Symbolic comparison of all executable bodies in actual built effective Java25 JAR views, including constructors and initializers.");
        result.put("normalization", "Remove numeric constant-pool indices while retaining javap symbolic comments; collapse horizontal whitespace. Encoded offsets and instruction operands retained. Debug metadata is absent from -c -p -s output.");
        result.put("inputSha256", hashes);
        result.put("coreBeforeAfter", compare(methods.get("baseline-core"), methods.get("after-core")));
        result.put("providerJava25BeforeAfter", compare(methods.get("baseline-prov"), methods.get("after-prov")));
        result.put("baselineCoreVersusProviderJava25", compare(methods.get("baseline-core"), methods.get("baseline-prov")));
        result.put("afterCoreVersusProviderJava25", compare(methods.get("after-core"), methods.get("after-prov")));
        Files.writeString(root.resolve("symbolic-method-comparison.json"), new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create().toJson(result) + "\n");
        System.out.println("Compared " + methods.get("baseline-core").size() + " methods in four artifact views.");
    }
}
