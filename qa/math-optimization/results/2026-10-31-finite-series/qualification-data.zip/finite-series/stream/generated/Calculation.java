public final class Calculation {public static int run(int n,int seed){return (new java.util.function.IntSupplier(){public int getAsInt(){
if(((long)(n) - (long)(0)) < 4096L){
return java.util.stream.IntStream.range(0,n).map(i->i*i+seed).sum();
}else{
java.math.BigInteger $series77_0_start = java.math.BigInteger.valueOf((long)(0));
java.math.BigInteger $series77_0_bound = java.math.BigInteger.valueOf((long)(n));
java.math.BigInteger $series77_0_count = $series77_0_bound.subtract($series77_0_start).subtract(java.math.BigInteger.ONE).signum()<0 ? java.math.BigInteger.ZERO : $series77_0_bound.subtract($series77_0_start).subtract(java.math.BigInteger.ONE).divide(new java.math.BigInteger("1")).add(java.math.BigInteger.ONE);
java.math.BigInteger $series77_0_after = $series77_0_start.add($series77_0_count.multiply(new java.math.BigInteger("1")));
if($series77_0_count.compareTo(new java.math.BigInteger("4096"))>=0){
java.math.BigInteger $series77_0_result0 = new java.math.BigInteger("0");
java.math.BigInteger $series77_0_choose0 = java.math.BigInteger.ONE;
$series77_0_choose0 = $series77_0_choose0.multiply($series77_0_count.subtract(new java.math.BigInteger("0"))).divide(new java.math.BigInteger("1"));
$series77_0_result0 = $series77_0_result0.add((($series77_0_start).multiply($series77_0_start)).multiply(new java.math.BigInteger("1")).add((java.math.BigInteger.valueOf((long)(seed))).multiply(new java.math.BigInteger("1"))).multiply($series77_0_choose0));
$series77_0_choose0 = $series77_0_choose0.multiply($series77_0_count.subtract(new java.math.BigInteger("1"))).divide(new java.math.BigInteger("2"));
$series77_0_result0 = $series77_0_result0.add((new java.math.BigInteger("1")).multiply(new java.math.BigInteger("1")).add(((new java.math.BigInteger("2")).multiply($series77_0_start)).multiply(new java.math.BigInteger("1"))).multiply($series77_0_choose0));
$series77_0_choose0 = $series77_0_choose0.multiply($series77_0_count.subtract(new java.math.BigInteger("2"))).divide(new java.math.BigInteger("3"));
$series77_0_result0 = $series77_0_result0.add(new java.math.BigInteger("2").multiply($series77_0_choose0));
return $series77_0_result0.intValue();
}else{
return java.util.stream.IntStream.range(0,n).map(i->i*i+seed).sum();
}
}
}}).getAsInt();}}
