public final class Calculation {public static int run(int n,int seed){return java.util.stream.IntStream.range(0,n).map(i->i*i+seed).sum();}}
