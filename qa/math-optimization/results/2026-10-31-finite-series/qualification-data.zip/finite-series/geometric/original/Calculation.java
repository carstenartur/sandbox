public final class Calculation {public static int run(int n,int seed){int sum=seed;int power=1;for(int i=0;i<n;i++){sum+=power;power*=3;}return sum+power;}}
