public final class Calculation {public static int run(int n,int seed){int sum=seed;int power=1;{
if(((long)(n) - (long)(0)) < 8192L){
for(int i=0;i<n;i++){sum+=power;power*=3;}
}else{
java.math.BigInteger $series95_0_start = java.math.BigInteger.valueOf((long)(0));
java.math.BigInteger $series95_0_bound = java.math.BigInteger.valueOf((long)(n));
java.math.BigInteger $series95_0_count = $series95_0_bound.subtract($series95_0_start).subtract(java.math.BigInteger.ONE).signum()<0 ? java.math.BigInteger.ZERO : $series95_0_bound.subtract($series95_0_start).subtract(java.math.BigInteger.ONE).divide(new java.math.BigInteger("1")).add(java.math.BigInteger.ONE);
java.math.BigInteger $series95_0_after = $series95_0_start.add($series95_0_count.multiply(new java.math.BigInteger("1")));
if($series95_0_count.compareTo(new java.math.BigInteger("8192"))>=0 && $series95_0_after.compareTo(new java.math.BigInteger("-2147483648"))>=0 && $series95_0_after.compareTo(new java.math.BigInteger("2147483647"))<=0){
java.math.BigInteger[][] $series95_0_matrix = new java.math.BigInteger[][]{{new java.math.BigInteger("1"),new java.math.BigInteger("1"),new java.math.BigInteger("0")},{new java.math.BigInteger("0"),new java.math.BigInteger("3"),new java.math.BigInteger("0")},{new java.math.BigInteger("0"),new java.math.BigInteger("0"),new java.math.BigInteger("1")}};
java.math.BigInteger[] $series95_0_vector = new java.math.BigInteger[]{(new java.math.BigInteger("1")).multiply(java.math.BigInteger.valueOf((long)(sum))),(new java.math.BigInteger("1")).multiply(java.math.BigInteger.valueOf((long)(power))),new java.math.BigInteger("1")};
java.math.BigInteger $series95_0_modulus=java.math.BigInteger.ONE.shiftLeft(32);
java.math.BigInteger $series95_0_exponent=$series95_0_count;
while($series95_0_exponent.signum()>0){
if($series95_0_exponent.testBit(0)){
java.math.BigInteger[] $series95_0_next=new java.math.BigInteger[3];
for(int $series95_0_r=0;$series95_0_r<3;$series95_0_r++){ $series95_0_next[$series95_0_r]=java.math.BigInteger.ZERO;for(int $series95_0_c=0;$series95_0_c<3;$series95_0_c++) $series95_0_next[$series95_0_r]=$series95_0_next[$series95_0_r].add($series95_0_matrix[$series95_0_r][$series95_0_c].multiply($series95_0_vector[$series95_0_c])).mod($series95_0_modulus);}
$series95_0_vector=$series95_0_next;}
$series95_0_exponent=$series95_0_exponent.shiftRight(1);if($series95_0_exponent.signum()>0){
java.math.BigInteger[][] $series95_0_square=new java.math.BigInteger[3][3];
for(int $series95_0_r=0;$series95_0_r<3;$series95_0_r++)for(int $series95_0_c=0;$series95_0_c<3;$series95_0_c++){ $series95_0_square[$series95_0_r][$series95_0_c]=java.math.BigInteger.ZERO;for(int $series95_0_k=0;$series95_0_k<3;$series95_0_k++) $series95_0_square[$series95_0_r][$series95_0_c]=$series95_0_square[$series95_0_r][$series95_0_c].add($series95_0_matrix[$series95_0_r][$series95_0_k].multiply($series95_0_matrix[$series95_0_k][$series95_0_c])).mod($series95_0_modulus);}
$series95_0_matrix=$series95_0_square;}}
sum = $series95_0_vector[0].intValue();
power = $series95_0_vector[1].intValue();
}else{
for(int i=0;i<n;i++){sum+=power;power*=3;}
}
}
}return sum+power;}}
