public final class Calculation {public static int run(int n,int seed){int sum=seed;{
if(((long)(n) - (long)(0)) < 4096L){
for(int i=0;i<n;i++)sum+=i*i;
}else{
java.math.BigInteger $series83_0_start = java.math.BigInteger.valueOf((long)(0));
java.math.BigInteger $series83_0_bound = java.math.BigInteger.valueOf((long)(n));
java.math.BigInteger $series83_0_count = $series83_0_bound.subtract($series83_0_start).subtract(java.math.BigInteger.ONE).signum()<0 ? java.math.BigInteger.ZERO : $series83_0_bound.subtract($series83_0_start).subtract(java.math.BigInteger.ONE).divide(new java.math.BigInteger("1")).add(java.math.BigInteger.ONE);
java.math.BigInteger $series83_0_after = $series83_0_start.add($series83_0_count.multiply(new java.math.BigInteger("1")));
if($series83_0_count.compareTo(new java.math.BigInteger("4096"))>=0 && $series83_0_after.compareTo(new java.math.BigInteger("-2147483648"))>=0 && $series83_0_after.compareTo(new java.math.BigInteger("2147483647"))<=0){
java.math.BigInteger $series83_0_result0 = java.math.BigInteger.valueOf((long)(sum));
java.math.BigInteger $series83_0_choose0 = java.math.BigInteger.ONE;
$series83_0_choose0 = $series83_0_choose0.multiply($series83_0_count.subtract(new java.math.BigInteger("0"))).divide(new java.math.BigInteger("1"));
$series83_0_result0 = $series83_0_result0.add(($series83_0_start).multiply($series83_0_start).multiply($series83_0_choose0));
$series83_0_choose0 = $series83_0_choose0.multiply($series83_0_count.subtract(new java.math.BigInteger("1"))).divide(new java.math.BigInteger("2"));
$series83_0_result0 = $series83_0_result0.add((new java.math.BigInteger("1")).multiply(new java.math.BigInteger("1")).add(((new java.math.BigInteger("2")).multiply($series83_0_start)).multiply(new java.math.BigInteger("1"))).multiply($series83_0_choose0));
$series83_0_choose0 = $series83_0_choose0.multiply($series83_0_count.subtract(new java.math.BigInteger("2"))).divide(new java.math.BigInteger("3"));
$series83_0_result0 = $series83_0_result0.add(new java.math.BigInteger("2").multiply($series83_0_choose0));
sum = $series83_0_result0.intValue();
}else{
for(int i=0;i<n;i++)sum+=i*i;
}
}
}return sum;}}
