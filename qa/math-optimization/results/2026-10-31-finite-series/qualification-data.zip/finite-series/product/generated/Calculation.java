public final class Calculation {public static int run(int n,int seed){int sum=seed;{
if(((long)(n) - (long)(0)) < 4096L){
for(int i=0;i<n;i++)sum*=3;
}else{
java.math.BigInteger $series83_0_start = java.math.BigInteger.valueOf((long)(0));
java.math.BigInteger $series83_0_bound = java.math.BigInteger.valueOf((long)(n));
java.math.BigInteger $series83_0_count = $series83_0_bound.subtract($series83_0_start).subtract(java.math.BigInteger.ONE).signum()<0 ? java.math.BigInteger.ZERO : $series83_0_bound.subtract($series83_0_start).subtract(java.math.BigInteger.ONE).divide(new java.math.BigInteger("1")).add(java.math.BigInteger.ONE);
java.math.BigInteger $series83_0_after = $series83_0_start.add($series83_0_count.multiply(new java.math.BigInteger("1")));
if($series83_0_count.compareTo(new java.math.BigInteger("4096"))>=0 && $series83_0_after.compareTo(new java.math.BigInteger("-2147483648"))>=0 && $series83_0_after.compareTo(new java.math.BigInteger("2147483647"))<=0){
java.math.BigInteger[][] $series83_0_matrix = new java.math.BigInteger[][]{{new java.math.BigInteger("3"),new java.math.BigInteger("0")},{new java.math.BigInteger("0"),new java.math.BigInteger("1")}};
java.math.BigInteger[] $series83_0_vector = new java.math.BigInteger[]{(new java.math.BigInteger("1")).multiply(java.math.BigInteger.valueOf((long)(sum))),new java.math.BigInteger("1")};
java.math.BigInteger $series83_0_modulus=java.math.BigInteger.ONE.shiftLeft(32);
java.math.BigInteger $series83_0_exponent=$series83_0_count;
while($series83_0_exponent.signum()>0){
if($series83_0_exponent.testBit(0)){
java.math.BigInteger[] $series83_0_next=new java.math.BigInteger[2];
for(int $series83_0_r=0;$series83_0_r<2;$series83_0_r++){ $series83_0_next[$series83_0_r]=java.math.BigInteger.ZERO;for(int $series83_0_c=0;$series83_0_c<2;$series83_0_c++) $series83_0_next[$series83_0_r]=$series83_0_next[$series83_0_r].add($series83_0_matrix[$series83_0_r][$series83_0_c].multiply($series83_0_vector[$series83_0_c])).mod($series83_0_modulus);}
$series83_0_vector=$series83_0_next;}
$series83_0_exponent=$series83_0_exponent.shiftRight(1);if($series83_0_exponent.signum()>0){
java.math.BigInteger[][] $series83_0_square=new java.math.BigInteger[2][2];
for(int $series83_0_r=0;$series83_0_r<2;$series83_0_r++)for(int $series83_0_c=0;$series83_0_c<2;$series83_0_c++){ $series83_0_square[$series83_0_r][$series83_0_c]=java.math.BigInteger.ZERO;for(int $series83_0_k=0;$series83_0_k<2;$series83_0_k++) $series83_0_square[$series83_0_r][$series83_0_c]=$series83_0_square[$series83_0_r][$series83_0_c].add($series83_0_matrix[$series83_0_r][$series83_0_k].multiply($series83_0_matrix[$series83_0_k][$series83_0_c])).mod($series83_0_modulus);}
$series83_0_matrix=$series83_0_square;}}
sum = $series83_0_vector[0].intValue();
}else{
for(int i=0;i<n;i++)sum*=3;
}
}
}return sum;}}
