public final class Calculation {public static int run(int n,int seed){int sum=seed;for(int i=0;i<n;i++)sum*=3;return sum;}}
