# Data archive contents

These are data and receipts for the public source revision in `provenance.json`.
The maintained harness and product implementation are ordinary reviewed Java
sources in that revision, not hidden in this archive. `SHA256SUMS` covers every
other file in this archive using relative paths.

- `finite-series/`: exact complete original/generated source fixtures, options,
  independent preparation observations, implementation/source receipts and hashes.
- `finite-series-jmh.json`: unmodified final JMH JSON, including every raw latency
  and GC sample and the measured fixture-manifest hash parameter.
- `finite-series-performance.json`: final v2 report; all 20 rows share the same
  environment, and means/99.9% intervals are reconstructed from all ten samples.
- `finite-series-host.json`, `finite-series-cpu-quota.txt`: recorded host view.
- `bc-current/`: both raw final scan reviews, manifests, completion markers and
  all 58/62 generated complete source files. Original archive sources and the
  scanner's separate nested proof-transport files are not duplicated here.
- `bc-baseline/`: exact remote raw JMH and performance-review JSON, scan manifests
  and completion markers. The full 25,477,494-byte Actions artifact is identified
  by workflow URL, artifact ID and SHA-256 in `provenance.json`, not copied here.
- `bc-*/bc-*/retention-index.json`: clearly labelled projections of each raw review
  for comparing inputs, accepted source spans and parse errors. These projections
  are derived evidence, not substitutes for the raw reviews.
- `retention/`: matched before/after inspection results.
- `logs/`: final preparation, JMH, BC scans and targeted tests, the preceding
  full-suite observation and failed discovery attempt, and regression RED evidence.
- `history/preliminary-v1-7fcadd0.zip`: original pre-fix exploratory evidence,
  retained unchanged. It lacks the hardened v2 measured-manifest binding and is
  not a final performance claim. Do not relabel its report or mix its samples into
  the final run.

BC-derived sources retain the upstream license in `BOUNCY-CASTLE-LICENSE.md`.
The corpus scans qualify source analysis and exact Apply/Undo; they do not qualify
whole-library behavior or cryptographic constant-time properties. The finite-series
GC profiler includes trial-end hash/cleanup work outside primary latency timing,
so its allocation values cannot support candidate-allocation comparisons.
