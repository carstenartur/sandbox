package org.bouncycastle.crypto.generators;

import java.math.BigInteger;
import java.security.SecureRandom;

import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.params.CramerShoupParameters;
import org.bouncycastle.crypto.params.DHParameters;
import org.bouncycastle.util.BigIntegers;

public class CramerShoupParametersGenerator
{
    private static final BigInteger ONE = BigInteger.valueOf(1);

    private int size;
    private int certainty;
    private SecureRandom random;

    /**
     * Initialise the parameters generator.
     *
     * @param size      bit length for the prime p
     * @param certainty a measure of the uncertainty that the caller is willing to tolerate:
     *                  the probability that the generated modulus is prime exceeds (1 - 1/2^certainty).
     *                  The execution time of this method is proportional to the value of this parameter.
     * @param random    a source of randomness
     */
    public void init(int size, int certainty, SecureRandom random)
    {
        this.size = size;
        this.certainty = certainty;
        this.random = random;
    }

    /**
     * which generates the p and g values from the given parameters, returning
     * the CramerShoupParameters object.
     * <p>
     * Note: can take a while...
     * </p>
     * @return a generated CramerShoupParameters object.
     */
    public CramerShoupParameters generateParameters()
    {
        //
        // find a safe prime p where p = 2*q + 1, where p and q are prime.
        //
        BigInteger[] safePrimes = ParametersHelper.generateSafePrimes(size, certainty, random);

//        BigInteger p = safePrimes[0];
        BigInteger q = safePrimes[1];
        BigInteger g1 = ParametersHelper.selectGenerator(q, random);
        BigInteger g2 = ParametersHelper.selectGenerator(q, random);
        while (g1.equals(g2))
        {
            g2 = ParametersHelper.selectGenerator(q, random);
        }

        return new CramerShoupParameters(q, g1, g2, SHA256Digest.newInstance());
    }

    public CramerShoupParameters generateParameters(DHParameters dhParams)
    {
        BigInteger p = dhParams.getP();
        BigInteger g1 = dhParams.getG();

        // now we just need a second generator
        BigInteger g2 = ParametersHelper.selectGenerator(p, random);
        while (g1.equals(g2))
        {
            g2 = ParametersHelper.selectGenerator(p, random);
        }

        return new CramerShoupParameters(p, g1, g2, SHA256Digest.newInstance());
    }

    private static class ParametersHelper
    {

        private static final BigInteger TWO = BigInteger.valueOf(2);

        /*
         * Finds a pair of prime BigInteger's {p, q: p = 2q + 1}
         *
         * (see: Handbook of Applied Cryptography 4.86)
         */
        static BigInteger[] generateSafePrimes(int size, int certainty, SecureRandom random)
        {
            return DHParametersHelper.generateSafePrimes(size, certainty, random, false);
        }

        /**
         * <p><strong>Mathematics cleanup:</strong> BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.</p>
         */
        static BigInteger selectGenerator(BigInteger p, SecureRandom random)
        {
            BigInteger pMinusTwo = p.subtract(TWO);
            BigInteger g;

            /*
             * RFC 2631 2.2.1.2 (and see: Handbook of Applied Cryptography 4.81)
             */
            do
            {
                BigInteger h = BigIntegers.createRandomInRange(TWO, pMinusTwo, random);

                // Verified mathematics (MATHEMATICAL).
                // BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.
                // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(h, 4096).
                // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(p, 4096).
                // Premise: BIG_INTEGER_VALUE_SEMANTICS(h).
                // Premise: BIG_INTEGER_VALUE_SEMANTICS(p).
                // Premise: POSITIVE(p).
                // Retain exact-receiver, non-null and magnitude guards for: TWO, h, p.
                // Original values:
                // g = (h.modPow(new java.math.BigInteger("2"), p));
                // Replacement values:
                // g = h.multiply(h).mod(p);
                // Recorded search path:
                // Search step 1/1 [modpow-small-binary-chain]:
                // g = (h.multiply(h).mod(p));
                // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
                // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
                // Independent numeric proof: AFFINE_MODULAR_NORMAL_FORM.
                // Estimated operation work: 36 -> 10; not a timing measurement.
                if ((TWO != null && TWO.getClass() == java.math.BigInteger.class && TWO.bitLength() < 4096) && (h != null && h.getClass() == java.math.BigInteger.class && h.bitLength() < 4096) && (p != null && p.getClass() == java.math.BigInteger.class && p.bitLength() < 4096 && p.signum() > 0)) {
                g = h.multiply(h).mod(p);
                } else {
                // Mathematics fallback: unchanged original Java behavior.
                g = h.modPow(TWO, p);
                }
            }
            while (g.equals(ONE));

            return g;
        }
    }

}
