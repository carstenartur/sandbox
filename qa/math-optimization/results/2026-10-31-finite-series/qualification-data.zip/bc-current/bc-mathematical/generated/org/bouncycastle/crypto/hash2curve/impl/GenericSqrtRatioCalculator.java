package org.bouncycastle.crypto.hash2curve.impl;

import java.math.BigInteger;

import org.bouncycastle.crypto.hash2curve.H2cUtils;
import org.bouncycastle.crypto.hash2curve.SqrtRatioCalculator;
import org.bouncycastle.math.ec.ECCurve;

/**
 * Generic implementation of the sqrt_ratio(u, v) operation defined in RFC 9380.
 *
 * <p>
 * This computes a square root of u/v in the prime field Fp associated with an elliptic curve, when
 * such a square root exists, and otherwise returns a valid square root of z·u/v for a fixed
 * quadratic non-residue z. This function is a required component of all map-to-curve constructions
 * in RFC 9380, including the Simplified SWU and Elligator 2 maps.
 * </p>
 *
 * <p>
 * RFC 9380 defines optimized sqrt_ratio formulas for certain curves where the field prime p
 * satisfies special congruences (e.g. p ≡ 3 mod 4 or p ≡ 5 mod 8). However, those optimizations are
 * curve-specific and do not apply to all hash-to-curve suites. This implementation instead follows
 * the fully generic algorithm from Section 5.6.3 of RFC 9380, which is valid for any elliptic curve
 * defined over a prime field Fp.
 * </p>
 *
 * <p>
 * This generic version supports all curves used in the RFC 9830 test vectors, including the NIST
 * P-256 / P-384 / P-521 curves, Curve25519, Edwards25519 (Ristretto255), Curve448, and Edwards448
 * (Decaf448). It provides a single uniform implementation suitable for all supported hash-to-curve
 * suites.
 * </p>
 */
public class GenericSqrtRatioCalculator implements SqrtRatioCalculator
{
    /** The elliptic curve for the instance */
//    private final ECCurve curve;
    /** A non-square element of F */
//    private final BigInteger z;

    private final BigInteger q;

    private final int c1;
    private final BigInteger c2, c3, c4, c5, c6, c7;

    /**
     * Constructs a {@code GenericSqrtRatioCalculator} instance with the specified elliptic curve and a
     * given value z.
     *
     * @param curve the elliptic curve over a finite field to be used for square root and ratio
     * calculations
     * @param z a non-square element of F
     */
    public GenericSqrtRatioCalculator(final ECCurve curve, final BigInteger z)
    {
//        this.curve = curve;
        this.q = curve.getField().getCharacteristic();
//        this.z = z;
        this.c1 = this.calculateC1();

        this.c2 = this.q.subtract(BigInteger.ONE).divide(BigInteger.valueOf(2).pow(this.c1));
        this.c3 = this.c2.subtract(BigInteger.ONE).divide(BigInteger.valueOf(2));
        this.c4 = BigInteger.valueOf(2).pow(this.c1).subtract(BigInteger.ONE);
        this.c5 = BigInteger.valueOf(2).pow(this.c1 - 1);
        this.c6 = z.modPow(this.c2, this.q);
        this.c7 = z.modPow(this.c2.add(BigInteger.ONE).divide(BigInteger.valueOf(2)), q);
    }

    private int calculateC1()
    {
        BigInteger qMinusOne = this.q.subtract(BigInteger.ONE);
        int c1 = 0;
        while (qMinusOne.mod(BigInteger.valueOf(2)).equals(BigInteger.ZERO))
        {
            qMinusOne = qMinusOne.divide(BigInteger.valueOf(2));
            c1++;
        }
        return c1;
    }

    /**
     * <p><strong>Mathematics cleanup:</strong> BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.</p>
     *  {@inheritDoc} */
    public SqrtRatio sqrtRatio(final BigInteger u, final BigInteger v)
    {

        // Verified mathematics (MATHEMATICAL).
        // BigInteger numerical values are preserved; result reference identity may change. Where receivers are unproved, the optimized branch requires exact BigInteger instances with bitLength() below 4096 and positive guarded moduli or exponents; signed bases are allowed. Otherwise the original calculation executes. No extension of the BigInteger value range or constant-time execution is claimed.
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(c6, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(v, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(c4, 4096).
        // Premise: BIG_INTEGER_BIT_LENGTH_BOUND(q, 4096).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(c6).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(v).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(c4).
        // Premise: BIG_INTEGER_VALUE_SEMANTICS(q).
        // Premise: POSITIVE(c4).
        // Premise: POSITIVE(q).
        // Retain exact-receiver, non-null and magnitude guards for: c4, c6, q, v.
        // Original values:
        // final java.math.BigInteger _math0 = v.modPow(c4, q);
        // tv1 = c6;
        // tv2 = _math0;
        // tv3 = (((_math0.modPow(new java.math.BigInteger("2"), q)).multiply(v)).mod(q));
        // Replacement values:
        // final java.math.BigInteger _math0 = v.modPow(c4, q);
        // tv1 = c6;
        // tv2 = _math0;
        // tv3 = _math0.multiply(_math0).multiply(v).mod(q);
        // Recorded search path:
        // Search step 1/2 [modpow-small-binary-chain]:
        // final java.math.BigInteger _math0 = v.modPow(c4, q);
        // tv1 = c6;
        // tv2 = _math0;
        // tv3 = ((_math0.multiply(_math0).mod(q)).multiply(v).mod(q));
        // Search step 2/2 [mod-arithmetic-inner-reductions]:
        // final java.math.BigInteger _math0 = v.modPow(c4, q);
        // tv1 = c6;
        // tv2 = _math0;
        // tv3 = (((_math0.multiply(_math0)).multiply(v)).mod(q));
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: TYPED_STRUCTURAL_IDENTITY, AFFINE_MODULAR_NORMAL_FORM.
        // Estimated operation work: 1044 -> 1012; not a timing measurement.
        BigInteger tv1;
        BigInteger tv2;
        BigInteger tv3;
        if ((c4 != null && c4.getClass() == java.math.BigInteger.class && c4.bitLength() < 4096 && c4.signum() > 0) && (c6 != null && c6.getClass() == java.math.BigInteger.class && c6.bitLength() < 4096) && (q != null && q.getClass() == java.math.BigInteger.class && q.bitLength() < 4096 && q.signum() > 0) && (v != null && v.getClass() == java.math.BigInteger.class && v.bitLength() < 4096)) {
        final java.math.BigInteger _math0 = v.modPow(c4, q);
        tv1 = c6;
        tv2 = _math0;
        tv3 = _math0.multiply(_math0).multiply(v).mod(q);
        } else {
        // Mathematics fallback: unchanged original Java behavior.
        tv1 = this.c6;
        tv2 = v.modPow(this.c4, this.q);
        tv3 = tv2.modPow(BigInteger.valueOf(2), this.q);
        tv3 = tv3.multiply(v).mod(this.q);
        }
        BigInteger tv5 = u.multiply(tv3).mod(this.q);
        tv5 = tv5.modPow(this.c3, this.q);
        tv5 = tv5.multiply(tv2).mod(this.q);
        tv2 = tv5.multiply(v).mod(this.q);
        tv3 = tv5.multiply(u).mod(this.q);
        BigInteger tv4 = tv3.multiply(tv2).mod(this.q);
        tv5 = tv4.modPow(this.c5, this.q);
        final boolean isQR = tv5.equals(BigInteger.ONE);
        tv2 = tv3.multiply(this.c7).mod(this.q);
        tv5 = tv4.multiply(tv1).mod(this.q);
        tv3 = H2cUtils.cmov(tv2, tv3, isQR);
        tv4 = H2cUtils.cmov(tv5, tv4, isQR);
        for (int i = this.c1; i >= 2; i--)
        {
            tv5 = BigInteger.valueOf(i - 2);
            tv5 = BigInteger.valueOf(2).pow(tv5.intValue());
            tv5 = tv4.modPow(tv5, this.q);
            final boolean e1 = tv5.equals(BigInteger.ONE);
            tv2 = tv3.multiply(tv1).mod(this.q);
            tv1 = tv1.multiply(tv1).mod(this.q);
            tv5 = tv4.multiply(tv1).mod(this.q);
            tv3 = H2cUtils.cmov(tv2, tv3, e1);
            tv4 = H2cUtils.cmov(tv5, tv4, e1);
        }
        return new SqrtRatio(isQR, tv3);
    }
}
