package org.bouncycastle.math.ec.rfc7748;

import org.bouncycastle.math.raw.Mod;

public abstract class X25519Field
{
    public static final int SIZE = 10;

    private static final int M24 = 0x00FFFFFF;
    private static final int M25 = 0x01FFFFFF;
    private static final int M26 = 0x03FFFFFF;

    private static final int[] P32 = new int[]{ 0xFFFFFFED, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF,
        0xFFFFFFFF, 0x7FFFFFFF };
    private static final int[] ROOT_NEG_ONE = new int[]{ -0x01F15F50, -0x0079362D, 0x00478C4F, 0x0035697F, 0x005E8630,
        0x01FBD7A7, -0x00BFD9B1, -0x000F4D4B, 0x00027E0F, 0x00570649 };

    protected X25519Field() {}

    public static void add(int[] x, int[] y, int[] z)
    {
        for (int i = 0; i < SIZE; ++i)
        {
            z[i] = x[i] + y[i];
        }
    }

    public static void addOne(int[] z)
    {
        z[0] += 1;
    }

    public static void addOne(int[] z, int zOff)
    {
        z[zOff] += 1;
    }

    public static void apm(int[] x, int[] y, int[] zp, int[] zm)
    {
        for (int i = 0; i < SIZE; ++i)
        {
            int xi = x[i], yi = y[i];
            zp[i] = xi + yi;
            zm[i] = xi - yi;
        }
    }

    public static int areEqual(int[] x, int[] y)
    {
        int d = 0;
        for (int i = 0; i < SIZE; ++i)
        {
            d |= x[i] ^ y[i];
        }
        return ((d - 1) & ~d) >> 31;
    }

    public static boolean areEqualVar(int[] x, int[] y)
    {
        return 0 != areEqual(x, y);
    }

    public static void carry(int[] z)
    {
        int z0 = z[0], z1 = z[1], z2 = z[2], z3 = z[3], z4 = z[4];
        int z5 = z[5], z6 = z[6], z7 = z[7], z8 = z[8], z9 = z[9];

        z2 += (z1 >> 26); z1 &= M26;
        z4 += (z3 >> 26); z3 &= M26;
        z7 += (z6 >> 26); z6 &= M26;
        z9 += (z8 >> 26); z8 &= M26;

        z3 += (z2 >> 25); z2 &= M25;
        z5 += (z4 >> 25); z4 &= M25;
        z8 += (z7 >> 25); z7 &= M25;
//        z0 += (z9 >> 24) * 19; z9 &= M24;
        z0 += (z9 >> 25) * 38; z9 &= M25;

        z1 += (z0 >> 26); z0 &= M26;
        z6 += (z5 >> 26); z5 &= M26;

        z2 += (z1 >> 26); z1 &= M26;
        z4 += (z3 >> 26); z3 &= M26;
        z7 += (z6 >> 26); z6 &= M26;
        z9 += (z8 >> 26); z8 &= M26;

        z[0] = z0; z[1] = z1; z[2] = z2; z[3] = z3; z[4] = z4;
        z[5] = z5; z[6] = z6; z[7] = z7; z[8] = z8; z[9] = z9;
    }

    public static void cmov(int cond, int[] x, int xOff, int[] z, int zOff)
    {
//        assert 0 == cond || -1 == cond;

        for (int i = 0; i < SIZE; ++i)
        {
            int z_i = z[zOff + i], diff = z_i ^ x[xOff + i];
            z_i ^= (diff & cond);
            z[zOff + i] = z_i;
        }
    }

    public static void cnegate(int negate, int[] z)
    {
//      assert negate >>> 1 == 0;

        int mask = 0 - negate;
        for (int i = 0; i < SIZE; ++i)
        {
            z[i] = (z[i] ^ mask) - mask;
        }
    }

    public static void copy(int[] x, int xOff, int[] z, int zOff)
    {
        for (int i = 0; i < SIZE; ++i)
        {
            z[zOff + i] = x[xOff + i];
        }
    }

    public static int[] create()
    {
        return new int[SIZE];
    }

    public static int[] createTable(int n)
    {
        return new int[SIZE * n];
    }

    public static void cswap(int swap, int[] a, int[] b)
    {
//        assert swap >>> 1 == 0;
//        assert a != b;

        int mask = 0 - swap;
        for (int i = 0; i < SIZE; ++i)
        {
            int ai = a[i], bi = b[i];
            int dummy = mask & (ai ^ bi);
            a[i] = ai ^ dummy; 
            b[i] = bi ^ dummy; 
        }
    }

    /** @deprecated Use {@link #decode255(byte[], int[])} instead. */
    public static void decode(byte[] x, int[] z)
    {
        decode255(x, 0, z, 0);
    }

    /** @deprecated Use {@link #decode255(byte[], int, int[], int)} instead. */
    public static void decode(byte[] x, int xOff, int[] z)
    {
        decode255(x, xOff, z, 0);
    }

    /** @deprecated Use {@link #decode255(byte[], int, int[], int)} instead. */
    public static void decode(byte[] x, int xOff, int[] z, int zOff)
    {
        decode255(x, xOff, z, zOff);
    }

    /** @deprecated Use {@link #decode255(int[], int, int[], int)} instead. */
    public static void decode(int[] x, int xOff, int[] z)
    {
        decode255(x, xOff, z, 0);
    }

    private static void decode128(int[] is, int off, int[] z, int zOff)
    {
        int t0 = is[off + 0], t1 = is[off + 1], t2 = is[off + 2], t3 = is[off + 3];

        z[zOff + 0] = t0 & M26;
        z[zOff + 1] = ((t1 <<  6) | (t0 >>> 26)) & M26;
        z[zOff + 2] = ((t2 << 12) | (t1 >>> 20)) & M25;
        z[zOff + 3] = ((t3 << 19) | (t2 >>> 13)) & M26;
        z[zOff + 4] = t3 >>> 7;
    }

    private static void decode128(byte[] bs, int off, int[] z, int zOff)
    {
        int t0 = decode32(bs, off + 0);
        int t1 = decode32(bs, off + 4);
        int t2 = decode32(bs, off + 8);
        int t3 = decode32(bs, off + 12);

        z[zOff + 0] = t0 & M26;
        z[zOff + 1] = ((t1 <<  6) | (t0 >>> 26)) & M26;
        z[zOff + 2] = ((t2 << 12) | (t1 >>> 20)) & M25;
        z[zOff + 3] = ((t3 << 19) | (t2 >>> 13)) & M26;
        z[zOff + 4] = t3 >>> 7;
    }

    public static void decode255(byte[] x, int[] z)
    {
        decode255(x, 0, z, 0);
    }

    public static void decode255(byte[] x, int xOff, int[] z, int zOff)
    {
        decode128(x, xOff, z, zOff);
        decode128(x, xOff + 16, z, zOff + 5);
        z[zOff + 9] &= M24;
    }

    public static void decode255(int[] x, int[] z)
    {
        decode255(x, 0, z, 0);
    }

    public static void decode255(int[] x, int xOff, int[] z, int zOff)
    {
        decode128(x, xOff, z, zOff);
        decode128(x, xOff + 4, z, zOff + 5);
        z[zOff + 9] &= M24;
    }

    static int decode32(byte[] bs, int off)
    {
        int n = bs[off] & 0xFF;
        n |= (bs[++off] & 0xFF) << 8;
        n |= (bs[++off] & 0xFF) << 16;
        n |=  bs[++off]         << 24;
        return n;
    }

    public static void encode(int[] x, int[] z, int zOff)
    {
        encode128(x, 0, z, zOff);
        encode128(x, 5, z, zOff + 4);
    }

    public static void encode(int[] x, byte[] z)
    {
        encode128(x, 0, z, 0);
        encode128(x, 5, z, 16);
    }

    public static void encode(int[] x, byte[] z, int zOff)
    {
        encode128(x, 0, z, zOff);
        encode128(x, 5, z, zOff + 16);
    }

    public static void encode(int[] x, int xOff, byte[] z, int zOff)
    {
        encode128(x, xOff, z, zOff);
        encode128(x, xOff + 5, z, zOff + 16);
    }

    private static void encode128(int[] x, int xOff, int[] is, int off)
    {
        int x0 = x[xOff + 0], x1 = x[xOff + 1], x2 = x[xOff + 2], x3 = x[xOff + 3], x4 = x[xOff + 4];

        is[off + 0] =  x0         | (x1 << 26);
        is[off + 1] = (x1 >>>  6) | (x2 << 20);
        is[off + 2] = (x2 >>> 12) | (x3 << 13);
        is[off + 3] = (x3 >>> 19) | (x4 <<  7);
    }

    private static void encode128(int[] x, int xOff, byte[] bs, int off)
    {
        int x0 = x[xOff + 0], x1 = x[xOff + 1], x2 = x[xOff + 2], x3 = x[xOff + 3], x4 = x[xOff + 4];

        int t0 =  x0         | (x1 << 26);  encode32(t0, bs, off + 0);
        int t1 = (x1 >>>  6) | (x2 << 20);  encode32(t1, bs, off + 4);
        int t2 = (x2 >>> 12) | (x3 << 13);  encode32(t2, bs, off + 8);
        int t3 = (x3 >>> 19) | (x4 <<  7);  encode32(t3, bs, off + 12);
    }

    private static void encode32(int n, byte[] bs, int off)
    {
        bs[  off] = (byte)(n       );
        bs[++off] = (byte)(n >>>  8);
        bs[++off] = (byte)(n >>> 16);
        bs[++off] = (byte)(n >>> 24);
    }

    public static void inv(int[] x, int[] z)
    {
//        int[] x2 = create();
//        int[] t = create();
//        powPm5d8(x, x2, t);
//        sqr(t, 3, t);
//        mul(t, x2, z);

        int[] t = create();
        int[] u = new int[8];

        copy(x, 0, t, 0);
        normalize(t);
        encode(t, u, 0);

        Mod.modOddInverse(P32, u, u);

        decode255(u, z);
    }

    public static void invVar(int[] x, int[] z)
    {
        int[] t = create();
        int[] u = new int[8];

        copy(x, 0, t, 0);
        normalize(t);
        encode(t, u, 0);

        Mod.modOddInverseVar(P32, u, u);

        decode255(u, z);
    }

    public static int isOne(int[] x)
    {
        int d = x[0] ^ 1;
        for (int i = 1; i < SIZE; ++i)
        {
            d |= x[i];
        }
        return ((d - 1) & ~d) >> 31;
    }

    public static boolean isOneVar(int[] x)
    {
        return 0 != isOne(x);
    }

    public static int isZero(int[] x)
    {
        int d = 0;
        for (int i = 0; i < SIZE; ++i)
        {
            d |= x[i];
        }
        return ((d - 1) & ~d) >> 31;
    }

    public static boolean isZeroVar(int[] x)
    {
        return 0 != isZero(x);
    }

    public static void mul(int[] x, int y, int[] z)
    {
        int x0 = x[0], x1 = x[1], x2 = x[2], x3 = x[3], x4 = x[4];
        int x5 = x[5], x6 = x[6], x7 = x[7], x8 = x[8], x9 = x[9];
        long c0, c1, c2, c3;

        c0  = (long)x2 * y; x2 = (int)c0 & M25; c0 >>= 25;
        c1  = (long)x4 * y; x4 = (int)c1 & M25; c1 >>= 25;
        c2  = (long)x7 * y; x7 = (int)c2 & M25; c2 >>= 25;
//        c3  = (long)x9 * y; x9 = (int)c3 & M24; c3 >>= 24;
//        c3 *= 19;
        c3  = (long)x9 * y; x9 = (int)c3 & M25; c3 >>= 25;
        c3 *= 38;

        c3 += (long)x0 * y; z[0] = (int)c3 & M26; c3 >>= 26;
        c1 += (long)x5 * y; z[5] = (int)c1 & M26; c1 >>= 26;

        c3 += (long)x1 * y; z[1] = (int)c3 & M26; c3 >>= 26;
        c0 += (long)x3 * y; z[3] = (int)c0 & M26; c0 >>= 26;
        c1 += (long)x6 * y; z[6] = (int)c1 & M26; c1 >>= 26;
        c2 += (long)x8 * y; z[8] = (int)c2 & M26; c2 >>= 26;

        z[2] = x2 + (int)c3;
        z[4] = x4 + (int)c0;
        z[7] = x7 + (int)c1;
        z[9] = x9 + (int)c2;
    }

    public static void mul(int[] x, int[] y, int[] z)
    {
        int x0 = x[0], y0 = y[0];
        int x1 = x[1], y1 = y[1];
        int x2 = x[2], y2 = y[2];
        int x3 = x[3], y3 = y[3];
        int x4 = x[4], y4 = y[4];

        int u0 = x[5], v0 = y[5];
        int u1 = x[6], v1 = y[6];
        int u2 = x[7], v2 = y[7];
        int u3 = x[8], v3 = y[8];
        int u4 = x[9], v4 = y[9];

        // Verified mathematics (PRESERVE_JAVA).
        // Java integral wraparound and explicit conversions are preserved.
        // Original values:
        // final long _math0 = (long) x2;
        // final long _math1 = (long) y2;
        // final long _math2 = (long) x0;
        // final long _math3 = (long) y4;
        // final long _math4 = (long) x1;
        // final long _math5 = (long) y3;
        // final long _math6 = (long) x3;
        // final long _math7 = (long) y1;
        // final long _math8 = (long) x4;
        // final long _math9 = (long) y0;
        // final long _math10 = (long) u2;
        // final long _math11 = (long) v2;
        // final long _math12 = (long) u0;
        // final long _math13 = (long) v4;
        // final long _math14 = (long) u1;
        // final long _math15 = (long) v3;
        // final long _math16 = (long) u3;
        // final long _math17 = (long) v1;
        // final long _math18 = (long) u4;
        // final long _math19 = (long) v0;
        // final long _math20 = (long) 76;
        // final long _math21 = (long) 38;
        // a4 = (((_math0 * _math1) << 1) + ((((_math2 * _math3) + (_math4 * _math5)) + (_math6 * _math7)) + (_math8 * _math9)));
        // b4 = (((_math10 * _math11) << 1) + ((((_math12 * _math13) + (_math14 * _math15)) + (_math16 * _math17)) + (_math18 * _math19)));
        // a0 = ((_math2 * _math9) - (((((_math14 * _math13) + (_math10 * _math15)) + (_math16 * _math11)) + (_math18 * _math17)) * _math20));
        // a1 = (((_math2 * _math7) + (_math4 * _math9)) - (((((_math10 * _math13) + (_math18 * _math11)) << 1) + (_math16 * _math15)) * _math21));
        // a2 = ((((_math2 * _math1) + (_math4 * _math7)) + (_math0 * _math9)) - (((_math16 * _math13) + (_math18 * _math15)) * _math21));
        // a3 = (((((_math4 * _math1) + (_math0 * _math7)) << 1) + ((_math2 * _math5) + (_math6 * _math9))) - ((_math18 * _math13) * _math20));
        // a5 = ((((((_math4 * _math3) + (_math0 * _math5)) + (_math6 * _math1)) + (_math8 * _math7)) << 1) - (_math12 * _math19));
        // a6 = (((((_math0 * _math3) + (_math8 * _math1)) << 1) + (_math6 * _math5)) - ((_math12 * _math17) + (_math14 * _math19)));
        // a7 = (((_math6 * _math3) + (_math8 * _math5)) - (((_math12 * _math11) + (_math14 * _math17)) + (_math10 * _math19)));
        // a8 = (((_math8 * _math3) << 1) - ((((_math14 * _math11) + (_math10 * _math17)) << 1) + ((_math12 * _math15) + (_math16 * _math19))));
        // Replacement values:
        // final long _math0 = (long) x2;
        // final long _math1 = (long) y2;
        // final long _math2 = (long) x0;
        // final long _math3 = (long) y4;
        // final long _math4 = (long) x1;
        // final long _math5 = (long) y3;
        // final long _math6 = (long) x3;
        // final long _math7 = (long) y1;
        // final long _math8 = (long) x4;
        // final long _math9 = (long) y0;
        // final long _math10 = (long) u2;
        // final long _math11 = (long) v2;
        // final long _math12 = (long) u0;
        // final long _math13 = (long) v4;
        // final long _math14 = (long) u1;
        // final long _math15 = (long) v3;
        // final long _math16 = (long) u3;
        // final long _math17 = (long) v1;
        // final long _math18 = (long) u4;
        // final long _math19 = (long) v0;
        // final long _math20 = (long) 76;
        // final long _math21 = (long) 38;
        // a4 = (((_math0 * _math1) << 1) + ((((_math2 * _math3) + (_math4 * _math5)) + (_math6 * _math7)) + (_math8 * _math9)));
        // b4 = (((_math10 * _math11) << 1) + ((((_math12 * _math13) + (_math14 * _math15)) + (_math16 * _math17)) + (_math18 * _math19)));
        // a0 = ((_math2 * _math9) - (((((_math14 * _math13) + (_math10 * _math15)) + (_math16 * _math11)) + (_math18 * _math17)) * _math20));
        // a1 = (((_math2 * _math7) + (_math4 * _math9)) - (((((_math10 * _math13) + (_math18 * _math11)) << 1) + (_math16 * _math15)) * _math21));
        // a2 = ((((_math2 * _math1) + (_math4 * _math7)) + (_math0 * _math9)) - (((_math16 * _math13) + (_math18 * _math15)) * _math21));
        // a3 = (((((_math4 * _math1) + (_math0 * _math7)) << 1) + ((_math2 * _math5) + (_math6 * _math9))) - ((_math18 * _math13) * _math20));
        // a5 = ((((((_math4 * _math3) + (_math0 * _math5)) + (_math6 * _math1)) + (_math8 * _math7)) << 1) - (_math12 * _math19));
        // a6 = (((((_math0 * _math3) + (_math8 * _math1)) << 1) + (_math6 * _math5)) - ((_math12 * _math17) + (_math14 * _math19)));
        // a7 = (((_math6 * _math3) + (_math8 * _math5)) - (((_math12 * _math11) + (_math14 * _math17)) + (_math10 * _math19)));
        // a8 = (((_math8 * _math3) << 1) - ((((_math14 * _math11) + (_math10 * _math17)) << 1) + ((_math12 * _math15) + (_math16 * _math19))));
        // Recorded search path:
        // No expression rewrite was selected; the value graph is unchanged and only its prepared computation may differ.
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: TYPED_STRUCTURAL_IDENTITY, EXACT_PRIMITIVE_LITERAL_CAST.
        // Estimated operation work: 124 -> 124; not a timing measurement.
        final long _math0 = (long) x2;
        final long _math1 = (long) y2;
        final long _math2 = (long) x0;
        final long _math3 = (long) y4;
        final long _math4 = (long) x1;
        final long _math5 = (long) y3;
        final long _math6 = (long) x3;
        final long _math7 = (long) y1;
        final long _math8 = (long) x4;
        final long _math9 = (long) y0;
        final long _math10 = (long) u2;
        final long _math11 = (long) v2;
        final long _math12 = (long) u0;
        final long _math13 = (long) v4;
        final long _math14 = (long) u1;
        final long _math15 = (long) v3;
        final long _math16 = (long) u3;
        final long _math17 = (long) v1;
        final long _math18 = (long) u4;
        final long _math19 = (long) v0;
        final long _math20 = (long) 76;
        final long _math21 = (long) 38;
        long a0;
        long a1;
        long a2;
        long a3;
        long a4;
        a4 = (((_math0 * _math1) << 1)
				+ ((((_math2 * _math3) + (_math4 * _math5)) + (_math6 * _math7)) + (_math8 * _math9)));
        long a5;
        long a6;
        long a7;
        long a8;
        long b4;
        b4 = (((_math10 * _math11) << 1)
				+ ((((_math12 * _math13) + (_math14 * _math15)) + (_math16 * _math17)) + (_math18 * _math19)));
        
//        b5     <<= 1;
        
//        b8     <<= 1;

        a0 = ((_math2 * _math9)
				- (((((_math14 * _math13) + (_math10 * _math15)) + (_math16 * _math11)) + (_math18 * _math17))
						* _math20));
        a1 = (((_math2 * _math7) + (_math4 * _math9))
				- (((((_math10 * _math13) + (_math18 * _math11)) << 1) + (_math16 * _math15)) * _math21));
        a2 = ((((_math2 * _math1) + (_math4 * _math7)) + (_math0 * _math9))
				- (((_math16 * _math13) + (_math18 * _math15)) * _math21));
        a3 = (((((_math4 * _math1) + (_math0 * _math7)) << 1) + ((_math2 * _math5) + (_math6 * _math9)))
				- ((_math18 * _math13) * _math20));

        a5 = ((((((_math4 * _math3) + (_math0 * _math5)) + (_math6 * _math1)) + (_math8 * _math7)) << 1)
				- (_math12 * _math19));
        a6 = (((((_math0 * _math3) + (_math8 * _math1)) << 1) + (_math6 * _math5))
				- ((_math12 * _math17) + (_math14 * _math19)));
        a7 = (((_math6 * _math3) + (_math8 * _math5))
				- (((_math12 * _math11) + (_math14 * _math17)) + (_math10 * _math19)));
        a8 = (((_math8 * _math3) << 1)
				- ((((_math14 * _math11) + (_math10 * _math17)) << 1) + ((_math12 * _math15) + (_math16 * _math19))));
//        long a9 = -b4;

        x0 += u0; y0 += v0;
        x1 += u1; y1 += v1;
        x2 += u2; y2 += v2;
        x3 += u3; y3 += v3;
        x4 += u4; y4 += v4;

        // Verified mathematics (PRESERVE_JAVA).
        // Java integral wraparound and explicit conversions are preserved.
        // Original values:
        // final long _math0 = (long) x0;
        // final long _math1 = (long) y0;
        // final long _math2 = (long) y1;
        // final long _math3 = (long) x1;
        // final long _math4 = (long) y2;
        // final long _math5 = (long) x2;
        // final long _math6 = (long) y3;
        // final long _math7 = (long) x3;
        // final long _math8 = (long) y4;
        // final long _math9 = (long) x4;
        // c0 = (_math0 * _math1);
        // c1 = ((_math0 * _math2) + (_math3 * _math1));
        // c2 = (((_math0 * _math4) + (_math3 * _math2)) + (_math5 * _math1));
        // c3 = ((((_math3 * _math4) + (_math5 * _math2)) << 1) + ((_math0 * _math6) + (_math7 * _math1)));
        // c4 = (((_math5 * _math4) << 1) + ((((_math0 * _math8) + (_math3 * _math6)) + (_math7 * _math2)) + (_math9 * _math1)));
        // c5 = (((((_math3 * _math8) + (_math5 * _math6)) + (_math7 * _math4)) + (_math9 * _math2)) << 1);
        // c6 = ((((_math5 * _math8) + (_math9 * _math4)) << 1) + (_math7 * _math6));
        // c7 = ((_math7 * _math8) + (_math9 * _math6));
        // c8 = ((_math9 * _math8) << 1);
        // Replacement values:
        // final long _math22 = (long) x0;
        // final long _math23 = (long) y0;
        // final long _math24 = (long) y1;
        // final long _math25 = (long) x1;
        // final long _math26 = (long) y2;
        // final long _math27 = (long) x2;
        // final long _math28 = (long) y3;
        // final long _math29 = (long) x3;
        // final long _math30 = (long) y4;
        // final long _math31 = (long) x4;
        // c0 = (_math22 * _math23);
        // c1 = ((_math22 * _math24) + (_math25 * _math23));
        // c2 = (((_math22 * _math26) + (_math25 * _math24)) + (_math27 * _math23));
        // c3 = ((((_math25 * _math26) + (_math27 * _math24)) << 1) + ((_math22 * _math28) + (_math29 * _math23)));
        // c4 = (((_math27 * _math26) << 1) + ((((_math22 * _math30) + (_math25 * _math28)) + (_math29 * _math24)) + (_math31 * _math23)));
        // c5 = (((((_math25 * _math30) + (_math27 * _math28)) + (_math29 * _math26)) + (_math31 * _math24)) << 1);
        // c6 = ((((_math27 * _math30) + (_math31 * _math26)) << 1) + (_math29 * _math28));
        // c7 = ((_math29 * _math30) + (_math31 * _math28));
        // c8 = ((_math31 * _math30) << 1);
        // Recorded search path:
        // No expression rewrite was selected; the value graph is unchanged and only its prepared computation may differ.
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: TYPED_STRUCTURAL_IDENTITY.
        // Estimated operation work: 56 -> 56; not a timing measurement.
        final long _math22 = (long) x0;
        final long _math23 = (long) y0;
        final long _math24 = (long) y1;
        final long _math25 = (long) x1;
        final long _math26 = (long) y2;
        final long _math27 = (long) x2;
        final long _math28 = (long) y3;
        final long _math29 = (long) x3;
        final long _math30 = (long) y4;
        final long _math31 = (long) x4;
        long c0  = (_math22 * _math23);
        long c1  = ((_math22 * _math24) + (_math25 * _math23));
        long c2  = (((_math22 * _math26) + (_math25 * _math24)) + (_math27 * _math23));
        long c3;
        c3 = ((((_math25 * _math26) + (_math27 * _math24)) << 1) + ((_math22 * _math28) + (_math29 * _math23)));
        long c4;
        c4 = (((_math27 * _math26) << 1)
				+ ((((_math22 * _math30) + (_math25 * _math28)) + (_math29 * _math24)) + (_math31 * _math23)));
        long c5;
        c5 = (((((_math25 * _math30) + (_math27 * _math28)) + (_math29 * _math26)) + (_math31 * _math24)) << 1);
        long c6;
        c6 = ((((_math27 * _math30) + (_math31 * _math26)) << 1) + (_math29 * _math28));
        long c7  = ((_math29 * _math30) + (_math31 * _math28));
        long c8;
        c8 = ((_math31 * _math30) << 1);

        int z8, z9;
        long t;

        t        = a8 + (c3 - a3);
        z8       = (int)t & M26; t >>= 26;
//        t       += a9 + (c4 - a4);
        t       +=      (c4 - a4) - b4;
//        z9       = (int)t & M24; t >>= 24;
//        t        = a0 + (t + ((c5 - a5) << 1)) * 19;
        z9       = (int)t & M25; t >>= 25;
        t        = a0 + (t + c5 - a5) * 38;
        z[0]     = (int)t & M26; t >>= 26;
        t       += a1 + (c6 - a6) * 38;
        z[1]     = (int)t & M26; t >>= 26;
        t       += a2 + (c7 - a7) * 38;
        z[2]     = (int)t & M25; t >>= 25;
        t       += a3 + (c8 - a8) * 38;
        z[3]     = (int)t & M26; t >>= 26;
//        t       += a4 - a9 * 38;
        t       += a4 + b4 * 38;
        z[4]     = (int)t & M25; t >>= 25;
        t       += a5 + (c0 - a0);
        z[5]     = (int)t & M26; t >>= 26;
        t       += a6 + (c1 - a1);
        z[6]     = (int)t & M26; t >>= 26;
        t       += a7 + (c2 - a2);
        z[7]     = (int)t & M25; t >>= 25;
        t       += z8;
        z[8]     = (int)t & M26; t >>= 26;
        z[9]     = z9 + (int)t;
    }

    public static void negate(int[] x, int[] z)
    {
        for (int i = 0; i < SIZE; ++i)
        {
            z[i] = -x[i];
        }
    }

    public static void normalize(int[] z)
    {
        int x = ((z[9] >>> (24 - 1)) & 1);
        reduce(z, x);
        reduce(z, -x);
//        assert z[9] >>> 24 == 0;
    }

    public static void one(int[] z)
    {
        z[0] = 1;
        for (int i = 1; i < SIZE; ++i)
        {
            z[i] = 0;
        }
    }

    private static void powPm5d8(int[] x, int[] rx2, int[] rz)
    {
        // z = x^((p-5)/8) = x^FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD
        // (250 1s) (1 0s) (1 1s)
        // Addition chain: [1] 2 3 5 10 15 25 50 75 125 [250]

        int[] x2 = rx2;         sqr(x, x2);             mul(x, x2, x2);
        int[] x3 = create();    sqr(x2, x3);            mul(x, x3, x3);
        int[] x5 = x3;          sqr(x3, 2, x5);         mul(x2, x5, x5);
        int[] x10 = create();   sqr(x5, 5, x10);        mul(x5, x10, x10);
        int[] x15 = create();   sqr(x10, 5, x15);       mul(x5, x15, x15);
        int[] x25 = x5;         sqr(x15, 10, x25);      mul(x10, x25, x25);
        int[] x50 = x10;        sqr(x25, 25, x50);      mul(x25, x50, x50);
        int[] x75 = x15;        sqr(x50, 25, x75);      mul(x25, x75, x75);
        int[] x125 = x25;       sqr(x75, 50, x125);     mul(x50, x125, x125);
        int[] x250 = x50;       sqr(x125, 125, x250);   mul(x125, x250, x250);

        int[] t = x125;
        sqr(x250, 2, t);
        mul(t, x, rz);
    }

    private static void reduce(int[] z, int x)
    {
        int t = z[9], z9 = t & M24;
        t = (t >> 24) + x;

        long cc = t * 19;
        cc += z[0]; z[0] = (int)cc & M26; cc >>= 26;
        cc += z[1]; z[1] = (int)cc & M26; cc >>= 26;
        cc += z[2]; z[2] = (int)cc & M25; cc >>= 25;
        cc += z[3]; z[3] = (int)cc & M26; cc >>= 26;
        cc += z[4]; z[4] = (int)cc & M25; cc >>= 25;
        cc += z[5]; z[5] = (int)cc & M26; cc >>= 26;
        cc += z[6]; z[6] = (int)cc & M26; cc >>= 26;
        cc += z[7]; z[7] = (int)cc & M25; cc >>= 25;
        cc += z[8]; z[8] = (int)cc & M26; cc >>= 26;
        z[9] = z9 + (int)cc;
    }

    public static void sqr(int[] x, int[] z)
    {
        // Verified mathematics (PRESERVE_JAVA).
        // Java integral wraparound and explicit conversions are preserved.
        // Original values:
        // final long _math0 = (long) (_mathRead17051 * 2);
        // final long _math1 = (long) _mathRead17005;
        // final long _math2 = (long) (_mathRead17097 * 2);
        // final long _math3 = (long) _mathRead17028;
        // final long _math4 = (long) (_mathRead17074 * 2);
        // final long _math5 = (long) (_mathRead17167 * 2);
        // final long _math6 = (long) _mathRead17121;
        // final long _math7 = (long) (_mathRead17213 * 2);
        // final long _math8 = (long) _mathRead17144;
        // final long _math9 = (long) (_mathRead17190 * 2);
        // final long _math10 = (long) (_mathRead17144 * 2);
        // final long _math11 = (long) 38;
        // final long _math12 = (long) (_mathRead17028 * 2);
        // final long _math13 = (long) _mathRead17190;
        // final long _math14 = (long) _mathRead17074;
        // final long _math15 = (long) (_mathRead17005 + _mathRead17121);
        // final int _math16 = _mathRead17028 + _mathRead17144;
        // final long _math17 = (long) (_math16 * 2);
        // final int _math18 = _mathRead17051 + _mathRead17167;
        // final long _math19 = (long) (_math18 * 2);
        // final long _math20 = (long) _math16;
        // final int _math21 = _mathRead17074 + _mathRead17190;
        // final long _math22 = (long) (_math21 * 2);
        // final int _math23 = _mathRead17097 + _mathRead17213;
        // final long _math24 = (long) (_math23 * 2);
        // final long _math25 = (long) _math21;
        // a4 = (((((long) _mathRead17051) * _math0) + (_math1 * _math2)) + (_math3 * _math4));
        // b4 = (((((long) _mathRead17167) * _math5) + (_math6 * _math7)) + (_math8 * _math9));
        // a0 = ((_math1 * _math1) - (((_math10 * _math7) + (_math5 * _math9)) * _math11));
        // a1 = ((_math1 * _math12) - (((_math5 * _math7) + (_math13 * _math13)) * _math11));
        // a2 = (((_math1 * _math0) + (_math3 * _math3)) - ((_math13 * _math7) * _math11));
        // a3 = (((_math12 * _math0) + (_math1 * _math4)) - ((((long) _mathRead17213) * _math7) * _math11));
        // a5 = (((_math12 * _math2) + (_math0 * _math4)) - (_math6 * _math6));
        // a6 = (((_math0 * _math2) + (_math14 * _math14)) - (_math6 * _math10));
        // a7 = ((_math14 * _math2) - ((_math6 * _math5) + (_math8 * _math8)));
        // a8 = ((((long) _mathRead17097) * _math2) - ((_math10 * _math5) + (_math6 * _math9)));
        // c0 = (_math15 * _math15);
        // c1 = (_math15 * _math17);
        // c2 = ((_math15 * _math19) + (_math20 * _math20));
        // c3 = ((_math17 * _math19) + (_math15 * _math22));
        // c4 = (((((long) _math18) * _math19) + (_math15 * _math24)) + (_math20 * _math22));
        // c5 = ((_math17 * _math24) + (_math19 * _math22));
        // c6 = ((_math19 * _math24) + (_math25 * _math25));
        // c7 = (_math25 * _math24);
        // c8 = (((long) _math23) * _math24);
        // Replacement values:
        // final long _math32 = (long) (_mathRead17051 * 2);
        // final long _math33 = (long) _mathRead17005;
        // final long _math34 = (long) (_mathRead17097 * 2);
        // final long _math35 = (long) _mathRead17028;
        // final long _math36 = (long) (_mathRead17074 * 2);
        // final long _math37 = (long) (_mathRead17167 * 2);
        // final long _math38 = (long) _mathRead17121;
        // final long _math39 = (long) (_mathRead17213 * 2);
        // final long _math40 = (long) _mathRead17144;
        // final long _math41 = (long) (_mathRead17190 * 2);
        // final long _math42 = (long) (_mathRead17144 * 2);
        // final long _math43 = (long) 38;
        // final long _math44 = (long) (_mathRead17028 * 2);
        // final long _math45 = (long) _mathRead17190;
        // final long _math46 = (long) _mathRead17074;
        // final long _math47 = (long) (_mathRead17005 + _mathRead17121);
        // final int _math48 = _mathRead17028 + _mathRead17144;
        // final long _math49 = (long) (_math48 * 2);
        // final int _math50 = _mathRead17051 + _mathRead17167;
        // final long _math51 = (long) (_math50 * 2);
        // final long _math52 = (long) _math48;
        // final int _math53 = _mathRead17074 + _mathRead17190;
        // final long _math54 = (long) (_math53 * 2);
        // final int _math55 = _mathRead17097 + _mathRead17213;
        // final long _math56 = (long) (_math55 * 2);
        // final long _math57 = (long) _math53;
        // a4 = (((((long) _mathRead17051) * _math32) + (_math33 * _math34)) + (_math35 * _math36));
        // b4 = (((((long) _mathRead17167) * _math37) + (_math38 * _math39)) + (_math40 * _math41));
        // a0 = ((_math33 * _math33) - (((_math42 * _math39) + (_math37 * _math41)) * _math43));
        // a1 = ((_math33 * _math44) - (((_math37 * _math39) + (_math45 * _math45)) * _math43));
        // a2 = (((_math33 * _math32) + (_math35 * _math35)) - ((_math45 * _math39) * _math43));
        // a3 = (((_math44 * _math32) + (_math33 * _math36)) - ((((long) _mathRead17213) * _math39) * _math43));
        // a5 = (((_math44 * _math34) + (_math32 * _math36)) - (_math38 * _math38));
        // a6 = (((_math32 * _math34) + (_math46 * _math46)) - (_math38 * _math42));
        // a7 = ((_math46 * _math34) - ((_math38 * _math37) + (_math40 * _math40)));
        // a8 = ((((long) _mathRead17097) * _math34) - ((_math42 * _math37) + (_math38 * _math41)));
        // c0 = (_math47 * _math47);
        // c1 = (_math47 * _math49);
        // c2 = ((_math47 * _math51) + (_math52 * _math52));
        // c3 = ((_math49 * _math51) + (_math47 * _math54));
        // c4 = (((((long) _math50) * _math51) + (_math47 * _math56)) + (_math52 * _math54));
        // c5 = ((_math49 * _math56) + (_math51 * _math54));
        // c6 = ((_math51 * _math56) + (_math57 * _math57));
        // c7 = (_math57 * _math56);
        // c8 = (((long) _math55) * _math56);
        // Recorded search path:
        // No expression rewrite was selected; the value graph is unchanged and only its prepared computation may differ.
        // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
        // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
        // Independent numeric proof: TYPED_STRUCTURAL_IDENTITY, EXACT_PRIMITIVE_LITERAL_CAST.
        // Estimated scalar arithmetic work: 120 -> 120; not a timing measurement.
        // All 10 array reads remain in source order. Capture stores, references and held values are additional costs in the reported assessment.
        final int _mathRead17005 = x[0];
        final int _mathRead17028 = x[1];
        final int _mathRead17051 = x[2];
        final int _mathRead17074 = x[3];
        final int _mathRead17097 = x[4];
        final int _mathRead17121 = x[5];
        final int _mathRead17144 = x[6];
        final int _mathRead17167 = x[7];
        final int _mathRead17190 = x[8];
        final int _mathRead17213 = x[9];
        final long _math32 = (long) (_mathRead17051 * 2);
        final long _math33 = (long) _mathRead17005;
        final long _math34 = (long) (_mathRead17097 * 2);
        final long _math35 = (long) _mathRead17028;
        final long _math36 = (long) (_mathRead17074 * 2);
        final long _math37 = (long) (_mathRead17167 * 2);
        final long _math38 = (long) _mathRead17121;
        final long _math39 = (long) (_mathRead17213 * 2);
        final long _math40 = (long) _mathRead17144;
        final long _math41 = (long) (_mathRead17190 * 2);
        final long _math42 = (long) (_mathRead17144 * 2);
        final long _math43 = (long) 38;
        final long _math44 = (long) (_mathRead17028 * 2);
        final long _math45 = (long) _mathRead17190;
        final long _math46 = (long) _mathRead17074;
        final long _math47 = (long) (_mathRead17005 + _mathRead17121);
        final int _math48 = _mathRead17028 + _mathRead17144;
        final long _math49 = (long) (_math48 * 2);
        final int _math50 = _mathRead17051 + _mathRead17167;
        final long _math51 = (long) (_math50 * 2);
        final long _math52 = (long) _math48;
        final int _math53 = _mathRead17074 + _mathRead17190;
        final long _math54 = (long) (_math53 * 2);
        final int _math55 = _mathRead17097 + _mathRead17213;
        final long _math56 = (long) (_math55 * 2);
        final long _math57 = (long) _math53;
        long a0;
        long a1;
        long a2;
        long a3;
        long a4  = (((((long) _mathRead17051) * _math32) + (_math33 * _math34)) + (_math35 * _math36));
        long a5;
        long a6;
        long a7;
        long a8;

        long b4  = (((((long) _mathRead17167) * _math37) + (_math38 * _math39)) + (_math40 * _math41));
        a0 = ((_math33 * _math33) - (((_math42 * _math39) + (_math37 * _math41)) * _math43));
        a1 = ((_math33 * _math44) - (((_math37 * _math39) + (_math45 * _math45)) * _math43));
        a2 = (((_math33 * _math32) + (_math35 * _math35)) - ((_math45 * _math39) * _math43));
        a3 = (((_math44 * _math32) + (_math33 * _math36)) - ((((long) _mathRead17213) * _math39) * _math43));

        a5 = (((_math44 * _math34) + (_math32 * _math36)) - (_math38 * _math38));
        a6 = (((_math32 * _math34) + (_math46 * _math46)) - (_math38 * _math42));
        a7 = ((_math46 * _math34) - ((_math38 * _math37) + (_math40 * _math40)));
        a8 = ((((long) _mathRead17097) * _math34) - ((_math42 * _math37) + (_math38 * _math41)));
//        long a9 = -b4;

        long c0  = (_math47 * _math47);
        long c1  = (_math47 * _math49);
        long c2  = ((_math47 * _math51) + (_math52 * _math52));
        long c3  = ((_math49 * _math51) + (_math47 * _math54));
        long c4  = (((((long) _math50) * _math51) + (_math47 * _math56)) + (_math52 * _math54));
        long c5  = ((_math49 * _math56) + (_math51 * _math54));
        long c6  = ((_math51 * _math56) + (_math57 * _math57));
        long c7  = (_math57 * _math56);
        long c8  = (((long) _math55) * _math56);

        int z8, z9;
        long t;

        t        = a8 + (c3 - a3);
        z8       = (int)t & M26; t >>= 26;
//        t       += a9 + (c4 - a4);
        t       +=      (c4 - a4) - b4;
//        z9       = (int)t & M24; t >>= 24;
//        t        = a0 + (t + ((c5 - a5) << 1)) * 19;
        z9       = (int)t & M25; t >>= 25;
        t        = a0 + (t + c5 - a5) * 38;
        z[0]     = (int)t & M26; t >>= 26;
        t       += a1 + (c6 - a6) * 38;
        z[1]     = (int)t & M26; t >>= 26;
        t       += a2 + (c7 - a7) * 38;
        z[2]     = (int)t & M25; t >>= 25;
        t       += a3 + (c8 - a8) * 38;
        z[3]     = (int)t & M26; t >>= 26;
//        t       += a4 - a9 * 38;
        t       += a4 + b4 * 38;
        z[4]     = (int)t & M25; t >>= 25;
        t       += a5 + (c0 - a0);
        z[5]     = (int)t & M26; t >>= 26;
        t       += a6 + (c1 - a1);
        z[6]     = (int)t & M26; t >>= 26;
        t       += a7 + (c2 - a2);
        z[7]     = (int)t & M25; t >>= 25;
        t       += z8;
        z[8]     = (int)t & M26; t >>= 26;
        z[9]     = z9 + (int)t;
    }

    public static void sqr(int[] x, int n, int[] z)
    {
//        assert n > 0;

        sqr(x, z);

        while (--n > 0)
        {
            sqr(z, z);
        }
    }

    public static boolean sqrtRatioVar(int[] u, int[] v, int[] z)
    {
        int[] uv3 = create();
        int[] uv7 = create();

        mul(u, v, uv3);
        sqr(v, uv7);
        mul(uv3, uv7, uv3);
        sqr(uv7, uv7);
        mul(uv7, uv3, uv7);

        int[] t = create();
        int[] x = create();
        powPm5d8(uv7, t, x);
        mul(x, uv3, x);

        int[] vx2 = create();
        sqr(x, vx2);
        mul(vx2, v, vx2);

        sub(vx2, u, t);
        normalize(t);
        if (isZeroVar(t))
        {
            copy(x, 0, z, 0);
            return true;
        }

        add(vx2, u, t);
        normalize(t);
        if (isZeroVar(t))
        {
            mul(x, ROOT_NEG_ONE, z);
            return true;
        }

        return false;
    }

    public static void sub(int[] x, int[] y, int[] z)
    {
        for (int i = 0; i < SIZE; ++i)
        {
            z[i] = x[i] - y[i];
        }
    }

    public static void subOne(int[] z)
    {
        z[0] -= 1;
    }

    public static void zero(int[] z)
    {
        for (int i = 0; i < SIZE; ++i)
        {
            z[i] = 0;
        }
    }
}
