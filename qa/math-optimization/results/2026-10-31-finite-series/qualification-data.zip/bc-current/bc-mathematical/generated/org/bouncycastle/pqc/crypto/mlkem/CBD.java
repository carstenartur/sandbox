package org.bouncycastle.pqc.crypto.mlkem;

import org.bouncycastle.util.Pack;

class CBD
{
    static void eta2(Poly r, byte[] bytes)
    {
        for (int i = 0; i < MLKEMEngine.N / 8; i++)
        {
            int t = Pack.littleEndianToInt(bytes, 4 * i);
            int d = t & 0x55555555;
            d += (t >>> 1) & 0x55555555;
            for (int j = 0; j < 8; j++)
            {
                // Verified mathematics (PRESERVE_JAVA).
                // Java integral wraparound and explicit conversions are preserved.
                // Original values:
                // final int _math0 = 4 * j;
                // a = ((int) ((short) ((d >>> (_math0 + 0)) & 3)));
                // b = ((int) ((short) ((d >>> (_math0 + 2)) & 3)));
                // Replacement values:
                // final int _math0 = 4 * j;
                // a = ((int) ((short) ((d >>> _math0) & 3)));
                // b = ((int) ((short) ((d >>> (_math0 + 2)) & 3)));
                // Recorded search path:
                // Search step 1/1 [typed-local-algebra]:
                // final int _math0 = 4 * j;
                // a = ((int) ((short) ((d >>> _math0) & 3)));
                // b = ((int) ((short) ((d >>> (_math0 + 2)) & 3)));
                // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
                // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
                // Independent numeric proof: TYPED_STRUCTURAL_IDENTITY, BITVECTOR_POLYNOMIAL_MOD_2_32, TYPED_OPERATION_CONGRUENCE.
                // Estimated operation work: 11 -> 10; not a timing measurement.
                final int _math0 = 4 * j;
                int a = ((int) ((short) ((d >>> _math0) & 3)));
                int b = ((int) ((short) ((d >>> (_math0 + 2)) & 3)));
                r.setCoeffIndex(8 * i + j, (short)(a - b));
            }
        }
    }

    static void eta3(Poly r, byte[] bytes)
    {
        for (int i = 0; i < MLKEMEngine.N / 4; i++)
        {
            int t = Pack.littleEndianToInt24(bytes, 3 * i);
            int d = t & 0x00249249;
            d += (t >>> 1) & 0x00249249;
            d += (t >>> 2) & 0x00249249;
            for (int j = 0; j < 4; j++)
            {
                // Verified mathematics (PRESERVE_JAVA).
                // Java integral wraparound and explicit conversions are preserved.
                // Original values:
                // final int _math0 = 6 * j;
                // a = ((int) ((short) ((d >>> (_math0 + 0)) & 7)));
                // b = ((int) ((short) ((d >>> (_math0 + 3)) & 7)));
                // Replacement values:
                // final int _math1 = 6 * j;
                // a = ((int) ((short) ((d >>> _math1) & 7)));
                // b = ((int) ((short) ((d >>> (_math1 + 3)) & 7)));
                // Recorded search path:
                // Search step 1/1 [typed-local-algebra]:
                // final int _math0 = 6 * j;
                // a = ((int) ((short) ((d >>> _math0) & 7)));
                // b = ((int) ((short) ((d >>> (_math0 + 3)) & 7)));
                // Each compound proposal is one recorded search step; no unrecorded primitive expansion is implied.
                // Selected edges were regenerated and independently checked; the original trace still governs exceptions and evaluation order.
                // Independent numeric proof: TYPED_STRUCTURAL_IDENTITY, BITVECTOR_POLYNOMIAL_MOD_2_32, TYPED_OPERATION_CONGRUENCE.
                // Estimated operation work: 11 -> 10; not a timing measurement.
                final int _math1 = 6 * j;
                int a = ((int) ((short) ((d >>> _math1) & 7)));
                int b = ((int) ((short) ((d >>> (_math1 + 3)) & 7)));
                r.setCoeffIndex(4 * i + j, (short)(a - b));
            }
        }
    }
}
