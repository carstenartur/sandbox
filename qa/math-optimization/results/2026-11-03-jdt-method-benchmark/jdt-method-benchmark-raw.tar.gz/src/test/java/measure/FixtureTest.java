package measure;

import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class FixtureTest {
    private static final char[] NAME = "fixture.class".toCharArray();
    @ParameterizedTest @ValueSource(ints = {0,24,79,4095,4096,4097,8192,65535})
    void validCompleteClassAndFirstDecodeEquality(int count) throws Throwable {
        byte[] bytes = Fixtures.synthetic(count, false);
        Fixtures.jvmVerify(bytes);
        Files.write(IsolatedReader.ROOT.resolve("fixtures/handlers-" + count + ".class"), bytes);
        for (String variant : List.of("before", "after")) {
            try (IsolatedReader reader = new IsolatedReader(variant)) {
                Object[] details = reader.inspect(bytes, NAME, false);
                assertEquals(1, details[1], "Names must be absent before first call");
                assertEquals(1, details[2]); assertEquals(true, details[3]);
                char[][][] names = (char[][][]) details[0];
                assertEquals(1, names.length); assertEquals(1, names[0].length);
                assertArrayEquals("value".toCharArray(), names[0][0]);
                assertTrue(Arrays.deepEquals(names, reader.read(bytes, NAME)));
                reader.proof(Integer.toString(count), bytes);
            }
        }
    }

    @Test void methodParametersAndFullInitializationAreExplicitBypassControls() throws Throwable {
        byte[] withParameters = Fixtures.synthetic(4096, true);
        Fixtures.jvmVerify(withParameters);
        Files.write(IsolatedReader.ROOT.resolve("fixtures/handlers-4096-MethodParameters.class"), withParameters);
        for (String variant : List.of("before", "after")) {
            try (IsolatedReader reader = new IsolatedReader(variant)) {
                Object[] parameters = reader.inspect(withParameters, NAME, false);
                assertEquals(0, parameters[1]); assertEquals(true, parameters[3]);
                assertArrayEquals("parameterViaMethodParameters".toCharArray(), ((char[][][])parameters[0])[0][0]);
                Object[] initialized = reader.inspect(Fixtures.synthetic(4096, false), NAME, true);
                assertEquals(0, initialized[1]); assertEquals(true, initialized[3]);
                assertArrayEquals("value".toCharArray(), ((char[][][])initialized[0])[0][0]);
            }
        }
    }

    @Test void realUnchangedClassNamesAgreeAndEveryMethodStartsUncached() throws Throwable {
        byte[] bytes = Fixtures.input("real-ClassFileReader");
        assertEquals("bbbd6045ebd668f43229be9550c771cc4c987ec29fc5b3863c60c892296d4a32", IsolatedReader.sha(bytes));
        Files.write(IsolatedReader.ROOT.resolve("fixtures/real-ClassFileReader.class"), bytes);
        Object[] before;
        Object[] after;
        try (IsolatedReader reader = new IsolatedReader("before")) {
            before = reader.inspect(bytes, NAME, false); reader.proof("real-ClassFileReader", bytes);
        }
        try (IsolatedReader reader = new IsolatedReader("after")) {
            after = reader.inspect(bytes, NAME, false); reader.proof("real-ClassFileReader", bytes);
        }
        char[][][] names = (char[][][]) before[0];
        assertTrue(names.length > 1);
        assertEquals(names.length, before[1]); assertEquals(names.length, after[1]);
        assertTrue(Arrays.deepEquals(before[0] instanceof Object[] x ? x : null, (Object[])after[0]));
        assertArrayEquals((String[]) before[4], (String[]) after[4]);
        assertEquals(true, before[3]); assertEquals(true, after[3]);
        StringBuilder text = new StringBuilder("methods=" + names.length + "\n");
        String[] selectors = (String[]) before[4];
        for (int i = 0; i < names.length; i++) text.append(selectors[i]).append("\t").append(Arrays.deepToString(names[i])).append('\n');
        Files.writeString(IsolatedReader.ROOT.resolve("evidence/real-argument-names.txt"), text);
    }
}
