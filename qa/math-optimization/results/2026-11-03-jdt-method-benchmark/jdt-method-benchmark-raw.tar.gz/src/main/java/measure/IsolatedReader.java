package measure;

import java.lang.invoke.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.io.*;

public final class IsolatedReader implements AutoCloseable {
    public static final Path ROOT = Path.of(System.getProperty("analysis.root", "/workspace/scratch/330c17e56514/jdt-method-benchmark"));
    public static final Path QUALIFIED = ROOT.resolveSibling("jdt-math-qualification");
    public static final String CLASS_RESOURCE = "org/eclipse/jdt/internal/compiler/classfmt/MethodInfo.class";
    private final URLClassLoader loader;
    private final MethodHandle read;
    private final MethodHandle inspect;
    public final Properties identity = new Properties();

    public static Path jar(String variant) {
        if (!variant.equals("before") && !variant.equals("after")) throw new IllegalArgumentException(variant);
        return QUALIFIED.resolve(variant.equals("before") ? "core-original" : "core-transformed")
            .resolve("org.eclipse.jdt.core.compiler.batch/target/org.eclipse.jdt.core.compiler.batch-3.46.100-SNAPSHOT.jar");
    }
    public static String sha(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static void require(boolean condition, String message) {if (!condition) throw new AssertionError(message);}

    public IsolatedReader(String variant) throws Exception {
        Path jar = jar(variant).toRealPath();
        String expectedJar = variant.equals("before") ? "eb6c7af97ef7f8ae79ffd21eeea5e1f28142c5925defa59232f8685e75520a9a" : "231d8531e42cdd2cb34d8eff0cd1fddf86b8b1be11d475abecb389782923125d";
        String expectedClass = variant.equals("before") ? "bc0956e48f95176ea2223d2a64f404445ea1c39f629ff11da8d59c9367ebf883" : "2ae8970c5e04e60dcaa1e85c4d962876db14a15abbe3d82e2c083ca8c03fdb90";
        String jarHash = sha(Files.readAllBytes(jar));
        require(jarHash.equals(expectedJar), "Qualified JAR hash mismatch");
        loader = new URLClassLoader(new URL[] { ROOT.resolve("bridge-classes").toUri().toURL(), jar.toUri().toURL() }, ClassLoader.getPlatformClassLoader());
        Class<?> bridge = Class.forName("benchbridge.ReaderBridge", true, loader);
        Class<?> methodInfo = Class.forName("org.eclipse.jdt.internal.compiler.classfmt.MethodInfo", true, loader);
        Class<?> classReader = Class.forName("org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader", true, loader);
        require(bridge.getClassLoader() == loader && methodInfo.getClassLoader() == loader && classReader.getClassLoader() == loader, "Classloader isolation failed");
        require(loader.getParent() == ClassLoader.getPlatformClassLoader(), "Wrong parent loader");
        Path codeSource = Path.of(methodInfo.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
        require(codeSource.equals(jar), "MethodInfo code source mismatch");
        require(Path.of(classReader.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath().equals(jar), "ClassFileReader code source mismatch");
        byte[] classBytes;
        try (InputStream input = methodInfo.getResourceAsStream("MethodInfo.class")) {classBytes = input.readAllBytes();}
        String classHash = sha(classBytes);
        require(classHash.equals(expectedClass), "MethodInfo class hash mismatch");
        read = MethodHandles.publicLookup().findStatic(bridge, "read", MethodType.methodType(char[][][].class, byte[].class, char[].class));
        inspect = MethodHandles.publicLookup().findStatic(bridge, "inspect", MethodType.methodType(Object[].class, byte[].class, char[].class, boolean.class));
        identity.setProperty("variant", variant);
        identity.setProperty("jar", jar.toString());
        identity.setProperty("jarSha256", jarHash);
        identity.setProperty("methodInfoSha256", classHash);
        identity.setProperty("methodInfoCodeSource", codeSource.toString());
        identity.setProperty("loaderParent", loader.getParent().getClass().getName());
        identity.setProperty("jvmVersion", System.getProperty("java.runtime.version"));
        identity.setProperty("jvmVendor", System.getProperty("java.vendor"));
        identity.setProperty("jvmHome", System.getProperty("java.home"));
        identity.setProperty("runtimeClasspath", System.getProperty("java.class.path"));
        identity.setProperty("bridgeSha256", sha(Files.readAllBytes(ROOT.resolve("bridge-classes/benchbridge/ReaderBridge.class"))));
    }
    public char[][][] read(byte[] bytes, char[] name) throws Throwable {return (char[][][]) read.invokeExact(bytes, name);}
    public Object[] inspect(byte[] bytes, char[] name, boolean full) throws Throwable {return (Object[]) inspect.invokeExact(bytes, name, full);}
    public void proof(String workload, byte[] bytes) throws Exception {
        identity.setProperty("input", workload);
        identity.setProperty("inputBytes", Integer.toString(bytes.length));
        identity.setProperty("inputSha256", sha(bytes));
        Path file = ROOT.resolve("evidence/proof-" + identity.getProperty("variant") + "-" + workload + "-" + ProcessHandle.current().pid() + ".properties");
        try (Writer out = Files.newBufferedWriter(file)) {identity.store(out, "Actual loaded-code and input identity; outside timing");}
    }
    @Override public void close() throws IOException {loader.close();}
}
