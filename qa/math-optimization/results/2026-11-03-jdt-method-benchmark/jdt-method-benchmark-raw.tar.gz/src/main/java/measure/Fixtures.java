package measure;

import java.io.*;
import java.nio.file.*;
import java.util.jar.*;

public final class Fixtures {
    public static final int[] COUNTS = {0, 24, 79, 4095, 4096, 4097, 8192, 65535};

    /** Complete Java 8 class; duplicate legal handlers and LVT after their table. */
    public static byte[] synthetic(int count, boolean methodParameters) throws IOException {
        if (count < 0 || count > 65535) throw new IllegalArgumentException();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeInt(0xcafebabe); out.writeShort(0); out.writeShort(52);
        out.writeShort(16);
        utf(out, "bench/Fixture" + count + (methodParameters ? "MP" : "")); // 1
        cls(out, 1); // 2
        utf(out, "java/lang/Object"); cls(out, 3); // 3,4
        utf(out, "target"); utf(out, "(I)I"); // 5,6
        utf(out, "Code"); utf(out, "LocalVariableTable"); // 7,8
        utf(out, "value"); utf(out, "I"); // 9,10
        utf(out, "StackMapTable"); utf(out, "java/lang/Throwable"); cls(out, 12); // 11..13
        utf(out, "MethodParameters"); utf(out, "parameterViaMethodParameters"); // 14,15
        out.writeShort(0x0021); out.writeShort(2); out.writeShort(4);
        out.writeShort(0); out.writeShort(0); out.writeShort(1); // interfaces, fields, methods
        out.writeShort(0x0009); out.writeShort(5); out.writeShort(6);
        out.writeShort(methodParameters ? 2 : 1);
        out.writeShort(7); out.writeInt(45 + 8 * count);
        out.writeShort(1); out.writeShort(1); out.writeInt(3);
        out.write(new byte[] {0x1a, (byte) 0xac, (byte) 0xbf}); // iload_0; ireturn; athrow
        out.writeShort(count);
        for (int i = 0; i < count; i++) {
            out.writeShort(0); out.writeShort(2); out.writeShort(2); out.writeShort(0);
        }
        out.writeShort(2);
        out.writeShort(8); out.writeInt(12); out.writeShort(1);
        out.writeShort(0); out.writeShort(3); out.writeShort(9); out.writeShort(10); out.writeShort(0);
        out.writeShort(11); out.writeInt(6); out.writeShort(1);
        out.writeByte(66); out.writeByte(7); out.writeShort(13); // stack Throwable at bci 2
        if (methodParameters) {
            out.writeShort(14); out.writeInt(5); out.writeByte(1); out.writeShort(15); out.writeShort(0);
        }
        out.writeShort(0); // class attributes
        return bytes.toByteArray();
    }

    private static void utf(DataOutputStream out, String value) throws IOException {out.writeByte(1); out.writeUTF(value);}
    private static void cls(DataOutputStream out, int index) throws IOException {out.writeByte(7); out.writeShort(index);}

    public static byte[] input(String workload) throws IOException {
        if (workload.equals("real-ClassFileReader")) {
            try (JarFile jar = new JarFile(IsolatedReader.jar("before").toFile())) {
                return jar.getInputStream(jar.getJarEntry("org/eclipse/jdt/internal/compiler/classfmt/ClassFileReader.class")).readAllBytes();
            }
        }
        return synthetic(Integer.parseInt(workload), false);
    }

    public static void jvmVerify(byte[] bytes) throws Exception {
        class Verifier extends ClassLoader {
            Verifier() {super(ClassLoader.getPlatformClassLoader());}
            Class<?> define() {return defineClass(null, bytes, 0, bytes.length);}
        }
        Object value = new Verifier().define().getMethod("target", int.class).invoke(null, 7);
        if (!Integer.valueOf(7).equals(value)) throw new AssertionError("JVM invocation returned " + value);
    }
}
