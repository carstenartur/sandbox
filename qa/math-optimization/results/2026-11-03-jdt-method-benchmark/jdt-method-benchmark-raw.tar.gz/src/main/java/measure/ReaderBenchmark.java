package measure;

import java.util.concurrent.TimeUnit;
import org.openjdk.jmh.annotations.*;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@Warmup(iterations = 3, time = 500, timeUnit = TimeUnit.MILLISECONDS)
@Measurement(iterations = 5, time = 500, timeUnit = TimeUnit.MILLISECONDS)
@Fork(value = 2, jvmArgsAppend = {"-Xms1g", "-Xmx1g", "-XX:+UseG1GC", "-Xverify:all"})
@Threads(1)
@State(Scope.Thread)
public class ReaderBenchmark {
    @Param({"before", "after"}) public String variant;
    @Param({"0", "24", "79", "4095", "4096", "4097", "8192", "65535", "real-ClassFileReader"}) public String workload;
    private IsolatedReader reader;
    private byte[] bytes;
    private char[] name;
    @Setup(Level.Trial) public void setup() throws Throwable {
        reader = new IsolatedReader(variant);
        bytes = Fixtures.input(workload);
        name = (workload + ".class").toCharArray();
        Object[] inspection = reader.inspect(bytes, name, false);
        char[][][] names = (char[][][]) inspection[0];
        if (((Integer) inspection[1]) != names.length || !Boolean.TRUE.equals(inspection[3])) throw new AssertionError("First-access/caching gate failed");
        if (!workload.startsWith("real-")) {
            Fixtures.jvmVerify(bytes);
            if (names.length != 1 || names[0].length != 1 || !new String(names[0][0]).equals("value")) throw new AssertionError("Expected trailing LVT name");
        }
        reader.proof(workload, bytes);
    }
    @Benchmark public char[][][] freshReadAndFirstArgumentNames() throws Throwable {return reader.read(bytes, name);}
    @TearDown(Level.Trial) public void close() throws Exception {reader.close();}
}
