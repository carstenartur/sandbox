import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import javax.xml.parsers.*;

/** Receipt generation only; neither a test framework nor part of the measured classpath. */
public class Summarize {
    static final Gson JSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    static final Path ROOT = Path.of(".").toAbsolutePath().normalize();
    static JsonObject object(Object value) {return JSON.toJsonTree(value).getAsJsonObject();}
    static String sha(Path path) throws Exception {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)));}
    static JsonObject metric(JsonObject entry, String name) {
        return name.equals("time") ? entry.getAsJsonObject("primaryMetric") : entry.getAsJsonObject("secondaryMetrics").getAsJsonObject(name);
    }
    static JsonObject compactMetric(JsonObject metric) {
        JsonObject r = new JsonObject();
        for (String k : List.of("score", "scoreError", "scoreConfidence", "scoreUnit", "rawData")) r.add(k, metric.get(k));
        return r;
    }
    static boolean overlaps(JsonObject a, JsonObject b) {
        JsonArray x = a.getAsJsonArray("scoreConfidence"), y = b.getAsJsonArray("scoreConfidence");
        return x.get(0).getAsDouble() <= y.get(1).getAsDouble() && y.get(0).getAsDouble() <= x.get(1).getAsDouble();
    }
    public static void main(String[] args) throws Exception {
        if (!Files.readString(ROOT.resolve("evidence/gates.exit")).strip().equals("0")) throw new AssertionError("Gate failure");
        if (!Files.readString(ROOT.resolve("evidence/jmh.exit")).strip().equals("0")) throw new AssertionError("JMH failure");
        JsonArray entries = JsonParser.parseString(Files.readString(ROOT.resolve("evidence/jmh-results.json"))).getAsJsonArray();
        if (entries.size() != 18) throw new AssertionError("Incomplete JMH case count");
        Map<String,Map<String,JsonObject>> index = new LinkedHashMap<>();
        for (JsonElement item : entries) {
            JsonObject e = item.getAsJsonObject();
            if (e.get("forks").getAsInt() != 2 || e.get("warmupIterations").getAsInt() != 3 || e.get("measurementIterations").getAsInt() != 5) throw new AssertionError("Run settings mismatch");
            for (String kind : List.of("time", "gc.alloc.rate.norm")) {
                JsonArray raw = metric(e, kind).getAsJsonArray("rawData");
                if (raw.size() != 2 || raw.get(0).getAsJsonArray().size() != 5 || raw.get(1).getAsJsonArray().size() != 5) throw new AssertionError("Incomplete measurements");
            }
            JsonObject p = e.getAsJsonObject("params");
            index.computeIfAbsent(p.get("workload").getAsString(), k -> new LinkedHashMap<>()).put(p.get("variant").getAsString(), e);
        }
        JsonObject receipt = new JsonObject();
        receipt.addProperty("scope", "Measured unchanged qualified R4_41 compiler.batch JARs; fresh ClassFileReader(..., false) and first getArgumentNames for every method on every operation; analysis-only bridge, no product recompilation or edits.");
        receipt.addProperty("startedUtc", Files.readString(ROOT.resolve("evidence/benchmark-start.utc")).strip());
        receipt.addProperty("endedUtc", Files.readString(ROOT.resolve("evidence/benchmark-end.utc")).strip());
        receipt.addProperty("jmhVersion", "1.37");
        receipt.addProperty("jmhCases", entries.size());
        receipt.addProperty("forksPerCase", 2);
        receipt.addProperty("warmup", "3 x 500 ms per fork");
        receipt.addProperty("measurement", "5 x 500 ms per fork");
        receipt.addProperty("threads", 1);
        receipt.addProperty("confidenceLevel", "JMH 99.9%; overlapping intervals are reported descriptively, not proof of equivalence");
        receipt.add("jvmArgs", entries.get(0).getAsJsonObject().get("jvmArgs"));
        receipt.addProperty("jvm", Files.readString(ROOT.resolve("evidence/java-version.txt")).strip());
        receipt.addProperty("maven", Files.readString(ROOT.resolve("evidence/maven-version.txt")).strip());
        receipt.addProperty("toolHashFile", "evidence/tool-sha256.txt");
        JsonObject synthetic = new JsonObject();
        synthetic.addProperty("classFileVersion", 52);
        synthetic.addProperty("methods", 1);
        synthetic.addProperty("method", "public static int target(int value)");
        synthetic.addProperty("codeLengthBytes", 3);
        synthetic.addProperty("code", "iload_0; ireturn; athrow");
        synthetic.addProperty("exceptionEntryBytes", 8);
        synthetic.addProperty("entry", "start_pc=0, end_pc=2, handler_pc=2, catch_type=0; legal duplicate catch-all handlers");
        synthetic.addProperty("followingAttribute", "LocalVariableTable contains value at local index 0, start_pc 0 and length 3; StackMapTable describes Throwable stack at handler bci 2.");
        synthetic.addProperty("scope", "Handler count is independent of method code_length. 65535 handlers means 524280 table bytes with only 3 instruction bytes, a valid extremal fixture rather than a representative real class.");
        synthetic.addProperty("executedBranches", "0 skips the existing outer block; 24, 79 and 4095 execute the first original-loop fallback after the threshold comparison; 4096, 4097, 8192 and 65535 execute the BigInteger branch with the inner guard succeeding. The second fallback on failed BigInteger range checks is unreachable for this concrete unsigned-u2At domain and was not executed.");
        receipt.add("syntheticFixtureDefinition", synthetic);
        var factory = DocumentBuilderFactory.newInstance();
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        var tests = factory.newDocumentBuilder().parse(ROOT.resolve("target/surefire-reports/TEST-measure.FixtureTest.xml").toFile()).getDocumentElement();
        JsonObject gate = new JsonObject();
        for (String field : List.of("tests", "failures", "errors", "skipped", "time")) gate.addProperty(field, tests.getAttribute(field));
        gate.addProperty("jvmVerification", "Synthetic fixtures use complete Java 8 classfiles, valid StackMapTable, legal duplicate exception handlers; every fixture was defined and target(7) invoked under -Xverify:all before timing.");
        gate.addProperty("pathGate", "All methods have argumentNames == null before first decode. Synthetic expected name value occurs in LVT beyond the entire exception table; all eight counts return it identically in before/after. Repeated getter returns identical cached object.");
        gate.addProperty("bypassControls", "MethodParameters control returns parameterViaMethodParameters with populated cache; fullyInitialize=true also prepopulates names. Neither control is timed.");
        gate.addProperty("realControl", "Unchanged before ClassFileReader.class; 67 methods with equal before/after names, all initially uncached; input SHA-256 bbbd6045ebd668f43229be9550c771cc4c987ec29fc5b3863c60c892296d4a32. Reviewed maximum exception-table count is 24, no MethodParameters attributes.");
        receipt.add("gates", gate);
        JsonArray comparisons = new JsonArray();
        StringBuilder table = new StringBuilder("workload\tbefore_ns_op\tafter_ns_op\ttime_ratio_after_before\ttime_99.9ci_overlap\tbefore_B_op\tafter_B_op\tallocation_ratio\tallocation_99.9ci_overlap\n");
        for (String key : List.of("0","24","79","4095","4096","4097","8192","65535","real-ClassFileReader")) {
            var pair = index.get(key);
            if (pair == null || pair.size() != 2) throw new AssertionError("Missing pair: " + key);
            JsonObject b = pair.get("before"), a = pair.get("after");
            JsonObject r = new JsonObject(); r.addProperty("input", key);
            if (!key.startsWith("real-")) {
                r.addProperty("exceptionTableEntries", Integer.parseInt(key));
                r.addProperty("exceptionTableBytes", 8 * Integer.parseInt(key));
                r.addProperty("methodCodeLengthBytes", 3);
            }
            for (String name : List.of("time", "gc.alloc.rate.norm")) {
                JsonObject bm = metric(b,name), am = metric(a,name), c = new JsonObject();
                c.add("before", compactMetric(bm)); c.add("after", compactMetric(am));
                c.addProperty("ratioAfterBefore", am.get("score").getAsDouble()/bm.get("score").getAsDouble());
                c.addProperty("confidenceIntervalsOverlap", overlaps(bm,am)); r.add(name,c);
            }
            comparisons.add(r);
            var t = r.getAsJsonObject("time"); var g = r.getAsJsonObject("gc.alloc.rate.norm");
            table.append(String.format(Locale.ROOT,"%s\t%.3f\t%.3f\t%.4f\t%s\t%.3f\t%.3f\t%.4f\t%s%n", key, metric(b,"time").get("score").getAsDouble(),metric(a,"time").get("score").getAsDouble(),t.get("ratioAfterBefore").getAsDouble(),t.get("confidenceIntervalsOverlap"),metric(b,"gc.alloc.rate.norm").get("score").getAsDouble(),metric(a,"gc.alloc.rate.norm").get("score").getAsDouble(),g.get("ratioAfterBefore").getAsDouble(),g.get("confidenceIntervalsOverlap")));
        }
        receipt.add("comparisons",comparisons);
        JsonArray origins = new JsonArray();
        try (var files = Files.list(ROOT.resolve("evidence"))) {
            for (Path f : files.filter(p -> p.getFileName().toString().startsWith("proof-")).sorted().toList()) {
                Properties p = new Properties(); try (Reader in = Files.newBufferedReader(f)) {p.load(in);}
                if (p.getProperty("runtimeClasspath").contains("jdt-math-qualification")) throw new AssertionError("Product JAR on host classpath");
                JsonObject origin = object(p); origin.addProperty("proofFile", ROOT.relativize(f).toString()); origins.add(origin);
            }
        }
        if (origins.size() != 54) throw new AssertionError("Expected 18 JUnit + 36 JMH origin proofs, got " + origins.size());
        receipt.add("loadedOrigins",origins);
        receipt.addProperty("exitCodes", "bridge compile 0; Maven/JUnit 0; JMH 0. Initial launcher attempt exited 127 because /usr/bin/time was absent, before Java started; preserved under evidence/launcher-attempt-1. Replaced only outer timing wrapper with Bash time; no measurement rerun.");
        receipt.add("limits", JSON.toJsonTree(List.of(
            "Steady-state JMH on one container/JDK/CPU configuration; no cold-start or general end-to-end product-speed claim.",
            "Full fresh reader and first names decode includes generated guard, fallback or BigInteger cost, and unrelated reader/name-array overhead; no standalone primitive-add loop timing.",
            "Synthetic handler entries are legal duplicates chosen to isolate table size, not a representative distribution of Java classfiles.",
            "The single real control is 67-method ClassFileReader.class, maximum reviewed table count 24; not a corpus coverage or workload representativeness claim.",
            "The same immutable input byte array is reused across operations and variants; file I/O, class loading and JVM fixture verification are outside timing.",
            "Every operation has a fresh ClassFileReader and fresh MethodInfo objects, but the reused input byte array and internal CharDeduplication thread cache are warm in this steady-state measurement; this does not model a fresh process or cold name cache.",
            "The inner BigInteger-range-check failure fallback is unreachable for this concrete start=0, stride=1 and u2At count range 0..65535; it was not executed. The timing includes only reachable guards and branches for each stated input.",
            "Bridge MethodHandle call and returned char[][][] consumption are common to both variants; this measures only the existing generated transformation, not a proposed primitive rewrite.",
            "No JIT assembly inspection was performed; bytecode differences or constant running time alone do not establish a specific JIT transformation.",
            "Only 2 forks and 5 measured iterations per fork; do not infer equivalence from overlapping confidence intervals or apply these microbenchmark ratios to a full compiler/application."
        )));
        Files.writeString(ROOT.resolve("receipt.json"),JSON.toJson(receipt)+"\n");
        Files.writeString(ROOT.resolve("comparison.tsv"),table.toString());
        System.out.print(table);
    }
}
