#!/usr/bin/env bash
set -u
JAVA=/tmp/jdt-pr5614-tools/jdk-25.0.5+8/bin/java
GSON=/tmp/jdt-pr5614-tools/apache-maven-3.9.16/lib/gson-2.13.2.jar
"$JAVA" -cp "$GSON" Summarize.java > evidence/summary.log 2>&1
summary_exit=$?
printf '%s\n' "$summary_exit" > evidence/summary.exit
exit "$summary_exit"
