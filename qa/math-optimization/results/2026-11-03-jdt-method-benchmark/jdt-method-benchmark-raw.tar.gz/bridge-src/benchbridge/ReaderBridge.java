package benchbridge;

import java.lang.reflect.Field;
import org.eclipse.jdt.internal.compiler.classfmt.ClassFileReader;
import org.eclipse.jdt.internal.compiler.classfmt.MethodInfo;
import org.eclipse.jdt.internal.compiler.env.IBinaryMethod;

/** Analysis-only bridge, compiled once against the qualified before JAR. */
public final class ReaderBridge {
    public static char[][][] read(byte[] bytes, char[] fileName) throws Exception {
        ClassFileReader reader = new ClassFileReader(bytes, fileName, false);
        IBinaryMethod[] methods = reader.getMethods();
        char[][][] result = new char[methods.length][][];
        for (int i = 0; i < methods.length; i++) {
            result[i] = methods[i].getArgumentNames();
        }
        return result;
    }

    /** Outside timing: prove lazy first access, populated cache, repeat identity. */
    public static Object[] inspect(byte[] bytes, char[] fileName, boolean full) throws Exception {
        ClassFileReader reader = new ClassFileReader(bytes, fileName, full);
        IBinaryMethod[] methods = reader.getMethods();
        Field cache = MethodInfo.class.getDeclaredField("argumentNames");
        cache.setAccessible(true);
        int uncached = 0;
        int cached = 0;
        boolean repeatIdentity = true;
        char[][][] result = new char[methods.length][][];
        String[] selectors = new String[methods.length];
        for (int i = 0; i < methods.length; i++) {
            if (cache.get(methods[i]) == null) uncached++;
            result[i] = methods[i].getArgumentNames();
            if (cache.get(methods[i]) != null) cached++;
            repeatIdentity &= result[i] == methods[i].getArgumentNames();
            selectors[i] = new String(methods[i].getSelector());
        }
        return new Object[] { result, uncached, cached, repeatIdentity, selectors };
    }
}
