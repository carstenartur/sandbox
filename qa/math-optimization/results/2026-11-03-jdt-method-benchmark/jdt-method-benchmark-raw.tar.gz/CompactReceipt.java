import com.google.gson.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Build the repository-sized receipt only after its complete raw archive exists. */
public class CompactReceipt {
    static String sha(Path path) throws Exception {return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)));}
    public static void main(String[] args) throws Exception {
        Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
        JsonObject full = JsonParser.parseString(Files.readString(Path.of("receipt.json"))).getAsJsonObject();
        JsonObject compact = full.deepCopy();
        compact.remove("loadedOrigins");
        compact.remove("maven");
        compact.addProperty("mavenVersion", "3.9.16");
        compact.addProperty("junitVersion", "6.1.3");
        compact.addProperty("qualifiedCoreCommit", "6725c16c24d94c83302346dc384bb915a0f2fe1a");
        compact.addProperty("buildScope", "This project compiled only analysis/bridge sources; measured product JARs were already qualified and were not rebuilt or modified.");
        for (JsonElement element : compact.getAsJsonArray("comparisons")) {
            JsonObject pair = element.getAsJsonObject();
            for (String metric : List.of("time", "gc.alloc.rate.norm")) {
                pair.getAsJsonObject(metric).getAsJsonObject("before").remove("rawData");
                pair.getAsJsonObject(metric).getAsJsonObject("after").remove("rawData");
            }
        }
        JsonObject identities = new JsonObject();
        JsonObject inputs = new JsonObject();
        List<String> fields = List.of("jar", "jarSha256", "methodInfoSha256", "methodInfoCodeSource", "loaderParent", "jvmVersion", "jvmVendor", "jvmHome", "bridgeSha256");
        for (JsonElement element : full.getAsJsonArray("loadedOrigins")) {
            JsonObject proof = element.getAsJsonObject();
            String variant = proof.get("variant").getAsString();
            JsonObject identity = new JsonObject();
            for (String field : fields) identity.add(field, proof.get(field));
            if (identities.has(variant) && !identities.get(variant).equals(identity)) throw new AssertionError("Mixed identities");
            identities.add(variant, identity);
            String input = proof.get("input").getAsString();
            JsonObject inputIdentity = new JsonObject();
            inputIdentity.add("bytes", proof.get("inputBytes")); inputIdentity.add("sha256", proof.get("inputSha256"));
            if (inputs.has(input) && !inputs.get(input).equals(inputIdentity)) throw new AssertionError("Input bytes differ");
            inputs.add(input, inputIdentity);
        }
        compact.add("qualifiedIdentities", identities);
        compact.add("identicalInputs", inputs);
        compact.addProperty("originProofCount", full.getAsJsonArray("loadedOrigins").size());
        compact.addProperty("originProofScope", "18 JUnit variant/input proofs and 36 individual JMH-fork proofs; identical variant hashes and input hashes checked when aggregating. Full proof blocks retained only in raw receipt/archive.");
        JsonObject artifacts = new JsonObject();
        for (String file : List.of("jdt-method-benchmark-raw.tar.gz", "receipt.json", "evidence/jmh-results.json", "evidence/jmh.log", "evidence/gates.log", "target/surefire-reports/TEST-measure.FixtureTest.xml", "evidence/tool-sha256.txt", "evidence/analysis-tool-sha256.txt", "evidence/artifact-manifest.sha256")) {
            JsonObject artifact = new JsonObject(); artifact.addProperty("sha256", sha(Path.of(file))); artifact.addProperty("bytes", Files.size(Path.of(file))); artifacts.add(file, artifact);
        }
        compact.add("rawArtifacts", artifacts);
        JsonObject findings = new JsonObject();
        findings.addProperty("synthetic4096AndAbove", "On all four measured 4096/4097/8192/65535 handler fixtures, after/before average-time ratio is 2.16–2.49 and normalized allocation ratio 2.82–3.05; each pair's 99.9% time intervals is disjoint. This actual generated branch did not improve the measured complete fresh read/name-decode operation.");
        findings.addProperty("syntheticBelow4096", "All four 0/24/79/4095 pairs have overlapping 99.9% time intervals and unchanged normalized allocation within reported intervals; no resolved time improvement or regression in this bounded run.");
        findings.addProperty("realControl", "ClassFileReader.class: 18.78 µs/op before versus 18.34 µs/op after, overlapping 99.9% time intervals and unchanged approximately 33744 B/op; no established speedup.");
        findings.addProperty("scope", "Steady-state fresh-reader measurement, one real class plus legal synthetic extremal cases; no cold-start, overall compiler/application or representative-corpus performance claim; no JIT assembly claim.");
        compact.add("findings", findings);
        Files.writeString(Path.of("receipt-compact.json"), gson.toJson(compact) + "\n");
        System.out.println("compact receipt: " + Files.size(Path.of("receipt-compact.json")) + " bytes");
    }
}
