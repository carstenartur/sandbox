#!/usr/bin/env bash
set -eu
JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
GSON=/tmp/jdt-pr5614-tools/apache-maven-3.9.16/lib/gson-2.13.2.jar
sha256sum "$GSON" "$JAVA_HOME/bin/javac" /root/.m2/repository/org/junit/jupiter/junit-jupiter-api/6.1.3/junit-jupiter-api-6.1.3.jar /root/.m2/repository/org/junit/jupiter/junit-jupiter-engine/6.1.3/junit-jupiter-engine-6.1.3.jar /root/.m2/repository/org/junit/jupiter/junit-jupiter-params/6.1.3/junit-jupiter-params-6.1.3.jar > evidence/analysis-tool-sha256.txt
"$JAVA_HOME/bin/javac" -version > evidence/javac-version.txt 2>&1
find README.md pom.xml Summarize.java CompactReceipt.java run-gates.sh run-benchmark.sh run-summary.sh run-archive.sh src bridge-src bridge-classes fixtures target evidence receipt.json comparison.tsv -type f ! -name artifact-manifest.sha256 ! -name compact.log ! -name compact.exit -print0 | sort -z | xargs -0 sha256sum > evidence/artifact-manifest.sha256
tar --exclude=evidence/compact.log --exclude=evidence/compact.exit -czf jdt-method-benchmark-raw.tar.gz README.md pom.xml Summarize.java CompactReceipt.java run-gates.sh run-benchmark.sh run-summary.sh run-archive.sh src bridge-src bridge-classes fixtures target evidence receipt.json comparison.tsv
"$JAVA_HOME/bin/java" -cp "$GSON" CompactReceipt.java > evidence/compact.log 2>&1
compact_exit=$?
printf '%s\n' "$compact_exit" > evidence/compact.exit
sha256sum jdt-method-benchmark-raw.tar.gz receipt-compact.json > archive-and-compact.sha256
