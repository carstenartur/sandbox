#!/usr/bin/env bash
set -u
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:$PATH"
BEFORE_JAR=/workspace/scratch/330c17e56514/jdt-math-qualification/core-original/org.eclipse.jdt.core.compiler.batch/target/org.eclipse.jdt.core.compiler.batch-3.46.100-SNAPSHOT.jar
java -version > evidence/java-version.txt 2>&1
/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin/mvn --version > evidence/maven-version.txt 2>&1
javac --release 25 -cp "$BEFORE_JAR" -d bridge-classes bridge-src/benchbridge/ReaderBridge.java > evidence/bridge-compile.log 2>&1
bridge_exit=$?
printf '%s\n' "$bridge_exit" > evidence/bridge-compile.exit
if [ "$bridge_exit" -ne 0 ]; then exit "$bridge_exit"; fi
/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin/mvn -o -B -ntp test > evidence/gates.log 2>&1
gates_exit=$?
printf '%s\n' "$gates_exit" > evidence/gates.exit
exit "$gates_exit"
