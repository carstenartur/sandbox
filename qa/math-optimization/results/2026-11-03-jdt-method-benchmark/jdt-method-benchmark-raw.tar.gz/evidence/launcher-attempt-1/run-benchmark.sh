#!/usr/bin/env bash
set -u
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:$PATH"
JMH_CORE=/root/.m2/repository/org/openjdk/jmh/jmh-core/1.37/jmh-core-1.37.jar
JMH_GEN=/root/.m2/repository/org/openjdk/jmh/jmh-generator-annprocess/1.37/jmh-generator-annprocess-1.37.jar
JOPT=/root/.m2/repository/net/sf/jopt-simple/jopt-simple/5.0.4/jopt-simple-5.0.4.jar
MATH3=/root/.m2/repository/org/apache/commons/commons-math3/3.6.1/commons-math3-3.6.1.jar
BENCH_CP="target/classes:$JMH_CORE:$JOPT:$MATH3"
if [ "$(cat evidence/gates.exit)" != 0 ]; then exit 99; fi
date -u +%Y-%m-%dT%H:%M:%SZ > evidence/benchmark-start.utc
sha256sum "$JAVA_HOME/release" "$JAVA_HOME/bin/java" "$JAVA_HOME/lib/server/libjvm.so" "$JMH_CORE" "$JMH_GEN" "$JOPT" "$MATH3" > evidence/tool-sha256.txt
lscpu > evidence/lscpu.txt
uname -a > evidence/uname.txt
cat /proc/meminfo > evidence/meminfo.txt
/usr/bin/time -v java -Danalysis.root="$PWD" -cp "$BENCH_CP" org.openjdk.jmh.Main 'measure.ReaderBenchmark.freshReadAndFirstArgumentNames' -f 2 -wi 3 -i 5 -w 500ms -r 500ms -t 1 -bm avgt -tu ns -prof gc -foe true -rf json -rff evidence/jmh-results.json -o evidence/jmh.log > evidence/jmh-console.log 2> evidence/jmh-time-stderr.log
benchmark_exit=$?
printf '%s\n' "$benchmark_exit" > evidence/jmh.exit
date -u +%Y-%m-%dT%H:%M:%SZ > evidence/benchmark-end.utc
exit "$benchmark_exit"
