# Qualified JDT MethodInfo measurement

This directory contains an analysis-only Maven/JUnit/JMH project. It does not patch the mathematics optimizer, Eclipse product sources, or CI. It uses the already built and qualified R4_41 compiler.batch JARs from the sibling `jdt-math-qualification` directory without rebuilding them.

## Observed result

The completed run covers all 18 variant/input combinations, 36 forks and 10 measured values per combination. JUnit and JMH exited 0. The actual generated BigInteger branch made the complete fresh reader/name-decode call slower on all four synthetic cases at or above 4096 handlers: 2.16–2.49 times the before mean, with disjoint 99.9% time intervals. Allocation rose from approximately 680 to 1920 or 2072 B/op. Below 4096 and on the real control, time intervals overlap and allocation stays unchanged within the reported intervals. The real control's approximately 2.3% lower after mean is not evidence of a speedup.

Times below are average ns/op ± JMH's 99.9% error interval. Allocation is rounded to whole B/op; precise values and intervals remain in both receipts and raw JSON.

| Input: handler count or real class | Before ns/op | After ns/op | Before B/op | After B/op |
| --- | ---: | ---: | ---: | ---: |
| 0 | 325.380 ± 35.227 | 319.313 ± 31.594 | 672 | 672 |
| 24 | 343.868 ± 56.407 | 341.517 ± 53.537 | 672 | 672 |
| 79 | 344.018 ± 46.811 | 367.618 ± 57.983 | 672 | 672 |
| 4095 | 374.987 ± 97.980 | 325.180 ± 23.829 | 680 | 680 |
| 4096 | 324.084 ± 44.139 | 806.532 ± 183.810 | 680 | 1920 |
| 4097 | 346.891 ± 49.779 | 767.215 ± 108.522 | 680 | 2072 |
| 8192 | 343.831 ± 55.861 | 743.243 ± 116.136 | 680 | 1920 |
| 65535 | 343.127 ± 27.398 | 753.780 ± 98.114 | 680 | 2072 |
| ClassFileReader.class, all 67 methods | 18782.461 ± 1999.304 | 18342.635 ± 2279.232 | 33744 | 33744 |

## Measured operation

Every benchmark operation constructs a new actual `ClassFileReader(bytes, fileName, false)`, obtains all of its methods and calls each method's first `getArgumentNames()`. It returns all names as `char[][][]`; JMH consumes that return value. Thus reader construction, attribute scanning, the generated threshold guard, original-loop fallback or BigInteger branch, and name decoding/allocation are within the timed operation. Input generation, input bytes, file I/O, class loading, identity checks and JVM fixture verification are outside timing.

The inputs are immutable identical byte arrays for before and after. There are eight synthetic cases with 0, 24, 79, 4095, 4096, 4097, 8192 and 65535 exception-table entries, plus one separate real control: the unchanged original `ClassFileReader.class`, with all 67 methods decoded. The real control's reviewed maximum handler count is 24. This is one real class, not a representative distribution or corpus benchmark.

Every operation has fresh ClassFileReader and MethodInfo objects. The reused input byte array and the internal CharDeduplication thread cache are warm in steady state; the measurement does not model a fresh process or a cold name cache.

The synthetic classfiles are complete Java 8 classfiles. The only method is `public static int target(int value)`, with exactly **3 code bytes** (`iload_0; ireturn; athrow`) for every handler count. Handler entries are legal duplicates with start 0, end 2, handler 2 and catch type 0. Each handler is 8 bytes; 65535 handlers therefore occupy 524280 table bytes, independently of the 3 instruction bytes. A correct StackMapTable describes the Throwable at bytecode index 2. The LocalVariableTable is behind the whole handler array, so recovering the expected name `value` tests the changed offset. The largest case is a valid extremal fixture, not a typical real class.

The zero-handler case skips the existing outer block. Cases 24, 79 and 4095 execute the first original-loop fallback after the generated threshold comparison. Cases 4096, 4097, 8192 and 65535 execute the BigInteger branch with the inner guard succeeding. The second fallback following a failed inner BigInteger range check is unreachable for this concrete start 0, stride 1 and unsigned-u2At count domain up to 65535; this measurement does not execute that fallback.

## Identity and path gates

The bridge is compiled once against the actual before JAR. JUnit and JMH system classpaths contain no product JAR. Each test variant or JMH fork creates an isolated URLClassLoader containing only the bridge and its selected qualified product JAR, with the platform classloader as parent. A JMH fork has exactly one variant. The loaded MethodInfo and ClassFileReader loaders and code sources are checked; the whole JAR and MethodInfo class resource hashes must match the qualified receipt. The bridge hash, actual input hash and JVM identity are also recorded per fork.

JUnit defines each synthetic class in the JVM and invokes `target(7)` under `-Xverify:all`. It checks expected names in both variants and verifies argumentNames is null before the first getter and populated afterward. Repeated getters return the identical cached object. Separate controls show that MethodParameters prepopulates a distinct parameter name and that fullyInitialize=true also prepopulates names. These bypass controls are not benchmarked. The real class's 67 methods begin uncached and have equal names before and after. Each JMH setup repeats the lazy-cache, expected-name, origin and synthetic JVM-verification gates before timing.

## Run

Run in this directory, with the qualification tree and JDK paths named in the scripts available:

```sh
bash run-gates.sh
bash run-benchmark.sh
```

The Maven test uses JUnit 6.1.3; only analysis sources and the bridge are compiled. JMH 1.37 uses 2 separate forks per case, 3 warmup iterations and 5 measured iterations per fork, each 500 ms, 1 thread, average time in ns/op, GC profiling, Temurin 25.0.5+8, G1GC, fixed 1 GiB heap and `-Xverify:all`. Raw JMH JSON retains every per-iteration time and allocation result and JMH's 99.9% confidence intervals. The generated JMH benchmark code is also retained.

`Summarize.java` creates `receipt.json` and `comparison.tsv` from those raw results after asserting all 18 case/variant combinations and their 2x5 measurements exist. Gson is used only by this receipt generator, not on the measured classpath. `run-summary.sh` contains its exact command.

One initial launcher attempt exited 127 because `/usr/bin/time` was unavailable, before Java or JMH started. That attempt is preserved under `evidence/launcher-attempt-1`. The only correction was using Bash's built-in `time`. There was one completed JMH measurement run, without optional reruns.

## Interpretation limits

These are steady-state measurements of full fresh reader/name-decode calls on one container/JDK configuration. They do not measure cold start, class loading, disk I/O, the full compiler or an IDE. The synthetic cases isolate valid table sizes; no input-frequency or representative-workload claim follows from them or from the separate single real control. Both variants include the same bridge call and returned names array overhead. Bytecode counts and flat runtime alone do not identify a particular JIT optimization; no assembly inspection was performed. Overlapping confidence intervals do not prove equivalence. Results characterize the actual generated transformation and do not measure a hypothetical simpler primitive replacement.

## Evidence

`evidence/gates.log` and `target/surefire-reports` hold JUnit results. `evidence/jmh.log`, `evidence/jmh-results.json`, `evidence/jmh-time-stderr.log` and exit files hold the completed run. `evidence/proof-*.properties` bind every test/fork to actual code and input identity. `fixtures` holds all exact input bytes. Tool hashes, machine information, full sources, generated benchmark code and exact run scripts are retained alongside the compact receipt.

`run-archive.sh` produces `jdt-method-benchmark-raw.tar.gz` with the full sources, compiled analysis bridge, generated harness, fixtures, raw results, gates, origin proofs and complete receipt. The product JARs and JDK are identified by exact hashes and existing qualified paths rather than duplicated in this small archive. `receipt-compact.json` retains one identity per variant, all pair scores/intervals and hash references to the complete raw evidence and archive. The compact receipt itself is created after the archive so it can contain the archive hash without a circular dependency.
