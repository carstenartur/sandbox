# Inverse predicate follow-up: implicit callbacks

## Exact identities

- Commit: f28577ffb7b09be6225ef0ca4d2acf2502175a33
- Tree: c08282cd397e0eb0e9cbe8d564b804ff85fc770c
- Parent: 0290a6a19e106817d339c80397b070bc25f8d050, tree 8e84663f282672a1ed44c8ee4e08e3afc49422f6.
- The parent is the byte-identical recovery of the original 043ea5c correction.
- This follow-up: two files, 47 insertions / 3 deletions.
- Both corrections together against recovered base 205b32f: two files, 122 insertions / 3 deletions.
- Tracked source is clean. The untracked .superpowers directory contains only local qualification evidence.

## Actual RED

Three valid original programs and their actual emitted replacements were compiled and executed through the existing JUnit authorities. At input (100, 3), every original returns ArithmeticException:1 to the external observer. Every pre-fix generated program returned ArithmeticException:2.

The three independent paths are:
1. super.toString() dispatches through Object.toString to the overridden hashCode and its scalar callback.
2. String concatenation converts this through the overridden toString and its scalar callback.
3. A locally caught exception invokes an unproved constructor which increments the callback observer.

The numeric scalar result remains unchanged. These are observable additional callbacks, not differences invented by changing BigInteger.signum values. Original and emitted source text is retained in red.log and red.xml.

RED was observed before production edits: 3 tests, 3 expected failures, zero errors/skips, exit 1, 23.743 seconds including dependency restoration.

## Correction and positive control

Only the new Inverse rejection-origin closure changed. It now admits a closed set of statements and expressions. Statement admission is limited to blocks, returns, if statements and local variable declarations. Expressions allow bound names/fields/this, literal constants, recursively proved ordinary method calls, parentheses, casts, conditionals, ordinary instanceof and primitive infix/prefix operations. Unknown expression/statement forms fail closed. In particular, super calls, unchecked allocations/constructors and reference-to-String concatenation are excluded.

The existing original-binding and already-guarded-field checks remain, as do the shared Work charges and recursion bound. The generic continuation projection and Runtime foundation are unchanged.

The pure transitive helper positive now also contains a benign String-literal instanceof expression. It still qualifies and original/generated programs execute identically. This distinguishes a closed pure syntax from a blanket ban on String literals. Existing actual G2 coverage still requires Inverse admission, four retained/shared values and the inverse receipt.

## Fresh qualification

- Focused clean gate: 7 tests, zero failures/errors/skips, exit 0, 15.020 seconds.
- Affected clean gate: 66 tests in five suites, zero failures/errors/skips, exit 0, 34.704 seconds.
- InverseReuse 28; InverseSource 2; Reuse 20; Residue 11; Runtime 5.
- All five affected XML reports are copied under surefire-reports.
- No source changes followed this affected gate.
- CPU was released to Root after the gate.
- No full corpus, Native or JMH run was performed here. Separate Runtime fixes are not part of this isolated qualification.

## Commands

Working directory: /tmp/sandbox-value-inverse-guard-review

JDK: /tmp/jdt-pr5614-tools/jdk-25.0.5+8
Maven: /tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin/mvn
Settings: /tmp/jdt-pr5614-tools/public-proxy-settings.xml
Local repository: /tmp/jdt-pr5614-m2

Common arguments:
-B -ntp -s /tmp/jdt-pr5614-tools/public-proxy-settings.xml -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -f qa/math-optimization/pom.xml

The initial RED used an online dependency bootstrap with the configured browser proxy and /etc/ssl/certs/java/cacerts truststore. Both subsequent clean gates used -o.

RED selector:
-Dtest=JavaValueInverseReuseTest#speculativeRejectionGuardMustNotInvokeImplicitCallbacks clean test

Focused selector:
-Dtest=JavaValueInverseReuseTest#speculativeRejectionGuardMustNotInvokeImplicitCallbacks+speculativeRejectionGuardMustNotDuplicateAnUnprovedScalarCallback+aPureTransitiveRejectionHelperKeepsTheQualifiedInverse+reusedInverseHasExecutedFreshWrappersAndIndependentScalarCopies clean test

Affected selector:
-Dtest=JavaValueInverseReuseTest,JavaValueInverseSourceTest,JavaValueReuseTest,JavaValueResidueTest,JavaValueRuntimeTest clean test

## Payload and review

The two-element full-text payload in recovery/inverse-predicate-f28577f-payload.json contains exactly the committed production and test files. It does not import old Runtime files or claim to be a complete integrated prefix. Both standalone full-file copies compare byte-for-byte with the committed source.

The exact follow-up commit and all evidence paths were sent to inverse_commit_review and Root. At the time of writing, final independent disposition has not yet been received.
