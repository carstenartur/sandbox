# Inverse static-initialization review regression

## Finding and disposition

The exact reported direct case is already protected on public head e54c30c617ab713d8dd4f02e82377e9ee0f59cdd, whose tree equals the local base df5c13fd8db0f8dce682c4a7689ff9e06d7cc3eb (59212bd01a8a26c2e734faa433a173f0f9151b75).

There is no observed RED or admitted Original/Generated mismatch. Production remains unchanged. Commit 4b7b862bd1a54d0b31a96c69363980c6bd8a54df adds only one parameterized regression with two executed cases: 26 added lines in JavaValueInverseReuseTest. Final tree: 396855226b26e32fe055d117b28ca1db8d51053c.

## Existing generic admission

Session.constant(UNITY) records Foreign.ONE and Foreign.ZERO before recording UNITY. JavaValueAlgebraProof.prove checks the session's static-field owners with requireInitializedOwners before emitting any guard. The reported identity therefore fails with:
VALUE_INVERSE_ALGEBRA:[UNITY:VALUE_ALGEBRA_INITIALIZATION_OWNER]

No guard reordering, owner-gate relaxation, budget change or implementation repair was needed.

## Compiled execution

Both variants enter Calculation.scale from a Leaf static initializer placed before UNITY. The existing executeInitializer helper compiles the complete source with javac --release 17 and runs it in an isolated class loader. The generated complete source is separately compiled and executed in another isolated loader.

Negative case: UNITY is initialized from Foreign.ONE/Foreign.ZERO; the original computation does not read Foreign. Both original and generated observe before:after:foreign:. Inverse admission is explicitly rejected with the exact owner diagnostic.

Positive case: UNITY remains source-local and only the reciprocal continuation reads Foreign.P, whose value equals the source modulus. The retained original inverse therefore already accesses that foreign owner. Both original and generated observe before:foreign:after:, and an Inverse receipt is explicitly required and present.

An established original access is not described as a general guarantee that every class initializer has fully completed under recursion.

## Fresh qualification

Focused clean run on unchanged production:
- 2 tests, zero failures/errors/skips, exit 0.
- 13.687 seconds.
- unchanged-production.log and unchanged-production.xml contain the actual observations and admission states.

Affected clean run:
- 74 tests in 5 suites, zero failures/errors/skips, exit 0.
- 44.009 seconds.
- InverseReuse 30; InverseSource 2; Reuse 26; Residue 11; Runtime 5.
- Actual G2 admission and the existing Runtime regressions remain in the executed suite.
- All five XML reports are preserved under surefire-reports.
- No source changes followed this gate.

JDK: /tmp/jdt-pr5614-tools/jdk-25.0.5+8
Maven: /tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin/mvn
Settings: /tmp/jdt-pr5614-tools/public-proxy-settings.xml
Local repository: /tmp/jdt-pr5614-m2

Both commands used:
-o -B -ntp -s /tmp/jdt-pr5614-tools/public-proxy-settings.xml -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -f qa/math-optimization/pom.xml

Focused selector:
-Dtest=JavaValueInverseReuseTest#foreignInitializationRequiresAnEstablishedOriginalAccess clean test

Affected selector:
-Dtest=JavaValueInverseReuseTest,JavaValueInverseSourceTest,JavaValueReuseTest,JavaValueResidueTest,JavaValueRuntimeTest clean test

## Source and payload boundaries

The production source and SDK jar compare unchanged against the publication base. The SDK jar SHA-256 is 5ad54860d828a738d4df8dba87659b8a14009bfb208f79705a4b8529b9c58884 (owning SDK93 prefix). This record does not claim later SDK70 integration, Native, full corpus or JMH qualification.

The one-element payload contains only the full committed JavaValueInverseReuseTest.java. It imports no production or SDK files. Test SHA-256: b2b0b35f9cd9e1c86e3477b71dc6f36fc71cdb414f2ea942a4289b8365616e97.

CPU was explicitly released to Root after the affected run. The independent reviewer has checked the exact commit, source/test diff, both raw logs and five XMLs without a finding; manifest verification is the final pending review step at the time of writing.
