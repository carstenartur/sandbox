# Native PR 1792: detached-comment source freshness

## Exact source identity

- Review comment: https://github.com/carstenartur/sandbox/pull/1792#discussion_r4445668187
- Public reviewed head: `b639c482ac4d5707a60530619624dc1e7cf8481a`.
- Byte-identical local base: `36be6f4476ce10e218833a5fe64fd9362358c7c8`, tree `9954a7fa9585302036043898524d1e2b8c98a162`.
- Local fix: `298def9d2ae0603857102c70819294b4cf156176`, tree `5b01c8734662a4948440244ccab62dd0fdca0506`.
- Isolated worktree: `/tmp/sandbox-native-freshness-review`.
- Exactly two files changed, 58 additions and 2 deletions. The production change is nine added lines. No remote mutation was performed.

## Confirmed failure and bounded correction

The original bound AST omitted comments added later by replacing equally long whitespace. The shared freshness check compared normal AST positions and structure, then the tail inspector read the original comment list. The emitted plan replaced the entire method body and removed the new comment. Both the current original and actually applied generated program were compiled and executed before the rejection assertion failed.

The correction includes each comment's node type, start and length in stable comment-list order, charging each entry through the existing callback before processing it. Missing original comment metadata explicitly fails the freshness check. Bound original nodes, the independent comparison AST, existing parser-mode retry, work limits and cancellation remain in their existing roles.

## Actual executed Maven/JUnit evidence

All runs used JDK `/tmp/jdt-pr5614-tools/jdk-25.0.5+8`, Maven `/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin/mvn`, offline repository `/tmp/jdt-pr5614-m2`, and the unchanged `qa/math-optimization/pom.xml` with `clean test`.

| Evidence | Source stage | Tests | Failures | Errors | Skips | Maven duration |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| `red.log`, `red-xml/` | Original production; added block/line comments | 2 | 2 | 0 | 0 | 12.688 s |
| `extended-red.log`, `extended-red-xml/` | Original production; added comments, changed kind and moved range | 4 | 4 | 0 | 0 | 11.705 s |
| `affected-green.log`, `affected-green-xml/` | First candidate, before null-metadata review correction | 75 | 0 | 0 | 0 | 16.786 s |
| `missing-metadata-red.log`, `missing-metadata-red-xml/` | First candidate; actual NPE detected by independent review | 1 | 1 | 0 | 0 | 10.271 s |
| `reviewed-green.log`, `reviewed-green-xml/` | Final committed source bytes | 76 | 0 | 0 | 0 | 17.774 s |

The final run completed at **2026-11-02 17:47:09 UTC**. It freshly compiled 127 production and 129 test sources. It covers `JavaTailRecursionRewriteTest`, `JavaTailRecursionReplayTest`, `JavaTailRecursionInspectorTest`, `MathCleanUpOptionsTest`, `JavaValueResidueTest`, `MathematicalInterruptionTest`, `DocumentedSourceSnapshotTest` and `JavaFiniteSumBudgetTest`. Matching authored Javadoc is exercised with both enabled and disabled structured-documentation parsing, and both emitted loop forms are compiled and executed. The unchanged-header-comment positive control remains admitted.

The final command was:

```sh
JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
PATH="$JAVA_HOME/bin:/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin:$PATH"
mvn -o -B --no-transfer-progress -Dmaven.repo.local=/tmp/jdt-pr5614-m2 \
  -f qa/math-optimization/pom.xml \
  -Dtest=JavaTailRecursionRewriteTest,JavaTailRecursionReplayTest,JavaTailRecursionInspectorTest,MathCleanUpOptionsTest,JavaValueResidueTest,MathematicalInterruptionTest,DocumentedSourceSnapshotTest,JavaFiniteSumBudgetTest \
  clean test
```

Independent reviewer `/root/inverse_commit_review` approved the exact final commit and tree after reading both committed files, all RED/GREEN logs and XML counts. The final qualification is the 76-test run, not the intermediate 75-test run. No complete corpus, native workbench, JMH or Help qualification is claimed for this isolated correction; Root owns the subsequent combined qualification and new capture.

## Separately observed public Help result

The old-head Help job `125437851402`, run `41492214472`, completed with Maven success and 9/9 screenshot tests passing. Its subsequent checkout comparison failed because the five mathematics PNGs differed. The log did not identify pixel causes, and no unrelated image changes were accepted. Genuine generated evidence is available at https://github.com/carstenartur/sandbox/actions/runs/41492214472/artifacts/13164808693. This result belongs to the pre-fix public head, not the local corrected source.
