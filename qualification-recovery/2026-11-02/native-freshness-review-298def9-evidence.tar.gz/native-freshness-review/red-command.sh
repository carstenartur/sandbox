#!/usr/bin/env bash
set -u
cd /tmp/sandbox-native-freshness-review
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin:$PATH"
freshness_receipts=/workspace/scratch/0eb32b15fbb4/recovery/native-freshness-review
git rev-parse HEAD 'HEAD^{tree}' > "$freshness_receipts/red-identity-before.txt"
git status --porcelain=v1 > "$freshness_receipts/red-status-before.txt"
git diff --binary > "$freshness_receipts/red-source.patch"
mvn -o -B --no-transfer-progress -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -f qa/math-optimization/pom.xml '-Dtest=JavaTailRecursionRewriteTest#nativeBridgeRejectsDetachedCommentsAddedToTheSource' clean test > "$freshness_receipts/red.log" 2>&1
freshness_red_exit=$?
printf '%s\n' "$freshness_red_exit" > "$freshness_receipts/red-exit.txt"
mkdir -p "$freshness_receipts/red-xml"
cp qa/math-optimization/target/surefire-reports/TEST-*.xml "$freshness_receipts/red-xml/"
git rev-parse HEAD 'HEAD^{tree}' > "$freshness_receipts/red-identity-after.txt"
tail -n 55 "$freshness_receipts/red.log"
exit "$freshness_red_exit"
