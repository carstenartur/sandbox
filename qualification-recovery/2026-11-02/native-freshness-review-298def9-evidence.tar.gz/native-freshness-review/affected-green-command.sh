#!/usr/bin/env bash
set -u
cd /tmp/sandbox-native-freshness-review
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin:$PATH"
freshness_receipts=/workspace/scratch/0eb32b15fbb4/recovery/native-freshness-review
git rev-parse HEAD 'HEAD^{tree}' > "$freshness_receipts/affected-green-identity-before.txt"
git status --porcelain=v1 > "$freshness_receipts/affected-green-status-before.txt"
git diff --binary > "$freshness_receipts/affected-green-source.patch"
mvn -o -B --no-transfer-progress -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -f qa/math-optimization/pom.xml -Dtest=JavaTailRecursionRewriteTest,JavaTailRecursionReplayTest,JavaTailRecursionInspectorTest,MathCleanUpOptionsTest,JavaValueResidueTest,MathematicalInterruptionTest,DocumentedSourceSnapshotTest,JavaFiniteSumBudgetTest clean test > "$freshness_receipts/affected-green.log" 2>&1
freshness_green_exit=$?
printf '%s\n' "$freshness_green_exit" > "$freshness_receipts/affected-green-exit.txt"
mkdir -p "$freshness_receipts/affected-green-xml"
cp qa/math-optimization/target/surefire-reports/TEST-*.xml "$freshness_receipts/affected-green-xml/"
git rev-parse HEAD 'HEAD^{tree}' > "$freshness_receipts/affected-green-identity-after.txt"
git status --porcelain=v1 > "$freshness_receipts/affected-green-status-after.txt"
sha256sum sandbox_math_cleanup/src/org/sandbox/jdt/internal/corext/fix/math/MathematicalAnalysis.java sandbox_math_cleanup_test/src/org/sandbox/jdt/internal/corext/fix/math/JavaTailRecursionRewriteTest.java > "$freshness_receipts/affected-green-source-sha256.txt"
tail -n 45 "$freshness_receipts/affected-green.log"
exit "$freshness_green_exit"
