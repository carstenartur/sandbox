#!/usr/bin/env bash
set -u
cd /tmp/sandbox-native-recovery
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin:$PATH"
export JAVA_TOOL_OPTIONS='-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Dhttps.proxyHost=browser-proxy -Dhttps.proxyPort=8889 -Dhttp.proxyHost=browser-proxy -Dhttp.proxyPort=8889'
native_receipts=/workspace/scratch/0eb32b15fbb4/recovery/native-qualification
git rev-parse HEAD 'HEAD^{tree}' > "$native_receipts/native-green3-identity-before.txt"
git diff --binary > "$native_receipts/native-green3-source.patch"
git status --porcelain=v1 > "$native_receipts/native-green3-status-before.txt"
git diff --name-only --diff-filter=ACM | while IFS= read -r native_path; do sha256sum "$native_path"; done > "$native_receipts/native-green3-source-sha256.txt"
sha256sum sandbox_math_cleanup/lib/qualification-2026-11-01-published-value.json >> "$native_receipts/native-green3-source-sha256.txt"
touch "$native_receipts/native-green3-started"
xvfb-run --auto-servernum --server-args='-screen 0 1600x1200x24' mvn -B --no-transfer-progress -s /tmp/jdt-pr5614-tools/public-proxy-settings.xml -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -Dsandbox.tycho.linux-only=true -Pswtbot -Dtest=FunctionalMathCleanUpTest,FunctionalMathPreferenceTest,MathematicalOptionsInitializerTest,MathematicalReportTest,MathematicalWorkbenchSWTBotTest,MathCleanUpOptionsTest,JavaTailRecursionInspectorTest,JavaTailRecursionRewriteTest,JavaTailRecursionReplayTest,JavaRuntimeIterationTest,JavaRuntimeIterationReviewTest,PrimitiveSourceGuardTest,JavaValueCallAdmissionTest,JavaValueGuardTypeBindingTest -Dsurefire.failIfNoSpecifiedTests=false -pl sandbox_target,sandbox_common,sandbox_math_cleanup_test -am clean verify > "$native_receipts/native-green3.log" 2>&1
native_green_exit=$?
printf '%s\n' "$native_green_exit" > "$native_receipts/native-green3-exit.txt"
mkdir -p "$native_receipts/native-green3-xml"
if test -d sandbox_math_cleanup_test/target/surefire-reports; then find sandbox_math_cleanup_test/target/surefire-reports -name 'TEST-*.xml' -newer "$native_receipts/native-green3-started" -exec cp {} "$native_receipts/native-green3-xml/" \;; fi
git rev-parse HEAD 'HEAD^{tree}' > "$native_receipts/native-green3-identity-after.txt"
sha256sum -c "$native_receipts/native-green3-source-sha256.txt" > "$native_receipts/native-green3-source-after.txt"
tail -n 55 "$native_receipts/native-green3.log"
exit "$native_green_exit"
