#!/usr/bin/env bash
set -u
cd /tmp/sandbox-native-recovery
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin:$PATH"
native_receipts=/workspace/scratch/0eb32b15fbb4/recovery/native-qualification
git rev-parse HEAD 'HEAD^{tree}' > "$native_receipts/headless-red-identity-before.txt"
git diff --binary > "$native_receipts/headless-red-source.patch"
mvn -o -B --no-transfer-progress -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -f qa/math-optimization/pom.xml -Dtest=MathCleanUpOptionsTest,JavaTailRecursionReplayTest clean test > "$native_receipts/headless-red.log" 2>&1
native_red_exit=$?
printf '%s\n' "$native_red_exit" > "$native_receipts/headless-red-exit.txt"
mkdir -p "$native_receipts/headless-red-xml"
cp qa/math-optimization/target/surefire-reports/TEST-*.xml "$native_receipts/headless-red-xml/"
git rev-parse HEAD 'HEAD^{tree}' > "$native_receipts/headless-red-identity-after.txt"
tail -n 38 "$native_receipts/headless-red.log"
exit "$native_red_exit"
