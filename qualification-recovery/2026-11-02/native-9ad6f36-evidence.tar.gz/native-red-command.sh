#!/usr/bin/env bash
set -u
cd /tmp/sandbox-native-recovery
export JAVA_HOME=/tmp/jdt-pr5614-tools/jdk-25.0.5+8
export PATH="$JAVA_HOME/bin:/tmp/jdt-pr5614-tools/apache-maven-3.9.16/bin:$PATH"
export JAVA_TOOL_OPTIONS='-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Dhttps.proxyHost=browser-proxy -Dhttps.proxyPort=8889 -Dhttp.proxyHost=browser-proxy -Dhttp.proxyPort=8889'
native_receipts=/workspace/scratch/0eb32b15fbb4/recovery/native-qualification
git rev-parse HEAD 'HEAD^{tree}' > "$native_receipts/native-red-identity-before.txt"
git diff --binary > "$native_receipts/native-red-source.patch"
xvfb-run --auto-servernum --server-args='-screen 0 1600x1200x24' mvn -B --no-transfer-progress -s /tmp/jdt-pr5614-tools/public-proxy-settings.xml -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -Dsandbox.tycho.linux-only=true -Dtest=FunctionalMathCleanUpTest -Dsurefire.failIfNoSpecifiedTests=false -pl sandbox_target,sandbox_common,sandbox_math_cleanup_test -am clean verify > "$native_receipts/native-red.log" 2>&1
native_red_exit=$?
printf '%s\n' "$native_red_exit" > "$native_receipts/native-red-exit.txt"
mkdir -p "$native_receipts/native-red-xml"
if test -d sandbox_math_cleanup_test/target/surefire-reports; then cp sandbox_math_cleanup_test/target/surefire-reports/TEST-*.xml "$native_receipts/native-red-xml/"; fi
git rev-parse HEAD 'HEAD^{tree}' > "$native_receipts/native-red-identity-after.txt"
tail -n 50 "$native_receipts/native-red.log"
exit "$native_red_exit"
