# Native tail / SDK70 reconstruction — qualified local slice

## Exact source

- Commit: `9ad6f36aa3c7f3acd43b0998568922c5683f2d54`.
- Tree: `60c2345284e89e3f90faf30f0f12eecd78aeab9c`.
- Parent: `1d213529d73fe43bc4fb017bfffa088d1befe7a1`.
- Parent tree: `d92eff43fbfb376f88680e48002798e1056ff68d`.
- Worktree: `/tmp/sandbox-native-recovery`, branch `codex/native-sdk-recovery`, clean.
- Scope: 29 files, +716/-118 = **834 changed text lines**, plus one exact SDK JAR transfer.

This reconstructs lost native integration in the previously authorized scope. It
does not claim recovery of the old Native implementation. The SDK artifact and
qualification JSON themselves are byte-exact transfers from pinned staging.

## Resulting behavior

The default-off tail option is independent of mathematical mode and of optional
Functional Converter coordination. Legacy constructors keep it false;
`withValueRuntime` preserves it. The complete math map has14 keys. Select All,
selection cleanup and save defaults do not grant frame-elision consent.

The native coordinator inspects and independently replays bounded static
primitive countdown methods on a private working copy. It preserves parameters,
simultaneous state updates, primitive widths and source-bound method identity,
documents the accepted frame/stack change, and supplies one Preview/Apply/Undo.
Tail bodies remain protected through later math/style phases and repeated Apply.
All phases share work, cancellation and the aggregate best-effort deadline;
source, compiler, classpath, dependency and profile freshness remain enforced.

Only Preserve Java, mathematical mode off and Estimated Runtime expose a
replayed counted loop to the existing SDK finite-series/affine proofs. Explicit
mathematical value mode retains the ordinary verified loop and can coexist with
audited detached reuse in the same native transaction. There is no new general
Java consumer for OrderedMatrixChain rules.

## Actual test evidence

| Run | Actual result | Meaning |
|---|---|---|
| `headless-red` | 17 tests,3 expected failures,0 errors/skips | Missing tail key/default/count and canonical-loop replay were observed before their implementation. |
| `native-red` | 32 tests,5 expected failures,0 errors/skips | All27 prior native coordination tests passed; all5 new tail integration tests failed before the bridge. |
| `native-green` | Stopped before tests | Production compiled; SpotBugs found the unused former source-match wrapper. The stale RED XML copied from its prior target is explicitly excluded from qualification. |
| `native-green2` | 146 tests,2 failures,0 errors/skips | All original gates passed, but the new accelerated-tail and tail+reuse positives exposed two admission mismatches. |
| `native-diagnosis-red` | 3 tests,3 expected failures,0 errors/skips | Actual diagnostics were `RUNTIME_ITERATION_NOT_ADMITTED` and `VALUE_CONSTRUCTOR_EFFECT`; independent postfix replay was also RED. |
| **`native-green3`** | **151 tests in14 fresh XML suites,0 failures/errors/skips** | All8 modules and all SpotBugs gates passed, Maven exit0,2:11, completed2026-11-02T05:50:26Z. |

The iteration correction emits the already admitted `counter--` form. Independent
replay checks its actual binding/type and the original counter-minus-one argument,
including an original/model mismatch regression. The native value fixture now
uses the same explicit `this.field` constructor assignments as the existing
Call/Reuse fixtures. Neither iteration/value admission nor budgets were relaxed.

The final selector includes FunctionalMathCleanUpTest, FunctionalMathPreferenceTest,
MathematicalOptionsInitializerTest, MathematicalReportTest,
MathematicalWorkbenchSWTBotTest, MathCleanUpOptionsTest,
JavaTailRecursionInspectorTest, JavaTailRecursionRewriteTest,
JavaTailRecursionReplayTest, JavaRuntimeIterationTest,
JavaRuntimeIterationReviewTest, PrimitiveSourceGuardTest,
JavaValueCallAdmissionTest and JavaValueGuardTypeBindingTest.

`native-green3-command.sh` records the exact Java25.0.5+8, Maven3.9.16,
public-proxy settings, Xvfb and unchanged clean verify/SpotBugs/SWTBot invocation.
`native-green3-summary.json` sums the14 fresh XML files. All29 source/SDK SHA-256s
match before and after the run. `native-final-byte-verification.json` additionally
checks the committed Git blobs against those tested bytes; no source changed
between qualification and commit. Native logs retain platform diagnostics and
the expected negative-path messages, rather than filtering them out.

## SDK and remaining boundaries

- SDK source: `70c13fb580062b1fd653f35b81b2fb7ed1903c28`.
- Pinned staging commit: `1573e539f14313409ed5e16e1d80ea95b97493b5`.
- JAR Git blob: `43f02adbaacc2db5028f2eb80ef7f8dae8423673`.
- JAR SHA-256: `ba0293dedb3fde9ca2f3042dcef8ae4d6bb2d576adedff8ba7a2b4d186f1cbe1`.
- Qualification Git blob: `9029f42ef1464afc68167ee3457df2d3b32c2e22`.
- The original SDK93 qualification is retained under its historical filename;
  no missing SDK70 double-build receipt or SDK test count is invented.

The public Native base and genuine five-fixture Help recapture remain with Root,
as do the combined corpus/upstream/retention and release gates. Help properties,
JSONs and PNGs are unchanged. This is local native consumer qualification, not
a new Regelsuche release, a current BLS measurement or a speedup claim.

## Recovery deliverables

`native-9ad6f36-payload.json` contains all28 changed text files in full and the
verified existing SDK Git blob reference, with exact parent/head/tree identities,
path scope, content hashes and test summary. The agent's functions store also
holds this complete object under `native_recovery_final_9ad6f36_payload`.
The compact evidence archive retains the three genuine RED stages, final GREEN,
XMLs, command scripts, source identity/byte checks and this report. Intermediate
failed attempts remain separately available in the local ledger.
