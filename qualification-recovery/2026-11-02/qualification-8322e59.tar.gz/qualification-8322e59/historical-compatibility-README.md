# BLS emission compatibility: 92b8b12 against historical bfad

## Result and exact identities

All five complete effective cohort source files are byte-for-byte identical to the retained bfad cohort. Four changed Java files were compared directly with `cmp --silent`; unchanged Fp12 was compared through both complete source-context files. Each of the five original sources was also compared directly against its pinned source-archive entry. All ten comparisons exited 0; `byte-comparison-exits.tsv` records them.

- Candidate: `92b8b123b8328b54be408117e1870b8a1d1514b9`, tree `b6a0f25c47ca41165a99c247b7811f82d605f7ae`.
- Historical cohort: `bfadf442b7535817dba4cc3c3e988f6a878e756e`, tree `61efa3e45eaa049ea3947d376e7ca2160f66e6c2`.
- Actual preparation: `/tmp/sandbox-complete-format-92b8b12/qa/math-optimization/target/bc-bls`.
- Retained current cohort: `../bc-bls/`. All 3,156 copied files match the actual preparation; `copied-cohort.sha256` and `copied-cohort-check.log` bind every file, including the 3,136 source-context files.

The existing canonical `prepare-bls-source-cohort` execution completed with exit 0 in 12.638 seconds on 2026-11-02 at 01:55:36 UTC. Its scan ran from 01:55:30.832916786 to 01:55:36.794375957 UTC. Both reports contain 5 parsed classes, 0 parse errors, 6 extracted regions and 9 accepted regions. The retained `run/` directory contains the original log, start/end timestamps, before/after commit and tree identities, exit code, and clean-status receipts.

## Complete source hashes

| Class | Accepted regions | SHA-256 of complete effective source |
|---|---:|---|
| BLS12_381G2HashToCurve.java | 2 | `c619c05cb0820ed6a31ce3d0c404df5ca750d357c6d0093c65bb1eb0f57d4008` |
| BLS12_381Pairing.java | 1 | `dacb0faf94d09a86f12ed0640e38e18059e38fac14f75a43cb6de68502aafef1` |
| Fp12Element.java | 0 | `c4a0bba167311890878798e94c3566dc8d603b24ec5d58a88c462629b8cd0354` |
| Fp2Element.java | 1 | `8d8b95aec88d70886204ca048aa2f7132585d5f1d0673e7cba986ec8e0c11ebc` |
| Fp6Element.java | 5 | `760c5e22c1c26205742a1104128ae6be346f482e09c01ae5d7b733fe2e5d1c36` |

Fp12 has no accepted change and therefore no `generated/` file or `afterSha256` field. Its effective text is the unchanged source-context file, with the same hash as its pinned archive entry. The archive comparisons used `unzip -p ... | cmp --silent - ...` with pipefail enabled.

## Manifests, profiles and runtime receipts

Each distinct `benchmark.properties` manifest matches all 13 listed files: four original sources, four generated sources, four evidence files and `review.json`. Both original manifests are retained here. The separate `baseline-manifest-check.log` and `candidate-manifest-check.log` contain 13 successful `sha256sum --check` results each.

All 14 option values are exactly equal between the completed reports. The historical profile taken from the bfad Git object is byte-identical to the candidate profile. The profile declares 20,000,000 work units, 20,000 states, a five-second timeout, explicit mathematical opt-in and `AUDITED_OPENJDK_25_0_5_8`; tail recursion remains false. Java source target 17 and runtime descriptor `25.0.5+8-LTS` are unchanged. For the profile-to-report comparison only, numeric-kind ordering is normalized as the set used by `MathCleanUpOptions.parse` and serialized by `toMap`; no option is omitted or defaulted.

Independently hashed pinned inputs:

- Binary archive: `986b0fb92ec10e0c66b43e036ce0077e6150cfaecd1db9fb92b56672e157afe5`.
- Source archive: `b37ac84b1d5435ab7b8d166c16ab9f75e09f68f8ec50479bae433939b241b03f`.
- Profile: `187b34fe92fcd280b6dd9e3e16f88147da120deea3f28a7201b37e4f555e8cf0`.

The per-file audited-value-runtime receipts are exactly equal. G2 retains bytecode fingerprint `44c22b522dd865f70f0d14fea62ed1ebcaa472813a24447ab2cd4fe974d7d8c7` and audited-source fingerprint `bea1aec240aae5f19304cc95115ec7289ed39ae90b2ca59a7334c3ca40d23019`. No new runtime audit or JDK execution was performed by this comparison.

All ten source-dependency receipts in each report match their retained source-context files. Their relative paths and hashes are equal between cohorts; the absolute checkout prefixes differ. Each cohort's `inputs.json` agrees with its own final report on all shared metadata. All 477 current runtime file hashes were checked against actual files, and the external dependency JAR map is unchanged. The full runtime-input maps are not identical: after checkout-path normalization there are 21 modified adapter class files and three added adapter class files, all individually listed in `comparison.json`.

## Exact differences in reports and evidence

The report, input receipt and manifest bytes differ and retain their own identities:

| Current file | SHA-256 |
|---|---|
| review.json | `f3e3eed5080f8f2fe2097c2b209a718a50739b2e8facc65d28b0b74b2b081cb1` |
| inputs.json | `3fd985d35c43c622bbb81303d0c19f31be6a4a33455b74477610dcdc4a85edd6` |
| benchmark.properties | `586be554765027321a8380a8e657540173061eccc379f2a8a7ff04a476d79dbc` |
| run/prepare.log | `1d80c447f8291b03603304169fd8b32fa0205354dcafb209a5ce1ce5b68f63c0` |

The only changed top-level report fields are `files`, `startedAt`, `finishedAt` and `runtimeInputs`. Within file records, differences are confined to evidence hashes and absolute source-dependency identities.

- G2 evidence has three changed algebra-fingerprint fields.
- Pairing evidence has changed algebra fingerprints, the added guard-binding receipts for both fixed-power chains, and four relocated dependency identities.
- Fp2 evidence differs only in the order of its assumptions array; the complete assumption objects match as an unordered collection.
- Fp6 evidence is byte-identical.

The complete old/new evidence hashes and field differences are recorded in `comparison.json`; `metadata-differences.json` records the additional dependency-path and assumption-order checks. No emitted Java differs.

## Scope of the result

This establishes emitted-source compatibility for the current candidate. The historical bfad JMH run still classifies all three BLS pairs as `HIGHER_TIME`. No new JMH result, current timing measurement, speedup or causal timing attribution follows from source identity, and no historical measurement is relabeled as a 92b8b12 measurement.

The audit used read-only Git, `cmp`, `unzip`, SHA-256 and JSON/file comparisons. Only the requested evidence directories and a temporary audit helper were written. No JVM, Maven, JMH, product-source change or remote action was performed for this audit.
