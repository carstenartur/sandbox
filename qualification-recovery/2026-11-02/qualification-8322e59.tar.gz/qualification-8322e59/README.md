# Rebuilt BLS QA: focused qualification of 8322e59

This archive contains original Maven logs, JUnit XML, recorded source identities,
and actual scanner receipts. It does not contain a new JMH measurement or a
complete runnable source cohort. The full BC source-context trees and transient
JUnit fixture directories are omitted; the canonical Maven preparation recreates
them from the pinned archives.

## Qualified source and environment

- Local commit: `8322e59c8cf9bc1589fc65e9c3d795379bc7a8ad`.
- Exact tested and committed tree: `ee505cb03cdc6ae5ec18ddbdbe49f1053b55069e`.
- Parent: `1d213529d73fe43bc4fb017bfffa088d1befe7a1`.
- Parent tree: `d92eff43fbfb376f88680e48002798e1056ff68d`.
- Coordinator's durable source checkpoint: `aeb838c9b7e3cc60545682f9ee3600ac9ce5f020`
  on `codex/recover-bls-20261102`.
- Change scope: eleven QA files, 883 added and three removed text lines; no
  production adapters, SDK artifact, general corpus budget, or admission gate changed.
- Java runtime: `25.0.5+8-LTS`; Maven `3.9.16`; emitted source target Java 17.
- SDK used in these runs (the pre-SDK70 integration artifact):
  `5ad54860d828a738d4df8dba87659b8a14009bfb208f79705a4b8529b9c58884`.
- Pinned BC 1.85.2 binary SHA-256:
  `986b0fb92ec10e0c66b43e036ce0077e6150cfaecd1db9fb92b56672e157afe5`.
- Pinned sources SHA-256:
  `b37ac84b1d5435ab7b8d166c16ab9f75e09f68f8ec50479bae433939b241b03f`.
- Qualified BLS profile SHA-256:
  `7bb9a94a3d9973e6f8b66e632fe7acaafb4080aca42f79f832a1501f6d3f74cf`.

The coordinator independently reviewed all changed helpers, loader, Maven profile,
and tests, inspected the actual 23 XML cases and source distribution, and reported
APPROVED for this exact commit/tree with no further concrete findings.

## Recorded RED and diagnostic stages

1. `red-initial/`: the first test asserted that the canonical BLS preparation
   entry point exists before its implementation. It failed as intended because
   that class did not exist: one failure, zero errors/skips, 8.292 seconds.
   The recorded base is `06137bf5b330ce6d55608f79c36787d69db9e16e`; the test
   was new and uncommitted, so `base-identity.txt` is a base identity, not a
   claim that its base tree contains that test.
2. `profile-mismatch/`: the first combined attempt ran 19 cases and reported
   one failure and one error, with zero skips, in 35.992 seconds. The rebuilt
   dedicated BLS profile had mistakenly copied the general corpus's 1,000,000
   work units. Actual acceptance was G2=1, Pairing=0, Fp12=0, Fp2=1, Fp6=3;
   the original nine-region assertion and expected Pairing evidence therefore
   failed. The additional canonical prepare completed in 5.786 seconds and
   its original receipts and concise value-limit diagnostics are retained.
   Its first offline attempt only failed to resolve the not-yet-cached Maven
   exec plugin; the configured proxy resolved it on the next attempt.
3. `historical-compatibility-README.md` is the retained earlier receipt, copied
   verbatim. Its SHA-256 is
   `9f724df32976aa9d5355dac0c11480dc9f56f5a9a688aa50092d3bb52bd8502e`.
   It explicitly establishes the original dedicated BLS limit of 20,000,000
   work units, 20,000 states and five seconds. Restoring that BLS limit and
   making JUnit use the canonical BLS profile recovered nine regions with the
   same SDK. The general corpus profiles remain at their independent limits.
   The old receipt's referenced cohorts and timings have not been recovered;
   its historical claims do not qualify this reconstructed harness.
4. `red-runtime/`: four parameterized cases changed every raw JMH row's JVM
   executable, JDK version, VM name, or VM version consistently to a foreign
   value. All four failed with the expected missing rejection, zero errors
   and zero skips, in 16.224 seconds, ending at 2026-11-02T05:41:18Z.
   This was observed before adding the runtime binding. The same run printed
   five parsed classes, zero parse errors and nine accepted regions. The
   requested temporary-directory retention setting was not effective; no
   retained complete fixture is claimed for that run.

The report fix now checks every raw row against the actual JVM properties used
by JMH 1.37, and fixture validation binds that runtime to the captured scanner
runtime. The report exposes those validated measurement-runtime fields.

## Fresh GREEN

`green-focused/` contains the original complete run and exported scanner
receipts. The clean Maven run completed at **2026-11-02T05:46:22Z**, took
**35.722 seconds**, and returned **exit 0: 23 tests, zero failures, errors or
skips**. Its staged candidate tree and post-commit tree are identical.

The selected classes were:

- `BlsSourceCohortTest`: 12 cases, including the four foreign-runtime cases;
  five complete originals and generated sources, complete G2 calls for 32/256
  bytes and full pairing outputs, distinct classloaders, all five compiled
  classes including unchanged Fp12, missing-class rejection, source/provenance
  and late-drift rejection, report pair/settings/statistics validation.
- `FiniteSeriesQualificationTest`: nine existing cases guarding the reused
  settings and statistical reconstruction authority.
- `FullCallBenchmarkReportTest`: two existing interval-classification cases.

The full-call tests compare sixteen varied samples during setup, then additional
complete samples and boundary lengths. They compare all 96 compressed G2 bytes
or all 576 serialized pairing bytes. These are numerical equality checks, not a
constant-time claim or general performance result.

| Complete class | Accepted regions | Effective generated SHA-256 |
|---|---:|---|
| BLS12_381G2HashToCurve | 2 | `c5c77430d497a03479c5f9e73b5a2a74ed1ea67cc7da2e443f7606dc29fc2dd3` |
| BLS12_381Pairing | 1 | `dacb0faf94d09a86f12ed0640e38e18059e38fac14f75a43cb6de68502aafef1` |
| Fp12Element | 0 | `c4a0bba167311890878798e94c3566dc8d603b24ec5d58a88c462629b8cd0354` |
| Fp2Element | 1 | `8d8b95aec88d70886204ca048aa2f7132585d5f1d0673e7cba986ec8e0c11ebc` |
| Fp6Element | 5 | `760c5e22c1c26205742a1104128ae6be346f482e09c01ae5d7b733fe2e5d1c36` |

G2 differs from the earlier recorded `c619c05cb0820ed6a31ce3d0c404df5ca750d357c6d0093c65bb1eb0f57d4008`.
The other four effective-source hashes equal the historical receipt. This is a
comparison of recorded source hashes; the lost original harness was not recovered
byte-for-byte. Current measurements must retain their own identity.

The focused Maven command, run from `/tmp/sandbox-bls-recovery` with the restored
JDK/Maven binaries on PATH and the configured proxy/trust-store JVM options, was:

```sh
mvn -o -s /tmp/jdt-pr5614-tools/public-proxy-settings.xml -B -ntp \
  -Dmaven.repo.local=/tmp/jdt-pr5614-m2 -f qa/math-optimization/pom.xml \
  -Dtest=BlsSourceCohortTest,FiniteSeriesQualificationTest,FullCallBenchmarkReportTest \
  clean test
```

## Remaining integration gates

The coordinator owns integration onto Native/SDK70, the explicit default-false
tail option in the BLS profile when that option becomes available, the optional
upstream JGit source-identity test, and a fresh canonical two-fork JMH/report run
on the frozen combined tree. None is claimed complete by these focused results.
No remote mutation was performed by this implementation worker.

`SHA256SUMS` binds every other file in this archive. The archive's own SHA-256 is
provided separately with the handoff.
